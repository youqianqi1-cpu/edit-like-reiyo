# Windows 执行说明

剪辑判断与 Mac 完全共用；本页只替换本机执行办法。此入口已做代码和媒体样本检查，尚未在 Windows 剪映完成真机验收。第一次先做短段，不能把文件生成成功说成用户已能播放。

## 1. 检查与一次准备

使用当前 Codex 可提供的 64 位 Python 3.10–3.12，运行 `python -X utf8 scripts/preflight.py`。确认剪映当前安装版本、草稿位置、字体候选和本地工具缺项。不要只根据存在 `videoeditor.dll` 就判定兼容；从运行中的剪映路径确认当前版本。默认安装位置候选由 preflight 列出，自定义位置再询问用户。

第一次向用户说明需在 Skill 自己的 `.runtime` 文件夹下载运行依赖和 Whisper small 模型（模型通常数百 MB，需要网络，下载完成后本地识别）。用户同意后执行：

```text
python -X utf8 scripts/setup_portable.py --download-model
```

之后 `<py>` 一律指该 Skill 下 `.runtime/venv/Scripts/python.exe`，重新运行 `<py> -X utf8 scripts/preflight.py`。使用已有本地 Whisper 模型时设置 `REIYO_WHISPER_MODEL` 为目录，不额外下载。下载失败或版本不合时记录准确缺项并停止该准备步骤，不反复更换模型、系统或安装来源。

源码已固定依赖版本及 Windows 草稿读写库的具体版本；不复制剪映的程序库，不获取 Reiyo 私人缓存。Windows 草稿兼容性依赖用户实际安装版本。

## 2. 先验证一个新的空白草稿

有实际电脑操作工具时，在剪映首页新建准确命名的“剪出帧我试剪-视频名”草稿，保存并回到首页。没有该工具时请用户做这一步并提供草稿位置。不要复制正式稿注册成新稿，也不要自己伪造剪映首页登记。

所有命令的路径用独立参数传入并正确引用；`<安装目录>` 是含 `videoeditor.dll` 的当前剪映版本目录。

```text
<py> -X utf8 scripts/draft_windows.py --install-dir <安装目录> init <新草稿目录> --exact-name <准确目录名> --closed --receipt ready.json
<py> -X utf8 scripts/draft_windows.py --install-dir <安装目录> read <新草稿目录> blank.json
```

初始化只接受空白草稿，并先在内存中核对读写是否一致，记录唯一身份与恢复副本。失败就停在这里，不开始整片制作。第二条命令输出当前文件指纹，后面写入必须使用它。

## 3. 原片、声音与画面

`<py> -X utf8 scripts/analyze_media.py <原片> <新分析目录>` 自动使用 Windows 本地识别入口，输出与 Mac 相同的 source.json、audio.pcm、audio.wav、words.jsonl、transcript.txt。失败后的半成品目录不当作可复用缓存。

画面用 `<py> -X utf8 scripts/portable_media.py frames <视频> <输出目录> <秒数...>`；输出记录请求时间与实际画面时间。图片拼图用 `portable_visuals.py contact <输出.png> <图片...>`。波形使用同一 `waveform.py` 与 `audit_breaths.py`；需要看放大的波形图时使用 `portable_visuals.py waves <输入.json> <输出.png> --font <本机中文字体>`，输入格式与 wave_sheet.swift 相同。简单图形分层使用 `portable_visuals.py shapes <输入.json> <输出.png>`，与 draw_shapes.swift 的底部原点坐标一致。

转写仅定位，仍按 breath-cuts.md 检查真正字头、尾音和无意义等待。Windows 识别结果可能与 Mac 不同，不继承旧词时间或剪点。声音解码按原始时间放回对应位置，遇到缺失时间戳就停止，不能把起始空白挪掉再切视频。手机旋转画面先抽帧肉眼检查再使用。

## 4. 同一套剪辑判断与生成工具

选段、字幕对齐、景别与重点字、素材/MG、声音使用同一套规则及脚本：`select_takes.py`、`apply_cuts.py`、`align_captions.py`、`compose_beats.py`、`layout_captions.py`、`assemble.py`。`check_cut_audio.py` 和 `sound_inventory.py` 自动走 Windows 声音入口。所有命令使用 `<py> -X utf8`，中文内容为 UTF-8。

在 plan 中显式填写本机实际存在的 `font` 和需要的 `title_font`，不要写 Mac 字体路径。核心生成器不会替你猜 Windows 字体。无个人资源时，使用 starter-assets.md 的随包字体和 WAV，资源准备脚本可在 Windows 运行。音效来自随包或用户许可的素材，正常音量默认 1.0，未找到的素材不能编造。

```text
<py> -X utf8 scripts/assemble.py blank.json plan.json candidate.json
<py> -X utf8 scripts/draft_windows.py --install-dir <安装目录> install <新草稿目录> candidate.json --expected-sha <刚读取的指纹> --exact-name <准确目录名> --closed --receipt saved.json
```

写入要求存在初始化记录，草稿身份一致、期间没有变化、已关闭；先验证候选再写入，保留恢复副本。只处理该新草稿的主文件及唯一时间线，不改现有正式稿和首页登记。不要绕过保护检查。

## 5. 第一次只剪 10–20 秒，再继续

选原片里能完整表达的短段，至少包含两处剪口、中文字幕和一个景别或重点字变化。首次短段用于验证该电脑的运行，不规定以后的风格或效果数量。

保存后重新打开，让当前实际工具或用户确认画面、时长、中文字体、音画同步、字头和尾音。若没有电脑操作工具，明确请用户打开播放；未看到或听到不能写为通过。短段通过后，在这个新试剪稿中制作完整视频；Mac 与 Windows 共同遵守同一份 quality-and-delivery.md，不重新借用作者旧任务。

文件读写不兼容、程序报错或素材无法定位时，保留提示和新草稿，不要求用户降级、修改正式稿或继续耗费整片时间。这个结果可以直接反馈给 Reiyo。
