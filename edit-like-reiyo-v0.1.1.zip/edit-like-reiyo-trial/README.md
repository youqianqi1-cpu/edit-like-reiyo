# 剪出帧我 · Edit like Reiyo

免费试用版 v0.1.1。已加入两款基础字体与 18 个短音效，没收藏也能开始；已有偏好优先。

把这句话发给 Codex：

> 帮我安装或更新「剪出帧我」：https://github.com/youqianqi1-cpu/edit-like-reiyo 。按照页面中的安装说明完成，保留我的自定义内容。

安装后：

> 用「剪出帧我」剪这条视频，新建草稿，原来的别动。

当前文件夹中的 `edit-like-reiyo/` 才是完整 Skill；安装时一起保留 references、scripts 和 assets。资源试听与字体预览在 `edit-like-reiyo/assets/starter/preview.html`。

剪辑判断与气口规则沿用原版本，本次只补充基础资源与调用办法。Mac 有开发机试剪记录；Windows 仍先做本机短段验证。资源文件已检查并接入工具，音效组合与新用户机器的实际成片效果通过试用继续确认。

资源来源与授权见 THIRD_PARTY.md，字体和音效授权原文随包提供。
