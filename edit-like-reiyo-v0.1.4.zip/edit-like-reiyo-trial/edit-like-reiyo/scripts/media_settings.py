"""Source-derived settings for NEW edits. Never rewrites an existing timeline."""
import json
import math
from pathlib import Path
import subprocess
import sys


def probe_source(path):
    if sys.platform == 'win32':
        from portable_media import probe
        return probe(path)
    result = subprocess.run([str(Path(__file__).with_name('media_probe')), str(path)],
                            capture_output=True, text=True, timeout=30, check=True)
    return json.loads(result.stdout)


def valid_fps(value):
    if type(value) not in (int, float) or not math.isfinite(value) or not 1 <= value <= 240:
        raise ValueError('Source frame rate is missing or invalid; inspect footage before cutting, never default to 30')
    for rate in [24000/1001, 30000/1001, 60000/1001, 120000/1001, 24, 25, 30, 50, 60, 120]:
        if abs(value-rate) < .002:
            return rate
    return value


def frame_settings(plan):
    durations = {}
    for take in plan['takes']:
        duration = take['end']-take['start']
        if not math.isfinite(duration) or duration <= 0:
            raise ValueError('Take duration must be positive')
        durations[take['source']] = durations.get(take['source'], 0) + duration
    if not durations:
        raise ValueError('No main footage to choose a frame rate from')
    sources = {}
    for key, duration in durations.items():
        source = plan['sources'][key]
        info = probe_source(source['path'])
        sources[key] = {'fps': valid_fps(info.get('fps')), 'used_seconds': duration,
                        'path': source['path'], 'fps_kind': info.get('fps_kind', 'unknown')}
    primary = max(durations, key=durations.get)
    fps = sources[primary]['fps']
    reason = 'Match the main source with the longest selected speaking duration; overlay footage does not choose the project rate'
    # A historical plan.fps is not evidence of a current user preference.
    if plan.get('fps_reason'):
        if not isinstance(plan['fps_reason'], str) or not plan['fps_reason'].strip():
            raise ValueError('fps_reason must record the explicit output requirement')
        fps = valid_fps(plan.get('fps'))
        reason = plan['fps_reason']
    return {'fps': fps, 'primary_source': primary, 'reason': reason, 'sources': sources,
            'mixed_main_rates': len({s['fps'] for s in sources.values()}) > 1,
            'vfr_verified': False, 'existing_timeline_changed': False}


def level_summary(levels):
    """Engineering flags only, not speech classification or a gain prescription."""
    channels = levels['channels']
    peaks = [c['peak_dbfs'] for c in channels if c['peak_dbfs'] is not None]
    flags = []
    if not peaks:
        flags.append('silence: check recording and selected audio track')
    elif max(peaks) < -18:
        flags.append('low sample peak: inspect normal speaking sections before gain adjustment')
    if any(c['near_full_scale_samples'] > 0 for c in channels):
        flags.append('near full scale: inspect loud sections for distortion; not proof of clipping')
    rms = [c['rms_dbfs'] for c in channels if c['rms_dbfs'] is not None]
    if len(channels) > 1 and (len(rms) != len(channels) or (rms and max(rms)-min(rms) >= 6)):
        flags.append('channel imbalance: inspect left/right recording before downmix or gain changes')
    return {'flags': flags, 'automatic_gain_db': 0,
            'thresholds_are_course_rules': False,
            'meaning': 'Sample levels only. Use the per-second windows and actual speech to review; no flags is not listening approval.'}
