"""Local Windows media helpers. Editorial decisions stay in the shared Skill.

PyAV decodes at original timestamps; Whisper provides word candidates, not cuts.
No media is uploaded. A model must already be downloaded by setup_portable.py.
"""
import argparse
import json
import math
import os
from pathlib import Path
import wave

RATE = 16000


def audio_levels(source):
    """Original channels and sample rate; no gain or mono resampling."""
    import av
    import numpy as np
    from media_settings import level_summary
    channels, windows = [], {}
    def empty(): return {'peak': 0., 'squares': 0., 'samples': 0, 'near_full_scale_samples': 0}
    def add(stat, values):
        stat['peak'] = max(stat['peak'], float(np.max(np.abs(values))))
        stat['squares'] += float(np.sum(values * values))
        stat['samples'] += values.size
        stat['near_full_scale_samples'] += int(np.count_nonzero(np.abs(values) >= .999))
    def finish(stat):
        db = lambda x: 20*math.log10(x) if x > 0 else None
        return {'peak_dbfs': db(stat['peak']),
                'rms_dbfs': db(math.sqrt(stat['squares']/stat['samples'])) if stat['samples'] else None,
                'samples': stat['samples'], 'near_full_scale_samples': stat['near_full_scale_samples']}
    with av.open(str(source)) as container:
        if not container.streams.audio: raise ValueError('No audio track')
        resampler = None
        def measure(frame):
            nonlocal channels
            if frame.pts is None: raise ValueError('Missing audio timestamp')
            values = frame.to_ndarray().astype(np.float64)
            if not np.all(np.isfinite(values)): raise ValueError('Nonfinite audio samples')
            if not channels: channels = [empty() for _ in values]
            if len(channels) != len(values): raise ValueError('Audio channel layout changed')
            for stat, row in zip(channels, values): add(stat, row)
            seconds = np.floor(float(frame.pts*frame.time_base)+np.arange(frame.samples)/frame.sample_rate).astype(int)
            for second in np.unique(seconds):
                add(windows.setdefault(int(second), empty()), values[:, seconds == second])
        for frame in container.decode(audio=0):
            if resampler is None:
                resampler = av.AudioResampler(format='fltp', layout=frame.layout, rate=frame.sample_rate)
            for converted in resampler.resample(frame): measure(converted)
        if resampler:
            for converted in resampler.resample(None): measure(converted)
    if not channels: raise ValueError('No decoded audio samples')
    result = {'measurement': 'original-channel sample peak and RMS; not LUFS or true peak',
              'channels': [finish(s) for s in channels],
              'windows': [dict(start=s, **finish(windows[s])) for s in sorted(windows)],
              'gain_applied_db': 0, 'listened': False}
    result['review'] = level_summary(result)
    return result


def probe(source):
    import av
    with av.open(str(source)) as container:
        videos = list(container.streams.video)
        video = videos[0] if videos else None
        duration = float(container.duration / av.time_base) if container.duration is not None else None
        if duration is None and video is not None and video.duration is not None:
            duration = float(video.duration * video.time_base)
        if duration is None or not math.isfinite(duration) or duration <= 0:
            raise ValueError('Cannot establish the source duration')
        origin = float(container.start_time / av.time_base) if container.start_time is not None else 0.0
        result = {'path': str(Path(source).resolve()), 'duration': duration, 'timeline_origin': origin}
        if video:
            result.update(width=video.codec_context.width, height=video.codec_context.height)
            result['fps'] = float(video.average_rate) if video.average_rate else None
            result['fps_kind'] = 'average; variable frame rate not determined'
            rotation = int(float(video.metadata.get('rotate', 0))) % 360
            # Side-data rotation is checked again on a decoded frame below.
            first = next(container.decode(video), None)
            if first is not None:
                rotation = int(getattr(first, 'rotation', rotation)) % 360
            result['rotation'] = rotation
            if rotation in (90, 270):
                result['width'], result['height'] = result['height'], result['width']
        return result


def decode_pcm(source, output, info=None):
    import av
    import numpy as np
    output = Path(output)
    if output.exists():
        raise FileExistsError(output)
    info = info or probe(source)
    samples = np.zeros(math.ceil(info['duration'] * RATE), dtype='<i2')
    with av.open(str(source)) as container:
        if not container.streams.audio:
            raise ValueError('No audio track in this source')
        resampler = av.AudioResampler(format='s16', layout='mono', rate=RATE)

        def place(frame):
            if frame.pts is None:
                raise ValueError('Audio frame has no timestamp; refuse shifted cuts')
            start = round((float(frame.pts * frame.time_base) - info['timeline_origin']) * RATE)
            values = frame.to_ndarray().reshape(-1)
            left, right = max(0, start), min(len(samples), start + len(values))
            if right > left:
                samples[left:right] = values[left-start:right-start]

        for frame in container.decode(audio=0):
            for converted in resampler.resample(frame):
                place(converted)
        for converted in resampler.resample(None):
            place(converted)
    output.write_bytes(samples.tobytes())


def make_wav(pcm, output):
    with wave.open(str(output), 'wb') as out:
        out.setparams((1, 2, RATE, 0, 'NONE', 'not compressed'))
        out.writeframes(Path(pcm).read_bytes())


def transcribe(wav, output, model_path=None):
    model_path = model_path or os.environ.get('REIYO_WHISPER_MODEL')
    if not model_path:
        model_path = str(Path(__file__).resolve().parents[1] / '.runtime/models/whisper-small')
    if not (Path(model_path) / 'model.bin').is_file():
        raise FileNotFoundError('Local speech model missing. Run setup_portable.py --download-model after confirming the first download.')
    from faster_whisper import WhisperModel
    model = WhisperModel(model_path, device='cpu', compute_type='int8', local_files_only=True)
    segments, _ = model.transcribe(str(wav), language='zh', word_timestamps=True,
                                  vad_filter=False, condition_on_previous_text=False)
    rows = []
    for segment in segments:
        for word in segment.words or []:
            rows.append({'start': word.start, 'duration': word.end-word.start,
                         'text': word.word, 'confidence': word.probability})
    if not rows:
        raise ValueError('No speech recognized; do not create empty captions')
    Path(output).write_text('\n'.join(json.dumps(row, ensure_ascii=False) for row in rows)+'\n', encoding='utf-8')
    return rows


def analyze(source, output, model_path=None):
    source, output = Path(source).resolve(), Path(output)
    output.mkdir(parents=True, exist_ok=True)
    if any(output.iterdir()):
        raise ValueError('Use a fresh analysis folder; failed or partial results are not reused')
    info = probe(source)
    (output/'source.json').write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding='utf-8')
    (output/'audio-levels.json').write_text(json.dumps(audio_levels(source), ensure_ascii=False, indent=2), encoding='utf-8')
    decode_pcm(source, output/'audio.pcm', info)
    make_wav(output/'audio.pcm', output/'audio.wav')
    rows = transcribe(output/'audio.wav', output/'words.jsonl', model_path)
    (output/'transcript.txt').write_text('\n'.join(f"[{r['start']:.3f}] {r['text']}" for r in rows), encoding='utf-8')
    (output/'receipt.json').write_text(json.dumps({'source':str(source), 'backend':'pyav-whisper-local',
        'listened':False, 'words':len(rows), 'timeline_origin':info['timeline_origin']}, indent=2), encoding='utf-8')


def frames(source, output, times):
    import av
    output = Path(output); output.mkdir(parents=True, exist_ok=True)
    info = probe(source)
    targets = sorted(set(times))
    if not targets or any(not math.isfinite(t) or t < 0 or t >= info['duration'] for t in targets):
        raise ValueError('Frame times must be within source duration')
    found = []
    with av.open(str(source)) as container:
        if not container.streams.video:
            raise ValueError('No video track')
        for frame in container.decode(video=0):
            if frame.pts is None:
                continue
            time = float(frame.pts * frame.time_base) - info['timeline_origin']
            while targets and time + 1e-6 >= targets[0]:
                requested = targets.pop(0)
                name = f'frame-{requested:.3f}.png'
                image = frame.to_image()
                if info.get('rotation'):
                    image = image.rotate(info['rotation'], expand=True)
                image.save(output/name)
                found.append({'requested':requested, 'actual':time, 'path':str((output/name).resolve())})
            if not targets:
                break
    if targets:
        raise ValueError(f'Could not decode requested frames: {targets}')
    (output/'frames.json').write_text(json.dumps(found, indent=2), encoding='utf-8')
    return found


if __name__ == '__main__':
    p = argparse.ArgumentParser(); sub = p.add_subparsers(dest='command', required=True)
    for name in ['analyze', 'decode', 'transcribe', 'frames']:
        c = sub.add_parser(name); c.add_argument('source'); c.add_argument('output')
        if name in ['analyze','transcribe']: c.add_argument('--model')
        if name == 'frames': c.add_argument('seconds', nargs='+', type=float)
    a = p.parse_args()
    if a.command == 'analyze': analyze(a.source, a.output, a.model)
    elif a.command == 'decode': decode_pcm(a.source, a.output)
    elif a.command == 'transcribe': transcribe(a.source, a.output, a.model)
    else: frames(a.source, a.output, a.seconds)
