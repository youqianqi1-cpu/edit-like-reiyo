import json
import math
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import wave

import analyze_media as am


class AudioPreparation(unittest.TestCase):
    def test_decode_and_resume_after_recognition_failure(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); src=root/'stereo.wav'; out=root/'analysis'
            with wave.open(str(src),'wb') as f:
                f.setparams((2,2,44100,0,'NONE','not compressed'))
                f.writeframes(b''.join(struct.pack('<hh',int(9000*math.sin(i*.1)),int(6000*math.sin(i*.1))) for i in range(44100)))
            native_run=am.run
            def failed_asr(args, timeout):
                if Path(args[0]).name=='transcribe_words': raise RuntimeError('simulated recognizer failure')
                return native_run(args,timeout)
            with patch.object(am,'run',side_effect=failed_asr):
                with self.assertRaisesRegex(RuntimeError,'transcribe_words'): am.analyze(src,out)
            self.assertEqual((out/'audio.pcm').stat().st_size,32000)
            self.assertEqual(json.loads((out/'failure.json').read_text())['stage'],'transcribe_words')
            pcm_hash=am.digest(out/'audio.pcm')
            calls=[]
            def resumed(args,timeout):
                calls.append(Path(args[0]).name)
                if calls[-1]!='transcribe_words': self.fail('Completed decoding must not run again')
                return '{"start":0.1,"duration":0.2,"text":"测试"}\n'
            with patch.object(am,'run',side_effect=resumed): am.analyze(src,out)
            self.assertEqual(calls,['transcribe_words'])
            self.assertEqual(am.digest(out/'audio.pcm'),pcm_hash)
            self.assertFalse((out/'failure.json').exists())
            with patch.object(am,'run',side_effect=AssertionError('no repeated tool calls')): am.analyze(src,out)
            src.write_bytes(b'changed')
            with self.assertRaisesRegex(ValueError,'changed footage'): am.analyze(src,out)

    def test_existing_output_and_bad_input_fail_without_crash(self):
        with tempfile.TemporaryDirectory() as td:
            src=Path(td)/'bad.mp4'; src.write_bytes(b'not a video')
            out=Path(td)/'saved.pcm'; out.write_bytes(b'keep me')
            r=subprocess.run([str(am.S/'decode_audio'),str(src),str(out)],capture_output=True)
            self.assertEqual(r.returncode,2); self.assertEqual(out.read_bytes(),b'keep me')
            out.unlink()
            r=subprocess.run([str(am.S/'decode_audio'),str(src),str(out)],capture_output=True)
            self.assertEqual(r.returncode,2); self.assertFalse(out.exists())

    def test_timeout_stops_and_reports(self):
        with patch.object(am.subprocess,'run',side_effect=subprocess.TimeoutExpired('decode_audio',120)):
            with self.assertRaisesRegex(RuntimeError,'stopped, not retried'): am.run(['decode_audio'],120)


if __name__=='__main__': unittest.main()
