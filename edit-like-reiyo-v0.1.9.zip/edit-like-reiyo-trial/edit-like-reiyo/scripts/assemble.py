"""Build an editable draft from an explicit, source-timed editorial plan.
No content choices or cuts are made here. Required spacing and phrase checks run before assembly.
"""
import argparse,copy,json,math,pathlib,re,uuid,wave,sys
from media_settings import frame_settings, plan_fps
from decision_trace import write_trace
from breath_review import require_review as require_breath_review, check_native as check_native_breaths, output_record, check_output_record
from sound_review import check as check_sound_review, require_review
from sound_density import from_plan as check_density, from_native as check_native_density, require_spacing
from caption_phrases import check as check_phrases, require_resolved
from punchline_events import check_plan as check_punchlines, check_native as check_native_punchlines
uid=lambda:str(uuid.uuid4()).upper()
def finite_number(value,label):
 if type(value) not in (int,float) or not math.isfinite(value):raise ValueError(f'{label} must be a finite number, got {value!r}; keep editorial explanations in reason')
def check_spacing_for_scope(plan,report):
 # Requested intermediate drafts do not have a packaging or SFX obligation.
 scope=plan.get('editing_scope')
 if scope in ('breath_only','breath_and_captions','breath_captions_emphasis'):
  excluded=('overlays','sounds','punchline_events')
  if scope!='breath_captions_emphasis':excluded+=('titles','caption_promotions')
  if scope=='breath_only':excluded+=('captions',)
  if any(plan.get(k) for k in excluded):
   raise ValueError(f'{scope} contains packaging outside the requested scope')
  if scope!='breath_captions_emphasis' and any(t.get('keys') or t.get('scale',1)!=1 or t.get('x',0)!=0 or t.get('y',0)!=0 for t in plan['takes']):
   raise ValueError(f'{scope} must preserve the original framing')
  report.update(status='not_applicable',reason=f'User requested {scope}')
 else:require_spacing(report)
 return report
def build(blank,plan,settings=None,require_reviewed_sound=False,pending_preview=False):
 if require_reviewed_sound:require_review(check_sound_review(plan))
 settings=settings or frame_settings(plan)
 plan_fps(plan,settings['fps'])
 breath_result=require_breath_review(plan,final=not pending_preview,pending_preview=pending_preview)
 check_spacing_for_scope(plan,check_density(plan,settings['fps']))
 require_resolved(check_phrases(plan))
 check_punchlines(plan,settings['fps'])
 d=copy.deepcopy(blank);d['materials']={'videos':[],'texts':[],'audios':[]};d['tracks']=[];d['time_marks']={'id':uid(),'mark_items':[]};d['fps']=settings['fps'];d['canvas_config']=plan['canvas'];d['path']=''
 fps=d['fps'];us=lambda x:round(round(x*fps)*1e6/fps)
 def track(typ,name):
  t={'id':uid(),'type':typ,'name':name,'segments':[]};d['tracks'].append(t);return t
 main=track('video','原素材 · 独立选段');overlay=track('video','真实演示 · 可编辑');cap=track('text','短句字幕');front=track('text','重点字');audio=track('audio','音效 · 原素材音量')
 def segment(mat,a,b,layer,src=None,scale=1.,x=0.,y=0.,volume=1.):
  for name,value in [('scale',scale),('x',x),('y',y),('volume',volume)]:finite_number(value,f'segment at {a:.3f}s {name}')
  s={'id':uid(),'material_id':mat,'target_timerange':{'start':us(a),'duration':us(b)-us(a)},'render_timerange':{},'render_index':layer,'track_render_index':layer,'extra_material_refs':[],'enable_lut':False,'enable_adjust':False,'enable_hsl':False,'responsive_layout':{},'source':'segmentsourcenormal','common_keyframes':[]}
  s['clip']={'alpha':1.,'scale':{'x':scale,'y':scale},'transform':{'x':x,'y':y},'flip':{}};s['uniform_scale']={}
  if src is not None:s.update(source_timerange={'start':us(src),'duration':us(b)-us(a)},volume=volume,last_nonzero_volume=volume,speed=1.)
  return s
 def keys(s,prop,pts):
  for t,v in pts:finite_number(v,f'{prop} keyframe at {t}s')
  offset=(s.get('source_timerange')or{}).get('start',0)
  assert all(0<=us(t)<=s['target_timerange']['duration']for t,v in pts)
  s['common_keyframes'].append({'id':uid(),'material_id':'','property_type':prop,'keyframe_list':[{'id':uid(),'time_offset':offset+us(t),'values':[v],'left_control':{'x':0.,'y':0.},'right_control':{'x':0.,'y':0.}}for t,v in pts]})
 vids={}
 def video(source):
  if source in vids:return vids[source]
  m=plan['sources'][source];path=pathlib.Path(m['path']).resolve();assert path.is_file(),path
  v={'id':uid(),'type':m.get('type','video'),'path':str(path),'duration':us(m['duration']),'width':m['width'],'height':m['height'],'material_name':path.name,'category_name':'local','crop':{},'stable':{'time_range':{}},'matting':{'path':''},'video_algorithm':{'path':''}}
  d['materials']['videos'].append(v);vids[source]=v['id'];return v['id']
 mapping=[];cursor=0
 for take in plan['takes']:
  a,b=take['start'],take['end'];assert 0<=a<b<=plan['sources'][take['source']]['duration']+.05
  length=(us(b)-us(a))/1e6;s=segment(video(take['source']),cursor,cursor+length,0,a,take.get('scale',1.),take.get('x',0.),take.get('y',0.),take.get('volume',1.))
  for prop,pts in take.get('keys',{}).items():keys(s,prop,pts)
  main['segments'].append(s);mapping.append({'source':take['source'],'start':us(a)/1e6,'end':us(b)/1e6,'at':cursor,'duration':length});cursor=round(cursor+length,6)
 d['duration']=us(cursor)
 font=plan.get('font')
 if not font and sys.platform=='darwin':font='/Applications/VideoFusion-macOS.app/Contents/Resources/Font/SystemFont/zh-hans.ttf'
 if not font or not pathlib.Path(font).is_file():raise ValueError('Set plan.font to an existing Chinese font on this computer; preflight.py lists candidates')
 def text(tx,a,b,tr,size=7,color='#FFFFFF',x=0,y=-.72,bg=False,fontpath=None,native_shadow=False):
  a=max(0,a);b=min(cursor,b)
  if us(b)<=us(a):return
  fp=fontpath or font;assert pathlib.Path(fp).is_file()
  fill={'alpha':1.,'content':{'render_type':'solid','solid':{'alpha':1.,'color':[int(color[i:i+2],16)/255 for i in (1,3,5)]}}}
  content=json.dumps({'text':tx,'styles':[{'range':[0,len(tx)],'size':size,'font':{'id':'','path':fp},'fill':fill,'strokes':[]}]},ensure_ascii=False,separators=(',',':'))
  m={'id':uid(),'type':'subtitle','content':content,'base_content':content,'font_size':size,'font_path':fp,'text_color':color,'initial_scale':1.,'line_spacing':.02,'words':{},'current_words':{},'combo_info':{},'caption_template_info':{'resource_id':'','path':''},'subtitle_keywords':{},'lyrics_template':{'resource_id':'','path':''},'add_type':1,'check_flag':23 if bg else 7,'shadow_alpha':0.,'background_color':bg if isinstance(bg,str) else ('#FFFFFF'if bg else '#000000'),'background_alpha':1. if bg else 0.,'background_style':1 if bg else 0,'background_round_radius':.12,'background_width':.13,'background_height':.10}
  if native_shadow:
   # Native text shadow, verified from a saved Jianying text; no duplicate glyph layer.
   obj=json.loads(content)
   obj['styles'][0]['shadows']=[{'content':{'render_type':'solid','solid':{'color':[36/255,52/255,90/255]}},'alpha':.9,'diffuse':.025,'distance':5.,'angle':-45.,'thickness_projection_enable':False,'thickness_projection_distance':0.,'thickness_projection_angle':-45.}]
   content=json.dumps(obj,ensure_ascii=False,separators=(',',':'))
   m.update(content=content,base_content=content,has_shadow=True,shadow_color='#24345A',shadow_alpha=.9,shadow_smoothing=.45,shadow_distance=5.,shadow_angle=-45.,shadow_point={'x':.6363961030678928,'y':-.6363961030678927},check_flag=m['check_flag']|32)
  d['materials']['texts'].append(m);s=segment(m['id'],a,b,d['tracks'].index(tr),x=x,y=y);tr['segments'].append(s);return s
 caption_style=plan.get('caption_style',{})
 if plan['canvas']['height']>plan['canvas']['width'] and caption_style.get('y',-.31)<-.52:raise ValueError('Portrait captions enter the lower interface area; inspect safe placement first')
 caption_lanes={0:cap}
 for c in plan.get('captions',[]):
  lane=c.get('lane',0)
  if lane not in caption_lanes:caption_lanes[lane]=track('text',f'短句累积 {lane}')
  y=c.get('y',caption_style.get('y',-.31))
  if plan['canvas']['height']>plan['canvas']['width'] and y<-.52:raise ValueError('Caption block below safe reading area')
  text(c['text'],c['start'],c['end'],caption_lanes[lane],c.get('size',caption_style.get('size',7)),c.get('color',caption_style.get('color','#24345A')),x=c.get('x',caption_style.get('x',0)),y=y,bg=c.get('background',caption_style.get('background',True)))
 title_lanes={0:front}
 for c in plan.get('titles',[]):
  lane=c.get('lane',0)
  if lane not in title_lanes:title_lanes[lane]=track('text',f'关系字 {lane}')
  tr=title_lanes[lane]
  s=text(c['text'],c['start'],c['end'],tr,c.get('size',18),c.get('color','#FFE15D'),c.get('x',0),c.get('y',.70),fontpath=plan.get('title_font',font),bg=c.get('background',False),native_shadow=c.get('shadow',True))
  if s:s['render_index']=100+d['tracks'].index(tr);s['track_render_index']=s['render_index']
  if s and c.get('keys'):
   for prop,pts in c['keys'].items():keys(s,prop,pts)
  elif s and c.get('pop',True) and c['end']-c['start']>.25:
   for ax in ['X','Y']:keys(s,'KFTypeScale'+ax,[(0,.88),(.1,1.035),(.2,1.)])
 overlay_lanes={0:overlay}
 for o in plan.get('overlays',[]):
  lane=o.get('lane',0)
  if lane not in overlay_lanes:overlay_lanes[lane]=track('video',f'图形演示 {lane}')
  tr=overlay_lanes[lane]
  s=segment(video(o['source']),o['start'],o['end'],d['tracks'].index(tr),o.get('source_start',0),o.get('scale',.8),o.get('x',0),o.get('y',.3),o.get('volume',0))
  for prop,pts in o.get('keys',{}).items():keys(s,prop,pts)
  s['render_index']=o.get('layer',10);s['track_render_index']=s['render_index']
  tr['segments'].append(s)
 for cue in plan.get('sounds',[]):
  path=pathlib.Path(cue['path']).resolve();assert path.is_file()
  with wave.open(str(path))as w:dur=w.getnframes()/w.getframerate()
  mat={'id':uid(),'type':cue.get('kind','sound'),'name':path.stem,'duration':round(dur*1e6),'path':str(path),'resource_id':'','similiar_music_info':{},'tts_benefit_info':{'benefit_type':'none'}};d['materials']['audios'].append(mat)
  a=cue['start'];src=cue.get('source_start',0);length=cue.get('duration',dur-src)
  assert 0<=src<dur and 0<length<=dur-src+.04
  b=min(cursor,a+length);s=segment(mat['id'],a,b,5,src,volume=0 if cue.get('muted')else cue.get('volume',1.));s.pop('clip');audio['segments'].append(s)
 for tr in caption_lanes.values():
  for seg in tr['segments']:seg['render_index']=500;seg['track_render_index']=500
 # Jianying also derives free-layer ordering from track order. Keep both representations consistent.
 d['tracks']=[t for t in d['tracks'] if t['segments']]
 d['tracks'].sort(key=lambda t:max(s.get('render_index',0) for s in t['segments']) if t['type']!='audio' else 1000)
 for layer,t in enumerate(d['tracks']):
  for seg in t['segments']:seg['render_index']=layer;seg['track_render_index']=layer
 for t in d['tracks']:
  t['segments'].sort(key=lambda s:s['target_timerange']['start'])
  for s in t['segments']:
   r=s['target_timerange'];assert r['duration']>0 and 0<=r['start']<r['start']+r['duration']<=d['duration']+1
  if t is not audio:
   for a,b in zip(t['segments'],t['segments'][1:]):assert a['target_timerange']['start']+a['target_timerange']['duration']<=b['target_timerange']['start']+1,t['name']
 check_spacing_for_scope(plan,check_native_density(d))
 check_native_punchlines(plan,d)
 check_native_breaths(plan,d)
 d['reiyo_breath_review']=output_record(breath_result,pending_preview,d)
 if pending_preview:d['tracks'][0]['name']='待审预览 · 气口未验收'
 check_output_record(d,breath_result,pending_preview,external=d['reiyo_breath_review'])
 return d,mapping
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('blank');p.add_argument('plan');p.add_argument('output');p.add_argument('--require-reviewed-sound',action='store_true');p.add_argument('--pending-preview',action='store_true');a=p.parse_args()
 if pathlib.Path(a.output+'.breath-review.json').exists():raise ValueError('Use a new output name; preserve the existing external review record')
 plan=json.loads(pathlib.Path(a.plan).read_text(encoding='utf-8'));settings=frame_settings(plan)
 write_trace(plan,a.output+'.decision-trace.json',pathlib.Path(a.plan).parent)
 sound_report=check_sound_review(plan)
 pathlib.Path(a.output+'.sound-review.json').write_text(json.dumps(sound_report,ensure_ascii=False,indent=2),encoding='utf-8')
 density_report=check_spacing_for_scope(plan,check_density(plan,settings['fps']));phrase_report=check_phrases(plan)
 pathlib.Path(a.output+'.sound-density.json').write_text(json.dumps(density_report,ensure_ascii=False,indent=2),encoding='utf-8')
 pathlib.Path(a.output+'.caption-phrases.json').write_text(json.dumps(phrase_report,ensure_ascii=False,indent=2),encoding='utf-8')
 require_resolved(phrase_report)
 if a.require_reviewed_sound:require_review(sound_report)
 d,m=build(json.loads(pathlib.Path(a.blank).read_text(encoding='utf-8')),plan,settings,pending_preview=a.pending_preview)
 pathlib.Path(a.output+'.punchline-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
 pathlib.Path(a.output+'.punchlines.json').write_text(json.dumps(check_native_punchlines(plan,d),ensure_ascii=False,indent=2),encoding='utf-8')
 pathlib.Path(a.output).write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
 pathlib.Path(a.output+'.breath-review.json').write_text(json.dumps(d['reiyo_breath_review'],ensure_ascii=False,indent=2),encoding='utf-8')
 pathlib.Path(a.output+'.mapping.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
 pathlib.Path(a.output+'.settings.json').write_text(json.dumps(settings,ensure_ascii=False,indent=2),encoding='utf-8')
 pathlib.Path(a.output+'.native-sound-density.json').write_text(json.dumps(check_spacing_for_scope(plan,check_native_density(d)),ensure_ascii=False,indent=2),encoding='utf-8')
 print('seconds',d['duration']/1e6,'tracks',len(d['tracks']),'fps',d['fps'])
 print('sound review:',sound_report['status'],'(record check only; not aesthetic approval)')

 if a.pending_preview:print('待审预览：保留未决记录，未正式验收；请正常速度播放后继续处理。')
