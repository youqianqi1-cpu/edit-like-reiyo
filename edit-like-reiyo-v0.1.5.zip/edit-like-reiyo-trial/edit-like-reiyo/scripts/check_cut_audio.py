"""Assemble analysis-only PCM from the exact source ranges, then transcribe it.
This is an automated speech comparison, not a claim of human listening.
"""
import argparse,json,pathlib,wave,subprocess,sys
S=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('plan',type=pathlib.Path);p.add_argument('analysis_root',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);a=p.parse_args();plan=json.loads(a.plan.read_text(encoding='utf-8'));a.output.mkdir(parents=True,exist_ok=True);cache={};fps=plan.get('fps',30)
with wave.open(str(a.output/'cut-check.wav'),'wb')as out:
 out.setparams((1,2,16000,0,'NONE','not compressed'))
 for r in plan['takes']:
  if r['source']not in cache:cache[r['source']]=(a.analysis_root/r['source']/'audio.pcm').read_bytes()
  start=round(round(r['start']*fps)/fps*16000);end=round(round(r['end']*fps)/fps*16000);out.writeframes(cache[r['source']][start*2:end*2])
if sys.platform=='win32':
 from portable_media import transcribe
 transcribe(a.output/'cut-check.wav',a.output/'words.jsonl')
else:
 from analyze_media import run, fallback, read_words
 target=a.output/'words.jsonl'
 try:
  target.write_text(run([S/'transcribe_words',a.output/'cut-check.wav'],300),encoding='utf-8'); read_words(target)
 except (OSError,ValueError,RuntimeError): fallback('transcribe',a.output/'cut-check.wav',target)
w=[json.loads(x)for x in(a.output/'words.jsonl').read_text(encoding='utf-8').splitlines()];(a.output/'transcript.txt').write_text(''.join(x['text']for x in w), encoding='utf-8');print(a.output/'transcript.txt')
