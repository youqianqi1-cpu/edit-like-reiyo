"""Read either native draft layout; write only a named closed draft after round-trip."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

S=Path(__file__).resolve().parent
F='/Applications/VideoFusion-macOS.app/Contents/Frameworks'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write_json(p,d): p.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')),encoding='utf-8')

def files(folder):
    folder=Path(folder)
    mains=[folder/n for n in ('draft_info.json','draft_content.json') if (folder/n).is_file()]
    if len(mains)!=1: raise ValueError('Expected exactly one active draft_info.json or draft_content.json; do not guess')
    timelines=sorted((folder/'Timelines').glob('*/*')) if (folder/'Timelines').exists() else []
    timelines=[p for p in timelines if p.name in ('draft_info.json','draft_content.json') and p.is_file()]
    if len(timelines)>1: raise ValueError('Use a new single-timeline draft; multiple timelines are protected')
    return [*mains,*timelines]

def decode(path,folder):
    raw=path.read_bytes()
    try: value=json.loads(raw.decode('utf-8-sig'))
    except (UnicodeDecodeError,json.JSONDecodeError):
        r=subprocess.run([str(S/'jycat'),str(path),str(folder)],env={**os.environ,'DYLD_FRAMEWORK_PATH':F},
                         capture_output=True,text=True,check=True,timeout=30)
        value=json.loads(r.stdout[r.stdout.index('{'):])
    if not isinstance(value,dict) or not value.get('id'): raise ValueError('Invalid draft identity')
    return value

def read(folder): return decode(files(folder)[0],folder)

def prepare(folder,candidate):
    targets=files(folder); before={p:p.read_bytes() for p in targets}
    old=decode(targets[0],folder); new=json.loads(Path(candidate).read_text(encoding='utf-8'))
    if old.get('id')!=new.get('id'): raise ValueError('Candidate belongs to a different native draft')
    for target in targets:
        if decode(target,folder).get('id')!=old['id']: raise ValueError('Timeline identity differs; do not guess')
    serialized=json.dumps(new,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    prepared={}
    for target,raw in before.items():
        try:
            json.loads(raw.decode('utf-8-sig')); prepared[target]=serialized
        except (UnicodeDecodeError,json.JSONDecodeError):
            # Adapt the filename only inside a disposable copy, never in the user's draft.
            with tempfile.TemporaryDirectory(prefix='reiyo-codec-') as tmp:
                staging=Path(tmp)/'draft'; shutil.copytree(folder,staging)
                for name in ('draft_info.json','draft_content.json'): (staging/name).unlink(missing_ok=True)
                (staging/'draft_info.json').write_bytes(raw)
                normalized=Path(tmp)/'candidate.json'; normalized.write_bytes(serialized)
                r=subprocess.run([str(S/'jywrite_verify.sh'),str(normalized),str(staging)],
                                  capture_output=True,text=True,check=True,timeout=60)
                receipt=dict(x.split('=',1) for x in r.stdout.splitlines() if '=' in x)
                if receipt.get('ROUNDTRIP_OK')!='true': raise ValueError('Native round-trip failed')
                lab=Path(receipt['LAB']); prepared[target]=(lab/'draft/draft_info.json').read_bytes()
                # Helper creates only this disposable sandbox; leave the original unchanged.
                if lab.name.startswith('jy-writer.') and lab.parent.resolve()==Path('/tmp').resolve(): shutil.rmtree(lab)
        with tempfile.TemporaryDirectory(prefix='reiyo-readback-') as tmp:
            p=Path(tmp)/target.name; p.write_bytes(prepared[target])
            if decode(p,Path(tmp))!=new: raise ValueError('Prepared draft differs after readback')
    if any(p.read_bytes()!=raw for p,raw in before.items()): raise ValueError('Draft changed during verification')
    return before,prepared,new

def check(folder):
    """Probe the real codec on a temporary copy before any editing; no target write."""
    with tempfile.TemporaryDirectory(prefix='reiyo-draft-check-') as tmp:
        candidate=Path(tmp)/'same.json'; write_json(candidate,read(folder))
        before,_,_=prepare(folder,candidate)
    return {'draft_read_write_ready':True,'files':[p.name for p in before],
            'sha256':sha(files(folder)[0]),'target_unchanged':True,'ui_reopen_verified':False}

def install(folder,candidate,expect,name,closed):
    folder=Path(folder).resolve()
    if not closed or folder.name!=name or sha(files(folder)[0])!=expect:
        raise ValueError('Target identity, closed state, or fingerprint mismatch')
    before,prepared,new=prepare(folder,candidate)
    if sha(files(folder)[0])!=expect: raise ValueError('Source changed after verification')
    backup=Path(tempfile.mkdtemp(prefix='reiyo-before-install-'))
    for i,(p,raw) in enumerate(before.items()): (backup/f'{i}.json').write_bytes(raw)
    try:
        for target,raw in prepared.items():
            tmp=target.with_name(target.name+'.reiyo-tmp'); tmp.write_bytes(raw); os.replace(tmp,target)
        if any(decode(p,folder)!=new for p in before): raise ValueError('Installed draft differs from candidate')
    except BaseException:
        for p,raw in before.items(): p.write_bytes(raw)
        raise
    finally:
        for p in before: p.with_name(p.name+'.reiyo-tmp').unlink(missing_ok=True)
    return {'saved':True,'target':str(folder),'backup':str(backup),'ui_reopen_verified':False}

if __name__=='__main__':
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='cmd',required=True)
    for name in ['read','check']:
        r=sub.add_parser(name); r.add_argument('draft',type=Path); r.add_argument('out',type=Path)
    w=sub.add_parser('install'); w.add_argument('draft',type=Path); w.add_argument('candidate',type=Path)
    w.add_argument('--expected-sha',required=True); w.add_argument('--exact-name',required=True)
    w.add_argument('--closed',action='store_true'); w.add_argument('--receipt',type=Path,required=True)
    a=p.parse_args()
    if a.cmd=='read': write_json(a.out,read(a.draft)); print(sha(files(a.draft)[0]))
    elif a.cmd=='check': write_json(a.out,check(a.draft)); print(a.out)
    else: write_json(a.receipt,install(a.draft,a.candidate,a.expected_sha,a.exact_name,a.closed)); print(a.receipt)
