import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import draft_io
import analyze_media as am

class DraftTests(unittest.TestCase):
    def test_both_names_and_rollback(self):
        for name in ['draft_content.json','draft_info.json']:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as d:
                root=Path(d)/'new'; root.mkdir(); f=root/name
                old={'id':'trial','tracks':[]}; f.write_text(json.dumps(old)); before=f.read_bytes()
                self.assertTrue(draft_io.check(root)['target_unchanged']); self.assertEqual(f.read_bytes(),before)
                candidate=Path(d)/'candidate.json'; new={**old,'duration':100}; candidate.write_text(json.dumps(new))
                draft_io.install(root,candidate,draft_io.sha(f),'new',True)
                self.assertEqual(draft_io.read(root),new)
                self.assertEqual([p.name for p in root.iterdir()],[name])
                with self.assertRaises(ValueError): draft_io.install(root,candidate,'bad','new',True)
                candidate.write_text(json.dumps({'id':'another'}))
                with self.assertRaises(ValueError): draft_io.install(root,candidate,draft_io.sha(f),'new',True)
    def test_ambiguous_layout_is_not_guessed(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for n in ['draft_info.json','draft_content.json']: (root/n).write_text('{}')
            with self.assertRaises(ValueError): draft_io.files(root)
    def test_rollback_when_second_write_fails(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'new'; root.mkdir(); timeline=root/'Timelines/t'; timeline.mkdir(parents=True)
            before={p:json.dumps({'id':'same','tracks':[]}).encode() for p in [root/'draft_info.json',timeline/'draft_info.json']}
            for p,b in before.items(): p.write_bytes(b)
            c=Path(d)/'candidate'; c.write_text('{"id":"same","tracks":[],"duration":42}')
            real=draft_io.os.replace; calls=[]
            def fail_second(a,b):
                calls.append(b)
                if len(calls)==2: raise OSError('simulated write failure')
                return real(a,b)
            with patch.object(draft_io.os,'replace',fail_second),self.assertRaises(OSError):
                draft_io.install(root,c,draft_io.sha(root/'draft_info.json'),'new',True)
            self.assertTrue(all(p.read_bytes()==b for p,b in before.items()))

class FallbackTests(unittest.TestCase):
    def test_fallback_results_are_cached_and_source_preserved(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); src=root/'source'; src.write_bytes(b'fixture'); calls=[]
            def native(args, timeout):
                if Path(args[0]).name=='media_probe': return json.dumps({'duration':1,'probe_schema':2})
                raise RuntimeError('simulated student AVFoundation failure')
            def portable(command,source,target,info=None):
                calls.append(command)
                if command=='levels': target.write_text('{"channels":[],"windows":[]}')
                elif command=='decode': target.write_bytes(bytes(32000))
                elif command=='transcribe': target.write_text('{"text":"测试","start":0.2,"duration":0.4}\n')
            with patch.object(am,'run',native),patch.object(am,'fallback',portable):
                r=am.analyze(src,root/'out')
            self.assertEqual(calls,['levels','decode','transcribe'])
            self.assertEqual(r['backends']['transcribe_words'],'portable-local')
            with patch.object(am,'run',side_effect=AssertionError('must reuse')),patch.object(am,'fallback',side_effect=AssertionError('must reuse')):
                am.analyze(src,root/'out')
            self.assertEqual(src.read_bytes(),b'fixture')
    def test_both_fail_stop_at_actual_step(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); src=root/'src'; src.write_bytes(b'fixture')
            with patch.object(am,'run',side_effect=RuntimeError('native failed')),patch.object(am,'fallback',side_effect=RuntimeError('portable failed')):
                with self.assertRaisesRegex(RuntimeError,'probe'): am.analyze(src,root/'out')
            fail=json.loads((root/'out/failure.json').read_text()); self.assertEqual(fail['stage'],'probe')

if __name__=='__main__': unittest.main()
