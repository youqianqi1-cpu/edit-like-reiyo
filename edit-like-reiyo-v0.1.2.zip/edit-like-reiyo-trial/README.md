# 剪出帧我 · Edit like Reiyo

免费试用版 v0.1.2。新增 Reiyo 剪映收藏中 38 项音效的查找线索与选用方法。没有同款收藏时，由 Codex 在使用者自己的剪映公开音效库查找、下载并添加；需要当前环境具备电脑操作能力。

两款字体继续随包提供。旧版 18 个公开短音效仅作为用户明确选择后的备选，不冒充 Reiyo 的收藏。原有气口、字幕、节奏与判断规则保持不变。

安装或更新：把 https://github.com/youqianqi1-cpu/edit-like-reiyo 发给 Codex，请它按主页说明安装，并保留自定义内容。安装后的下一轮告诉它：“用剪出帧我剪这条视频，新建草稿，原来的别动。”

完整 Skill 是 edit-like-reiyo 文件夹，保留 references、scripts、assets。音效检索说明见 references/reiyo-favorite-sounds.md；字体及旧版可选资源见 assets/starter/preview.html。

已验证 Mac 原账号公开搜索到五种候选并加入独立试音草稿，包含两次下载后添加；保存重开成功。本次未验证新账号、Windows，也未验收这些声音与成片的配合。部分声音有同名歧义或不可商用限制，按具体条目处理。
