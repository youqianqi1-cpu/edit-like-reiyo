"""Local input preparation, with resumable verified stages. No cuts are decided here."""
import argparse
import hashlib
import json
import math
import pathlib
import subprocess
import sys
import time
import wave

S = pathlib.Path(__file__).resolve().parent


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    tmp = path.with_suffix('.writing')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def run(args, timeout):
    try:
        result = subprocess.run([str(x) for x in args], capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(f'{pathlib.Path(args[0]).name} exceeded {timeout}s; stopped, not retried') from e
    if result.returncode:
        raise RuntimeError(f'{pathlib.Path(args[0]).name} exited {result.returncode}: {result.stderr[-6000:]}')
    return result.stdout


def read_words(path):
    rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]
    if not rows or any(not isinstance(r.get('text'), str) or not r['text'].strip() or
                       not isinstance(r.get('start'), (int, float)) or not math.isfinite(r['start']) or r['start'] < 0
                       for r in rows):
        raise ValueError('No valid timed speech; do not create empty captions')
    return rows


def analyze(source, output):
    src, output = source.resolve(), output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    fingerprint = {'source': str(src), 'source_size': src.stat().st_size, 'source_mtime_ns': src.stat().st_mtime_ns}
    progress_path = output/'progress.json'
    if progress_path.exists():
        progress = json.loads(progress_path.read_text(encoding='utf-8'))
        if progress.get('input') != fingerprint:
            raise ValueError('This folder belongs to different or changed footage. Use a fresh analysis folder.')
    else:
        if any(output.iterdir()):
            raise ValueError('Old or unverified partial analysis. Preserve it and use a fresh analysis folder; do not rebuild tools.')
        progress = {'input': fingerprint, 'completed': {}}
        save(progress_path, progress)
    started = time.monotonic()
    stage = 'probe'

    def ready(name):
        path = output/name
        expected = progress['completed'].get(name)
        return expected is not None and path.is_file() and digest(path) == expected

    def complete(name):
        progress['completed'][name] = digest(output/name)
        save(progress_path, progress)
        print(f'Completed {name}', flush=True)

    try:
        if not ready('source.json'):
            info = json.loads(run([S/'media_probe', src], 30))
            if not isinstance(info.get('duration'), (int, float)) or not math.isfinite(info['duration']) or info['duration'] <= 0:
                raise ValueError('Source duration could not be read')
            save(output/'source.json', info); complete('source.json')
        info = json.loads((output/'source.json').read_text(encoding='utf-8'))
        stage = 'decode_audio'
        pcm = output/'audio.pcm'
        if not ready('audio.pcm'):
            tmp = output/'audio.pcm.partial'
            # Only our disposable intermediate is cleared; source and drafts are never touched.
            tmp.unlink(missing_ok=True)
            run([S/'decode_audio', src, tmp], 120)
            if not tmp.is_file() or tmp.stat().st_size != math.ceil(info['duration']*16000)*2:
                raise ValueError('Decoded audio length does not match the original timeline')
            tmp.replace(pcm); complete('audio.pcm')
            progress['completed'].pop('audio.wav', None); progress['completed'].pop('words.jsonl', None)
            save(progress_path, progress)
        stage = 'make_wav'
        wav = output/'audio.wav'
        if not ready('audio.wav'):
            tmp = output/'audio.wav.partial'
            with wave.open(str(tmp), 'wb') as f:
                f.setparams((1, 2, 16000, 0, 'NONE', 'not compressed'))
                with pcm.open('rb') as raw:
                    for data in iter(lambda: raw.read(1024*1024), b''): f.writeframesraw(data)
            tmp.replace(wav); complete('audio.wav')
        stage = 'transcribe_words'
        words = output/'words.jsonl'
        if not ready('words.jsonl'):
            tmp = output/'words.partial'
            tmp.write_text(run([S/'transcribe_words', wav], 600), encoding='utf-8')
            read_words(tmp)
            tmp.replace(words); complete('words.jsonl')
        rows = read_words(words)
        paragraphs, bucket, begin = [], [], 0
        for word in rows:
            if not bucket: begin = word['start']
            bucket.append(word['text'])
            if word['start']-begin > 12:
                paragraphs.append(f'[{begin:.2f}] '+''.join(bucket)); bucket=[]
        if bucket: paragraphs.append(f'[{begin:.2f}] '+''.join(bucket))
        (output/'transcript.txt').write_text('\n'.join(paragraphs), encoding='utf-8')
        receipt = dict(fingerprint, elapsed=time.monotonic()-started, words=len(rows), last_word=rows[-1], listened=False)
        save(output/'receipt.json', receipt)
        (output/'failure.json').unlink(missing_ok=True)
        print(json.dumps(receipt, ensure_ascii=False))
        return receipt
    except (OSError, ValueError, RuntimeError) as e:
        save(output/'failure.json', dict(stage=stage, error=str(e), completed=list(progress['completed']),
                                         next='Stop this attempt. Do not rebuild all tools or change the draft. Resume only after addressing this stage.'))
        raise RuntimeError(f'Preparation stopped at {stage}: {e}. See {output / "failure.json"}') from e


if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('source', type=pathlib.Path); p.add_argument('output', type=pathlib.Path)
    a=p.parse_args()
    if sys.platform == 'win32':
        from portable_media import analyze as windows_analyze
        windows_analyze(a.source, a.output)
    else:
        try: analyze(a.source, a.output)
        except (OSError, ValueError, RuntimeError) as e: p.exit(2, str(e)+'\n')
