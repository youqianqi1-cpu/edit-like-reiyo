#!/bin/zsh
set -euo pipefail
script_dir=${0:A:h}
[[ $(uname -s) == Darwin ]] || { echo 'This execution route currently supports macOS only.' >&2; exit 2; }
# Rebuild only the failed tool when requested; audio decoding does not use Swift.
mode=${1:-all}
[[ "$mode" == all || "$mode" == decode_audio ]] || { echo 'Usage: prepare.sh [decode_audio]' >&2; exit 2; }
xcrun clang -fobjc-arc -O2 -Wno-deprecated-declarations -mmacosx-version-min=13.0 \
  -framework Foundation -framework AVFoundation -framework CoreMedia -framework AudioToolbox \
  "$script_dir/decode_audio.m" -o "$script_dir/decode_audio.new"
mv "$script_dir/decode_audio.new" "$script_dir/decode_audio"
[[ "$mode" == decode_audio ]] && exit 0
[[ -d /Applications/VideoFusion-macOS.app ]] || { echo 'Jianying installation not found.' >&2; exit 2; }
"$script_dir/build_jytools.sh"
for name in transcribe_words media_probe; do
 xcrun swiftc -parse-as-library -O "$script_dir/$name.swift" -o "$script_dir/$name.new"
 mv "$script_dir/$name.new" "$script_dir/$name"
done
xcrun swiftc -O "$script_dir/extract_frames.swift" -o "$script_dir/extract_frames.new"
mv "$script_dir/extract_frames.new" "$script_dir/extract_frames"
