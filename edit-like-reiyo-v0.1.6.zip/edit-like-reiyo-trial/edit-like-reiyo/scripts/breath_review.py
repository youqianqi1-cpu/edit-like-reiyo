"""Bind per-candidate signal decisions to final source cuts; never infer speech from RMS.
A passed record is not playback approval. Adjacent framing splits preserve the binding.
"""
import hashlib
import json
import math
from pathlib import Path
from media_settings import plan_fps


def cut_rows(plan):
    fps = plan_fps(plan)
    rows = []
    for t in plan['takes']:
        a, b = round(t['start']*fps), round(t['end']*fps)
        if a < 0 or b <= a:
            raise ValueError('Invalid final source cut')
        if rows and rows[-1][0] == t['source'] and rows[-1][2] == a:
            rows[-1][2] = b
        else:
            rows.append([t['source'], a, b])
    return rows


def cut_signature(plan):
    rows = cut_rows(plan)
    paths = {k: str(Path(plan['sources'][k]['path']).resolve()) for k in {r[0] for r in rows}} if 'sources' in plan else {}
    data = {'fps': plan_fps(plan), 'source_ranges_frames': rows, 'source_paths': paths}
    return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()


def candidates(report):
    return [c for t in report['takes'] for c in t['quiet_candidates']] + [j for j in report['joins'] if j['decision'] == 'review_required']


def pending_decisions(report):
    def part(source, a, b):
        return {'source': source, 'start': a, 'end': b, 'disposition': 'uncertain', 'reason': '',
                'evidence': {'source': source, 'start': a, 'end': b, 'scan_signature': report['scan_signature'],
                             'pcm_sha256': report['inputs'][source]['pcm_sha256'], 'kind': 'signal', 'observation': ''}}
    items = [{'id': c['id'], 'action': 'unresolved',
              'segments': [part(c['source'], c['start'], c['end'])] if 'source' in c else []} for c in candidates(report)]
    joins = []
    for j in report['joins']:
        row = {'id': j['id']}
        for side in ('left', 'right'):
            ctx = j[side+'_context']
            row[side] = [part(ctx['source'], r['start'], r['end']) for r in ctx['regions']]
        joins.append(row)
    return {'scan_signature': report['scan_signature'], 'actual_listening': False, 'items': items, 'join_reviews': joins}


def _number(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _coverage(parts, source, start, end, report, allowed):
    """Validate source-bound evidence coverage, not the truth of a human observation."""
    if not isinstance(parts, list) or not parts:
        return False
    cursor = start
    for part in parts:
        a, b = part.get('start'), part.get('end')
        if not _number(a) or not _number(b) or abs(a-cursor)>1e-7 or b<=a or b>end+1e-7:
            return False
        if part.get('source') != source or part.get('disposition') not in allowed or not str(part.get('reason') or '').strip():
            return False
        e = part.get('evidence', {})
        if not isinstance(e, dict): return False
        x, y = e.get('start'), e.get('end')
        if (e.get('source') != source or e.get('scan_signature') != report['scan_signature']
                or e.get('pcm_sha256') != report['inputs'][source]['pcm_sha256']
                or not _number(x) or not _number(y) or x<start-1e-7 or y>end+1e-7 or x>a+1e-7 or y<b-1e-7
                or e.get('kind') not in ('signal', 'listening', 'visual')
                or not str(e.get('observation') or '').strip()):
            return False
        cursor = b
    return abs(cursor-end)<1e-7


def _side_complete(parts, context, report):
    if not _coverage(parts, context['source'], context['start'], context['end'], report,
                     {'weak_speech', 'expressive_pause', 'voiced_context'}): return False
    # A voiced peak must not close the low-energy residual on either side of it.
    for part in parts:
        region = next((r for r in context['regions'] if part['start']>=r['start']-1e-7 and part['end']<=r['end']+1e-7), None)
        if region is None or (region['kind']=='low_energy' and part['disposition']=='voiced_context'):
            return False
    return True


def evaluate(report, decisions):
    if report.get('schema_version') != 3:
        raise ValueError('Rescan with current tool: join-side evidence is missing from the old scan')
    if decisions.get('scan_signature') != report['scan_signature']:
        raise ValueError('Decisions belong to a different signal scan; rescan the FINAL cuts')
    items = decisions.get('items', [])
    ids = [x['id'] for x in items]
    expected = {x['id']: x for x in candidates(report)}
    if len(ids) != len(set(ids)) or set(ids) != set(expected):
        raise ValueError('Each final signal candidate needs exactly one decision; no stale/missing candidates')
    joins = decisions.get('join_reviews', [])
    join_ids = [x['id'] for x in joins]
    if len(join_ids) != len(set(join_ids)) or set(join_ids) != {j['id'] for j in report['joins']}:
        raise ValueError('Every join needs both-side review, including unflagged joins')
    pending = []
    by_join = {x['id']: x for x in joins}
    for join in report['joins']:
        row = by_join[join['id']]
        for side in ('left', 'right'):
            if not _side_complete(row.get(side), join[side+'_context'], report):
                pending.append(join['id']+':'+side)
    for item in items:
        if item.get('action') not in ('keep', 'unresolved'):
            raise ValueError('Apply reviewed cuts first, then rescan; final decisions are keep or unresolved')
        c = expected[item['id']]
        complete = item['action']=='keep'
        if 'source' in c:
            complete = complete and _coverage(item.get('segments'), c['source'], c['start'], c['end'], report,
                                             {'weak_speech', 'expressive_pause'})
        else:
            complete = complete and not any(x.startswith(c['id']+':') for x in pending)
        if not complete: pending.append(item['id'])
    listen = decisions.get('listening') or {}
    listened = (isinstance(listen, dict) and listen.get('scan_signature')==report['scan_signature']
                and listen.get('cut_signature')==report['cut_signature'] and listen.get('scope')=='main_speech'
                and _number(listen.get('speed')) and listen.get('speed')==1 and listen.get('complete') is True
                and bool(str(listen.get('reviewer') or '').strip()) and bool(str(listen.get('note') or '').strip()))
    passed = listened and listen.get('result')=='passed'
    return {'status': 'unresolved' if pending else 'signal_review_complete', 'pending': pending,
            'actual_listening': listened, 'listening_status': 'passed' if passed else ('needs_changes' if listened else 'pending'),
            'formal_accepted': not pending and passed,
            'take_count': len(report['takes']), 'join_count': len(report['joins']),
            'candidate_count': len(expected), 'note': 'Evidence coverage is machine-checked; observations and listening truth require actual review. Acceptance covers main speech only, not the finished mix.'}


def require_review(plan, final=False, pending_preview=False):
    if type(pending_preview) is not bool or (pending_preview and final):
        raise ValueError("Choose either formal acceptance or explicit pending preview")
    ref = plan.get('breath_review')
    if not isinstance(ref, dict) or not ref.get('report') or not ref.get('decisions'):
        raise ValueError('Final breath signal review missing: audit FINAL cuts, decide candidates, attach breath_review')
    report = json.loads(Path(ref['report']).read_text(encoding='utf-8'))
    decisions = json.loads(Path(ref['decisions']).read_text(encoding='utf-8'))
    if report['cut_signature'] != cut_signature(plan):
        raise ValueError('Final cuts/fps changed after breath scan; rescan including protection extensions and new joins')
    # Recompute against retained PCM: a stale report cannot certify different audio or omitted candidates.
    from audit_breaths import audit
    scan_plan = dict(plan, takes=report['scanned_takes'])
    if cut_signature(scan_plan) != cut_signature(plan):
        raise ValueError('Scanned takes do not cover the final plan')
    fresh = audit(scan_plan, report['analysis_root'], report['threshold_is_candidate_only'])
    if fresh != report:
        raise ValueError('Signal report or PCM changed; run a new final scan and decisions')
    if not all(v.get('source_binding_verified') for v in fresh['inputs'].values()):
        raise ValueError('Source analysis receipt missing; verify PCM belongs to this original before final approval')
    result = evaluate(report, decisions)
    if result['pending'] and not pending_preview:
        raise ValueError('Final breath candidates unresolved: '+', '.join(result['pending'][:8]))
    if final and not result['formal_accepted']:
        raise ValueError('Formal breath acceptance pending: normal-speed listening has not passed')
    result.update(scan_signature=report['scan_signature'], cut_signature=report['cut_signature'],
                  decisions_sha256=hashlib.sha256(json.dumps(decisions,sort_keys=True).encode()).hexdigest(),
                  review_files={'report':str(Path(ref['report']).resolve()), 'decisions':str(Path(ref['decisions']).resolve())})
    # Preserve exact unresolved source locations without copying the full RMS report into a draft.
    locations = {c['id']: {'source':c['source'], 'start':c['start'], 'end':c['end']} for t in report['takes'] for c in t['quiet_candidates']}
    for j in report['joins']:
        locations[j['id']] = {side:{k:j[side+'_context'][k] for k in ('source','start','end')} for side in ('left','right')}
        for side in ('left','right'):locations[j['id']+':'+side] = locations[j['id']][side]
    result['pending_locations'] = {key:locations[key] for key in result['pending']}
    return result


def native_binding(draft):
    """Only speech identity/timing/audio. Ignore visual layout and observed native defaults."""
    from media_settings import valid_fps
    fps=valid_fps(draft.get('fps'))
    main=next((t for t in draft.get('tracks',[]) if t.get('type')=='video'),None)
    if not draft.get('id') or not main or not main.get('id'):raise ValueError('Native content/track identity missing')
    materials={v['id']:v for v in draft.get('materials',{}).get('videos',[])}
    refs={v['id']:(kind,v) for kind,items in draft.get('materials',{}).items() for v in items if isinstance(v,dict) and 'id' in v}
    rows=[];cursor=0
    visual={'canvases','placeholder_infos','material_colors'}
    neutral={'speeds':'speed','sound_channel_mappings':'none','vocal_separations':'vocal_separation'}
    for seg in main['segments']:
        src=seg['source_timerange'];dst=seg['target_timerange']
        a=round(src.get('start',0)*fps/1e6);length=round(src['duration']*fps/1e6)
        at=round(dst.get('start',0)*fps/1e6);duration=round(dst['duration']*fps/1e6)
        if at!=cursor or length!=duration or length<=0:raise ValueError('Invalid speech timeline binding')
        audio={'speed':float(seg.get('speed',1)),'volume':float(seg.get('volume',1)), 'refs':[]}
        if not all(math.isfinite(audio[k]) for k in ('speed','volume')):raise ValueError('Invalid speech audio value')
        for ref in seg.get('extra_material_refs',[]):
            if ref not in refs:raise ValueError('Unresolved material reference in main speech')
            kind,value=refs[ref]
            if kind in visual:continue
            payload={k:v for k,v in value.items() if k!='id'}
            if kind in neutral and payload=={'type':neutral[kind]}:continue
            audio['refs'].append([kind,payload])
        audio['refs'].sort(key=lambda x:json.dumps(x,sort_keys=True))
        for k,v in seg.items():
            if k not in ('volume','speed','last_nonzero_volume') and any(word in k for word in ('audio','voice','mute','pitch','sound')):
                audio[k]=v
        audio['keys']=[k for k in seg.get('common_keyframes',[]) if any(w in str(k.get('property_type','')).lower() for w in ('volume','audio','speed'))]
        row=[str(Path(materials[seg['material_id']]['path']).resolve()),a,a+length,at,at+duration,audio]
        if rows and rows[-1][0]==row[0] and rows[-1][2]==a and rows[-1][4]==at and rows[-1][5]==audio:
            rows[-1][2]=a+length;rows[-1][4]=at+duration
        else:rows.append(row)
        cursor+=duration
    if round(draft['duration']*fps/1e6)!=cursor:raise ValueError('Native duration does not cover speech')
    track_audio={k:v for k,v in main.items()if any(w in k.lower()for w in ('audio','voice','mute','pitch','sound','volume','speed'))}
    return {'content_id':draft['id'],'main_track_id':main['id'],'fps':fps,'track_audio':track_audio,
            'speech_rows_sha256':hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest(), 'duration_frames':cursor}


def output_record(result, pending_preview=False, draft=None):
    if type(pending_preview) is not bool:raise ValueError('pending_preview must be an explicit boolean')
    return {'schema_version':2,'binding':native_binding(draft),
            'mode':'pending_preview' if pending_preview else 'formal',
            'formal_breath_accepted':not pending_preview and result.get('formal_accepted') is True,'review':result}


def check_output_record(draft, result, pending_preview=False, external=None):
    if not isinstance(external,dict):raise ValueError('External review record missing; do not infer it from a track label')
    expected=output_record(result,pending_preview,draft)
    base={k:v for k,v in external.items() if k!='installation'}
    if base!=expected:raise ValueError('External review record missing, changed or belongs to another mode/project/cuts')
    # Native saves may drop this hint; if retained, conflicting evidence must not be ignored.
    inline=draft.get('reiyo_breath_review')
    if inline is not None and inline!=expected:raise ValueError('Inline and external review records conflict')
    return expected


def check_native(plan, draft):
    fps = plan_fps(plan, draft.get('fps'))
    videos = {v['id']: v for v in draft.get('materials', {}).get('videos', [])}
    main = next((t for t in draft.get('tracks', []) if t.get('type') == 'video'), None)
    if not main:
        raise ValueError('Main speech track missing')
    path_to_source = {str(Path(v['path']).resolve()): k for k,v in plan['sources'].items()}
    takes = []; cursor = 0
    for s in main['segments']:
        target=s['target_timerange'];src=s['source_timerange']
        at=round(target.get('start',0)/1e6*fps); length=round(target['duration']/1e6*fps)
        if at != cursor or length <= 0 or s.get('speed', 1) != 1:
            raise ValueError('Main track timing differs from final source cut review')
        if round(src['duration']/1e6*fps) != length:
            raise ValueError('Main source duration differs from reviewed cut')
        key=path_to_source[str(Path(videos[s['material_id']]['path']).resolve())]
        a=round(src.get('start',0)/1e6*fps)
        takes.append({'source':key,'start':a/fps,'end':(a+length)/fps});cursor+=length
    if round(draft['duration']/1e6*fps) != cursor or cut_signature(dict(plan,takes=takes)) != cut_signature(plan):
        raise ValueError('Native main track differs from reviewed final cuts')
    return {'source_cuts_match':True,'actual_listening':False}


if __name__ == '__main__':
    raise SystemExit('Use draft_io.py verify DRAFT --plan PLAN --review REVIEW [--pending-preview], or the Windows verify command. Formal acceptance must read the actual saved project and committed external record.')
