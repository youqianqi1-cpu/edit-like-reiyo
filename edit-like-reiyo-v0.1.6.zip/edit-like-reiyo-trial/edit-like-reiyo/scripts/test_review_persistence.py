"""Synthetic persistence and failure injection; no real listening or app playback claims."""
import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import draft_io,draft_windows,review_storage as storage
from assemble import build
from breath_review import pending_decisions,native_binding
from test_final_breaths import FinalSignalTests
from test_external_fixtures import metadata,review


class PersistenceTests(unittest.TestCase):
 setUp=FinalSignalTests.setUp
 bind=FinalSignalTests.bind
 def install_fixture(self,formal=False,windows=False):
  r,d=self.bind()
  if formal:
   d['listening']={'scope':'main_speech','scan_signature':r['scan_signature'],'cut_signature':r['cut_signature'],
                  'speed':1,'complete':True,'reviewer':'synthetic test','note':'not real listening','result':'passed'}
  else:d=pending_decisions(r)
  Path(self.plan['breath_review']['decisions']).write_text(json.dumps(d))
  self.native=build({'id':'unit'},self.plan,settings={'fps':24},pending_preview=not formal)[0]
  self.target=self.root/'target';self.target.mkdir();metadata(self.target)
  self.active=self.target/'draft_info.json'
  self.timeline=self.target/'Timelines'/'single'/'draft_content.json';self.timeline.parent.mkdir(parents=True)
  for p in (self.active,self.timeline):p.write_text('{"id":"unit","tracks":[]}')
  self.candidate=self.root/'candidate.json';self.candidate.write_text(json.dumps(self.native));review(self.candidate)
  self.external=Path(str(self.candidate)+'.breath-review.json')
  if windows:
   class Codec:
    def encode(self,value):return b'test:'+value.encode()
    def decode(self,value):return json.loads(value.removeprefix(b'test:'))
   self.codec=Codec()
   draft_windows.initialize(self.target,self.target.name,self.codec,True)
   draft_windows.install(self.target,self.candidate,draft_windows.digest(self.active),self.target.name,True,self.codec,self.plan,pending_preview=not formal)
  else:draft_io.install(self.target,self.candidate,draft_io.sha(self.active),self.target.name,True,self.plan,pending_preview=not formal)
 def verify(self,formal=False):
  return draft_io.verify(self.target,self.plan,self.external,pending_preview=not formal)
 def native_save(self):
  for p in (self.active,self.timeline):
   d=json.loads(p.read_text());d.pop('reiyo_breath_review');d['fps']=24.0;d['duration']-=1
   for s in d['tracks'][0]['segments']:
    for k in ('speed','volume','last_nonzero_volume','common_keyframes'):s.pop(k,None)
    for k in ('source_timerange','target_timerange'):
     if s[k].get('start')==0:s[k].pop('start')
   p.write_text(json.dumps(d))
 def test_native_save_drop_inline_defaults_and_one_us_preserves_pending(self):
  self.install_fixture();before=json.loads(self.external.read_text())
  self.native_save();result=self.verify()
  self.assertTrue(result['native_persistence_verified']);self.assertFalse(result['formal_breath_accepted'])
  self.assertFalse(result['ui_reopen_verified']);self.assertEqual(json.loads(self.external.read_text()),before)
  self.assertEqual(result['breath_review']['pending'],before['review']['pending'])
 def test_formal_native_save_keeps_synthetic_listening_record(self):
  self.install_fixture(formal=True);self.native_save()
  self.assertTrue(self.verify(formal=True)['formal_breath_accepted'])
 def test_missing_or_uncommitted_external_cannot_fall_back_to_inline(self):
  self.install_fixture();raw=self.external.read_bytes();self.external.unlink()
  with self.assertRaisesRegex(ValueError,'missing'):self.verify()
  d=json.loads(raw);d.pop('installation');self.external.write_text(json.dumps(d))
  with self.assertRaisesRegex(ValueError,'uncommitted'):self.verify()
 def test_wrong_project_id_and_folder_rejected(self):
  self.install_fixture();mp=self.target.parent/'root_meta_info.json';original=mp.read_bytes()
  m=json.loads(original);m['all_draft_store'][0]['draft_id']='other';mp.write_text(json.dumps(m))
  with self.assertRaisesRegex(ValueError,'another project'):self.verify()
  mp.write_bytes(original);d=json.loads(self.external.read_text());d['installation']['target']['folder']=str(self.root/'other')
  self.external.write_text(json.dumps(d))
  with self.assertRaisesRegex(ValueError,'another project'):self.verify()
 def test_timeline_file_identity_and_every_copy_checked(self):
  self.install_fixture();original=self.timeline.read_bytes()
  d=json.loads(original);d['id']='another-content';self.timeline.write_text(json.dumps(d))
  with self.assertRaises(ValueError):self.verify()
  self.timeline.write_bytes(original);self.timeline.rename(self.timeline.with_name('draft_info.json'))
  with self.assertRaisesRegex(ValueError,'another project'):self.verify()
 def test_main_identity_cuts_fps_and_audio_changes_rejected(self):
  self.install_fixture();original=self.active.read_bytes()
  for change in ('content','track','cut','fps','volume','audio_key','track_mute','material_audio'):
   with self.subTest(change=change):
    d=json.loads(original);s=d['tracks'][0]['segments'][0]
    if change=='content':d['id']='other'
    elif change=='track':d['tracks'][0]['id']='other'
    elif change=='cut':s['source_timerange']['start']+=41667
    elif change=='fps':d['fps']=30
    elif change=='volume':s['volume']=.5
    elif change=='audio_key':s['common_keyframes']=[{'property_type':'KFTypeVolume','value':.5}]
    elif change=='track_mute':d['tracks'][0]['is_muted']=True
    else:
     d['materials']['speeds']=[{'id':'audio-speed','type':'speed','speed':.5}]
     s['extra_material_refs']=['audio-speed']
    self.active.write_text(json.dumps(d))
    with self.assertRaises(ValueError):self.verify()
  self.active.write_bytes(original)
 def test_native_default_refs_and_visual_only_changes_are_neutral(self):
  self.install_fixture();original=native_binding(self.native)
  d=copy.deepcopy(self.native);s=d['tracks'][0]['segments'][0]
  kinds={'canvases':'canvas_color','placeholder_infos':'placeholder_info','material_colors':None,
         'speeds':'speed','sound_channel_mappings':'none','vocal_separations':'vocal_separation'}
  for kind,typ in kinds.items():
   item={'id':'ref-'+kind}
   if typ:item['type']=typ
   d['materials'][kind]=[item];s.setdefault('extra_material_refs',[]).append(item['id'])
  s['clip']={'scale':{'x':1.3,'y':1.3}}
  self.assertEqual(native_binding(d),original)
  for p in (self.active,self.timeline):p.write_text(json.dumps(d))
  self.assertTrue(self.verify()['native_persistence_verified'])
 def test_contiguous_visual_split_preserves_review(self):
  self.install_fixture();d=copy.deepcopy(self.native);segments=d['tracks'][0]['segments']
  left=copy.deepcopy(segments[0]);right=copy.deepcopy(left);right['id']='visual-split'
  for key in ('source_timerange','target_timerange'):
   left[key]['duration']=500000
   right[key]['start']=left[key].get('start',0)+500000
   right[key]['duration']-=500000
  right['clip']={'scale':{'x':1.2,'y':1.2}}
  segments[:1]=[left,right]
  for p in (self.active,self.timeline):p.write_text(json.dumps(d))
  self.assertTrue(self.verify()['native_persistence_verified'])
 def test_changed_evidence_or_plan_rejected(self):
  self.install_fixture();dp=Path(self.plan['breath_review']['decisions']);raw=dp.read_bytes()
  d=json.loads(raw);d['items'][0]['note']='changed';dp.write_text(json.dumps(d))
  with self.assertRaises(ValueError):self.verify()
  dp.write_bytes(raw);p=copy.deepcopy(self.plan);p['takes'][0]['end']+=1/24
  with self.assertRaises(ValueError):draft_io.verify(self.target,p,self.external,pending_preview=True)
  self.pcm.write_bytes(bytes(self.pcm.stat().st_size))
  with self.assertRaisesRegex(ValueError,'PCM changed'):self.verify()
 def test_pending_cannot_be_promoted_by_label_or_missing_listening(self):
  self.install_fixture()
  with self.assertRaisesRegex(ValueError,'unresolved'):self.verify(formal=True)
  d=json.loads(self.external.read_text());d['mode']='formal';d['formal_breath_accepted']=True
  self.external.write_text(json.dumps(d))
  with self.assertRaises(ValueError):self.verify(formal=True)
 def test_verify_detects_native_change_during_read(self):
  self.install_fixture();real=draft_io.decode;calls=[]
  def changed(path,folder):
   value=real(path,folder);calls.append(path)
   if len(calls)==2:
    d=json.loads(self.active.read_text());d['tracks'][0]['segments'][0]['volume']=.2
    self.active.write_text(json.dumps(d))
   return value
  with patch.object(draft_io,'decode',side_effect=changed):
   with self.assertRaisesRegex(ValueError,'changed during verification'):self.verify()
 def test_windows_shared_persistence_and_mixed_native_file_names(self):
  self.install_fixture(windows=True);self.native_save()
  result=draft_windows.verify(self.target,self.plan,self.external,self.codec,pending_preview=True)
  self.assertTrue(result['native_persistence_verified'])
  self.assertEqual(len(result['project']['files']),2)
  d=json.loads(self.timeline.read_text());d['id']='other';self.timeline.write_text(json.dumps(d))
  with self.assertRaises(ValueError):draft_windows.verify(self.target,self.plan,self.external,self.codec,pending_preview=True)


class TransactionTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
  self.folder=self.root/'draft';self.folder.mkdir();metadata(self.folder)
  self.first=self.folder/'draft_info.json';self.second=self.folder/'Timelines'/'one'/'draft_content.json';self.second.parent.mkdir(parents=True)
  self.before={self.first:b'original-root',self.second:b'original-timeline'}
  self.prepared={p:b'new-'+raw for p,raw in self.before.items()}
  for p,raw in self.before.items():p.write_bytes(raw)
  self.record={'schema_version':2,'mode':'pending_preview','review':{'pending':['one']}}
  self.external=self.root/'review.json';self.raw=storage.encode(self.record);self.external.write_bytes(self.raw)
  self.target=storage.identity(self.folder,list(self.before))
 def save(self,validate=lambda _:None):
  return storage.save(self.before,self.prepared,self.external,self.record,self.target,validate)
 def assert_restored(self):
  for p,raw in self.before.items():self.assertEqual(p.read_bytes(),raw)
  self.assertEqual(self.external.read_bytes(),self.raw)
  self.assertFalse(storage.pending_path(self.external).exists())
 def test_success_backups_and_committed_record(self):
  result=self.save();record=storage.load_review(self.external)
  self.assertEqual(record['installation']['target'],self.target)
  self.assertEqual(record['installation']['record_sha256'],storage.digest(storage.encode(self.record)))
  self.assertEqual((Path(result['backup'])/'external').read_bytes(),self.raw)
  for i,(p,raw)in enumerate(self.before.items()):
   self.assertEqual((Path(result['backup'])/str(i)).read_bytes(),raw);self.assertEqual(p.read_bytes(),self.prepared[p])
 def test_write_failures_restore_all_files(self):
  real=storage.atomic_write
  for failed_path in (self.second,self.external):
   with self.subTest(path=failed_path):
    failures=[]
    def fail_once(path,raw):
     if Path(path).resolve()==failed_path.resolve() and not failures:failures.append(True);raise OSError('injected write failure')
     return real(path,raw)
    with patch.object(storage,'atomic_write',side_effect=fail_once):
     with self.assertRaisesRegex(OSError,'injected'):self.save()
    self.assert_restored()
 def test_readback_failure_before_and_after_external_commit_rolls_back(self):
  for fail_at in (1,2):
   calls=[]
   def validate(record):
    calls.append(record)
    if len(calls)==fail_at:raise ValueError('injected readback failure')
   with self.assertRaisesRegex(ValueError,'injected'):self.save(validate)
   self.assert_restored()
 def test_concurrent_native_change_is_not_overwritten_and_blocks_review(self):
  def validate(_):
   self.second.write_bytes(b'user-edit');raise ValueError('changed')
  with self.assertRaisesRegex(ValueError,'Concurrent native'):self.save(validate)
  self.assertEqual(self.second.read_bytes(),b'user-edit')
  with self.assertRaisesRegex(ValueError,'incomplete'):storage.load_review(self.external)
  with self.assertRaisesRegex(ValueError,'incomplete'):self.save()
 def test_concurrent_external_change_is_not_overwritten(self):
  def validate(_):self.external.write_bytes(b'user-record')
  with self.assertRaisesRegex(ValueError,'Concurrent external'):self.save(validate)
  self.assertEqual(self.external.read_bytes(),b'user-record')
  self.assertTrue(storage.pending_path(self.external).exists())
 def interrupt_save(self):
  with patch.object(storage,'_restore',side_effect=OSError('simulated process exit')):
   with self.assertRaises(OSError):self.save(lambda _:(_ for _ in ()).throw(ValueError('interrupted')))
 def test_incomplete_transaction_explicit_recovery(self):
  self.interrupt_save()
  with self.assertRaisesRegex(ValueError,'incomplete'):storage.load_review(self.external)
  result=storage.recover(self.folder,list(self.before),self.external)
  self.assertTrue(result['recovered']);self.assertFalse(result['formal_breath_accepted']);self.assert_restored()
 def test_recovery_rejects_wrong_project_and_tampered_backup(self):
  self.interrupt_save();journal=storage.pending_path(self.external);j=json.loads(journal.read_text())
  mp=self.folder.parent/'root_meta_info.json';original=mp.read_bytes()
  m=json.loads(original);m['all_draft_store'][0]['draft_id']='other';mp.write_text(json.dumps(m))
  with self.assertRaisesRegex(ValueError,'project differs'):storage.recover(self.folder,list(self.before),self.external)
  mp.write_bytes(original);(Path(j['backup'])/'0').write_bytes(b'corrupt')
  with self.assertRaisesRegex(ValueError,'backup changed'):storage.recover(self.folder,list(self.before),self.external)
  self.assertTrue(journal.exists())
 def test_recovery_rejects_missing_journal_entry(self):
  self.interrupt_save();journal=storage.pending_path(self.external);j=json.loads(journal.read_text());j['native'].pop()
  journal.write_text(json.dumps(j))
  with self.assertRaisesRegex(ValueError,'entries incomplete'):storage.recover(self.folder,list(self.before),self.external)
 def test_external_must_be_outside_project_and_all_targets_prepared(self):
  inside=self.folder/'review.json';inside.write_bytes(self.raw)
  with self.assertRaisesRegex(ValueError,'outside'):storage.save(self.before,self.prepared,inside,self.record,self.target,lambda _:None)
  del self.prepared[self.second]
  with self.assertRaisesRegex(ValueError,'Every native'):self.save()


del FinalSignalTests
if __name__=='__main__':unittest.main()
