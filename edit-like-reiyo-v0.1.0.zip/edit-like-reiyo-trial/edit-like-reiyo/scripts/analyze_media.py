"""Local-only input preparation. No cuts are decided by this script."""
import argparse,json,pathlib,subprocess,time,wave,hashlib,sys
S=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('source',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);a=p.parse_args()
if sys.platform=='win32':
 from portable_media import analyze
 analyze(a.source,a.output)
 raise SystemExit(0)
a.output.mkdir(parents=True,exist_ok=True);src=a.source.resolve();t=time.time()
fingerprint={'source':str(src),'source_size':src.stat().st_size,'source_mtime_ns':src.stat().st_mtime_ns}
previous=a.output/'receipt.json'
if previous.exists():
 old=json.loads(previous.read_text(encoding='utf-8'))
 if any(old.get(k)!=v for k,v in fingerprint.items()):
  raise SystemExit('This analysis folder belongs to different or changed footage. Choose a fresh output folder.')
elif any((a.output/n).exists()for n in ['audio.pcm','audio.wav','words.jsonl']):
 raise SystemExit('Unverified cached analysis. Choose a fresh output folder.')
probe=subprocess.run([str(S/'media_probe'),str(src)],capture_output=True,text=True,check=True);info=json.loads(probe.stdout);(a.output/'source.json').write_text(json.dumps(info,ensure_ascii=False,indent=2), encoding='utf-8')
pcm=a.output/'audio.pcm'
if not pcm.exists():subprocess.run([str(S/'decode_audio'),str(src),str(pcm)],check=True)
wav=a.output/'audio.wav'
if not wav.exists():
 with wave.open(str(wav),'wb') as w:w.setparams((1,2,16000,0,'NONE','not compressed'));w.writeframes(pcm.read_bytes())
words=a.output/'words.jsonl'
if not words.exists():
 tmp=words.with_suffix('.partial')
 with tmp.open('w') as f:subprocess.run([str(S/'transcribe_words'),str(wav)],stdout=f,check=True)
 rows=[json.loads(s)for s in tmp.read_text(encoding='utf-8').splitlines() if s.strip()]
 assert rows and all('start'in s and 'text'in s for s in rows);tmp.rename(words)
rows=[json.loads(s) for s in words.read_text(encoding='utf-8').splitlines()];paragraphs=[];bucket=[];begin=0
for w in rows:
 if not bucket:begin=w['start']
 bucket.append(w['text'])
 if w['start']-begin>12:
  paragraphs.append(f'[{begin:.2f}] '+''.join(bucket));bucket=[]
if bucket:paragraphs.append(f'[{begin:.2f}] '+''.join(bucket))
(a.output/'transcript.txt').write_text('\n'.join(paragraphs), encoding='utf-8')
receipt={'source':str(src),'source_size':src.stat().st_size,'source_mtime_ns':src.stat().st_mtime_ns,'elapsed':time.time()-t,'words':len(rows),'last_word':rows[-1],'listened':False}
(a.output/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2), encoding='utf-8');print(json.dumps(receipt,ensure_ascii=False))
