"""Align human-reviewed caption groups to recognized word times.
Use | or newline between meaningful short phrases. Review differences; alignment is not speech proof.
"""
import argparse,json,pathlib,re,difflib
clean=lambda x:re.sub(r'[\s，。？！、,.!?：；“”「」…]','',x)
def align(words,lines):
 old='';clock=[]
 for w in words:
  tx=clean(w['text']);old+=tx
  for n in range(len(tx)):clock.append((w['start']+w['duration']*n/len(tx),w['start']+w['duration']*(n+1)/len(tx)))
 groups=[clean(x)for x in re.split(r'[|\n]',lines)if clean(x)];new=''.join(groups);mapped=[None]*len(new);changes=[]
 for op,a,b,c,d in difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes():
  if op=='equal':mapped[c:d]=clock[a:b]
  else:
   changes.append({'recognized':old[a:b],'caption':new[c:d],'at':clock[min(a,len(clock)-1)][0]})
   if d>c:
    x=clock[min(a,len(clock)-1)][0];y=clock[max(a,b-1)][1]
    for n in range(d-c):mapped[c+n]=(x+(y-x)*n/(d-c),x+(y-x)*(n+1)/(d-c))
 out=[];pos=0
 for tx in groups:
  out.append({'text':tx,'start':mapped[pos][0],'end':mapped[pos+len(tx)-1][1]});pos+=len(tx)
 for i,c in enumerate(out[:-1]):c['end']=min(c['end']+.025,out[i+1]['start'])
 return out,changes
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('words',type=pathlib.Path);p.add_argument('lines',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);a=p.parse_args();captions,changes=align([json.loads(x)for x in a.words.read_text(encoding='utf-8').splitlines()],a.lines.read_text(encoding='utf-8'));a.output.write_text(json.dumps(captions,ensure_ascii=False,indent=2), encoding='utf-8');a.output.with_suffix('.differences.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2), encoding='utf-8');print(len(captions),'captions;',len(changes),'text differences to review')
