"""Local Windows media helpers. Editorial decisions stay in the shared Skill.

PyAV decodes at original timestamps; Whisper provides word candidates, not cuts.
No media is uploaded. A model must already be downloaded by setup_portable.py.
"""
import argparse
import json
import math
import os
from pathlib import Path
import wave

RATE = 16000


def probe(source):
    import av
    with av.open(str(source)) as container:
        videos = list(container.streams.video)
        video = videos[0] if videos else None
        duration = float(container.duration / av.time_base) if container.duration is not None else None
        if duration is None and video is not None and video.duration is not None:
            duration = float(video.duration * video.time_base)
        if duration is None or not math.isfinite(duration) or duration <= 0:
            raise ValueError('Cannot establish the source duration')
        origin = float(container.start_time / av.time_base) if container.start_time is not None else 0.0
        result = {'path': str(Path(source).resolve()), 'duration': duration, 'timeline_origin': origin}
        if video:
            result.update(width=video.codec_context.width, height=video.codec_context.height)
            rotation = int(float(video.metadata.get('rotate', 0))) % 360
            # Side-data rotation is checked again on a decoded frame below.
            first = next(container.decode(video), None)
            if first is not None:
                rotation = int(getattr(first, 'rotation', rotation)) % 360
            result['rotation'] = rotation
            if rotation in (90, 270):
                result['width'], result['height'] = result['height'], result['width']
        return result


def decode_pcm(source, output, info=None):
    import av
    import numpy as np
    output = Path(output)
    if output.exists():
        raise FileExistsError(output)
    info = info or probe(source)
    samples = np.zeros(math.ceil(info['duration'] * RATE), dtype='<i2')
    with av.open(str(source)) as container:
        if not container.streams.audio:
            raise ValueError('No audio track in this source')
        resampler = av.AudioResampler(format='s16', layout='mono', rate=RATE)

        def place(frame):
            if frame.pts is None:
                raise ValueError('Audio frame has no timestamp; refuse shifted cuts')
            start = round((float(frame.pts * frame.time_base) - info['timeline_origin']) * RATE)
            values = frame.to_ndarray().reshape(-1)
            left, right = max(0, start), min(len(samples), start + len(values))
            if right > left:
                samples[left:right] = values[left-start:right-start]

        for frame in container.decode(audio=0):
            for converted in resampler.resample(frame):
                place(converted)
        for converted in resampler.resample(None):
            place(converted)
    output.write_bytes(samples.tobytes())


def make_wav(pcm, output):
    with wave.open(str(output), 'wb') as out:
        out.setparams((1, 2, RATE, 0, 'NONE', 'not compressed'))
        out.writeframes(Path(pcm).read_bytes())


def transcribe(wav, output, model_path=None):
    model_path = model_path or os.environ.get('REIYO_WHISPER_MODEL')
    if not model_path:
        model_path = str(Path(__file__).resolve().parents[1] / '.runtime/models/whisper-small')
    if not (Path(model_path) / 'model.bin').is_file():
        raise FileNotFoundError('Local speech model missing. Run setup_portable.py --download-model after confirming the first download.')
    from faster_whisper import WhisperModel
    model = WhisperModel(model_path, device='cpu', compute_type='int8', local_files_only=True)
    segments, _ = model.transcribe(str(wav), language='zh', word_timestamps=True,
                                  vad_filter=False, condition_on_previous_text=False)
    rows = []
    for segment in segments:
        for word in segment.words or []:
            rows.append({'start': word.start, 'duration': word.end-word.start,
                         'text': word.word, 'confidence': word.probability})
    if not rows:
        raise ValueError('No speech recognized; do not create empty captions')
    Path(output).write_text('\n'.join(json.dumps(row, ensure_ascii=False) for row in rows)+'\n', encoding='utf-8')
    return rows


def analyze(source, output, model_path=None):
    source, output = Path(source).resolve(), Path(output)
    output.mkdir(parents=True, exist_ok=True)
    if any(output.iterdir()):
        raise ValueError('Use a fresh analysis folder; failed or partial results are not reused')
    info = probe(source)
    (output/'source.json').write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding='utf-8')
    decode_pcm(source, output/'audio.pcm', info)
    make_wav(output/'audio.pcm', output/'audio.wav')
    rows = transcribe(output/'audio.wav', output/'words.jsonl', model_path)
    (output/'transcript.txt').write_text('\n'.join(f"[{r['start']:.3f}] {r['text']}" for r in rows), encoding='utf-8')
    (output/'receipt.json').write_text(json.dumps({'source':str(source), 'backend':'pyav-whisper-local',
        'listened':False, 'words':len(rows), 'timeline_origin':info['timeline_origin']}, indent=2), encoding='utf-8')


def frames(source, output, times):
    import av
    output = Path(output); output.mkdir(parents=True, exist_ok=True)
    info = probe(source)
    targets = sorted(set(times))
    if not targets or any(not math.isfinite(t) or t < 0 or t >= info['duration'] for t in targets):
        raise ValueError('Frame times must be within source duration')
    found = []
    with av.open(str(source)) as container:
        if not container.streams.video:
            raise ValueError('No video track')
        for frame in container.decode(video=0):
            if frame.pts is None:
                continue
            time = float(frame.pts * frame.time_base) - info['timeline_origin']
            while targets and time + 1e-6 >= targets[0]:
                requested = targets.pop(0)
                name = f'frame-{requested:.3f}.png'
                image = frame.to_image()
                if info.get('rotation'):
                    image = image.rotate(info['rotation'], expand=True)
                image.save(output/name)
                found.append({'requested':requested, 'actual':time, 'path':str((output/name).resolve())})
            if not targets:
                break
    if targets:
        raise ValueError(f'Could not decode requested frames: {targets}')
    (output/'frames.json').write_text(json.dumps(found, indent=2), encoding='utf-8')
    return found


if __name__ == '__main__':
    p = argparse.ArgumentParser(); sub = p.add_subparsers(dest='command', required=True)
    for name in ['analyze', 'decode', 'transcribe', 'frames']:
        c = sub.add_parser(name); c.add_argument('source'); c.add_argument('output')
        if name in ['analyze','transcribe']: c.add_argument('--model')
        if name == 'frames': c.add_argument('seconds', nargs='+', type=float)
    a = p.parse_args()
    if a.command == 'analyze': analyze(a.source, a.output, a.model)
    elif a.command == 'decode': decode_pcm(a.source, a.output)
    elif a.command == 'transcribe': transcribe(a.source, a.output, a.model)
    else: frames(a.source, a.output, a.seconds)
