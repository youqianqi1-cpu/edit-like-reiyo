"""Prepare project-local dependencies; never upgrade system Python or Jianying."""
import argparse
from pathlib import Path
import subprocess
import sys
import venv

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--download-model', action='store_true'); a = p.parse_args()
    if sys.platform != 'win32':
        raise SystemExit('This setup is for Windows. Use the existing Mac execution route on macOS.')
    if not ((3,10) <= sys.version_info[:2] <= (3,12)) or sys.maxsize <= 2**32:
        raise SystemExit('Use 64-bit Python 3.10–3.12 supplied by your Codex environment, or install it first.')
    root = Path(__file__).resolve().parents[1]; runtime = root/'.runtime'; env = runtime/'venv'
    python = env/'Scripts/python.exe'
    if not python.exists(): venv.EnvBuilder(with_pip=True).create(env)
    subprocess.run([str(python),'-m','pip','install','--disable-pip-version-check','--retries','1','--timeout','30',
                    '-r',str(root/'scripts/requirements-windows.txt')],check=True)
    if a.download_model:
        model = runtime/'models/whisper-small'; model.parent.mkdir(parents=True,exist_ok=True)
        subprocess.run([str(python),'-c',
            'from faster_whisper.utils import download_model; import sys; download_model("small",output_dir=sys.argv[1])',
            str(model)],check=True)
    print('Use this Python for all trial commands:',python)
    print('Model:',runtime/'models/whisper-small')
