"""Run with python3 -m unittest discover -s scripts -p 'test_*.py'."""
import copy
import tempfile
import unittest
from compose_beats import compose


class CaptionPromotionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.plan = {
            'fps': 30,
            'takes': [{'source': 'raw', 'start': 10, 'end': 12},
                      {'source': 'raw', 'start': 20, 'end': 21}],
            'captions': [
                {'text': '先打开', 'start': 0, 'end': 1},
                {'text': '再选择', 'start': 1, 'end': 2},
                {'text': '最后保存', 'start': 2, 'end': 2.8}],
            'caption_style': {'size': 7, 'color': '#FFFFFF',
                              'background': '#24345A', 'x': -.1, 'y': -.31}}

    def run_beats(self, beats, plan=None):
        return compose(plan or self.plan, beats, self.temp.name)

    def beat(self, index=1, text='再选择', **kw):
        return dict(type='promote', reason='语义重音',
                    caption_indices=[index], text=text, **kw)

    def frames(self, plan):
        return [(t['source'], f) for t in plan['takes']
                for f in range(round(t['start'] * plan['fps']),
                               round(t['end'] * plan['fps']))]

    def test_exact_timing_palette_and_input_survive(self):
        before = copy.deepcopy(self.plan)
        out = self.run_beats([self.beat(style={'size': 17, 'background': False})])
        self.assertEqual(self.plan, before)
        self.assertEqual(out['takes'], self.plan['takes'])
        self.assertEqual([c['text'] for c in out['captions']], ['先打开', '最后保存'])
        title = out['titles'][0]
        self.assertEqual((title['start'], title['end']), (1, 2))
        self.assertEqual((title['color'], title['x'], title['y']), ('#FFFFFF', -.1, -.31))
        self.assertEqual(title['size'], 17)
        self.assertIs(title['background'], False)

    def test_indices_do_not_shift_between_beats(self):
        out = self.run_beats([self.beat(0, '先打开'), self.beat(2, '最后保存')])
        self.assertEqual([c['text'] for c in out['captions']], ['再选择'])
        self.assertEqual([c['text'] for c in out['titles']], ['先打开', '最后保存'])

    def test_parallel_preserves_all_source_frames_and_short_title_end(self):
        # The third phrase has a short end gap; do not lengthen it to scene end.
        out = self.run_beats([{
            'type': 'parallel', 'source': 'raw', 'reason': '三个并列步骤', 'end': 21,
            'style': {'size': 16},
            'items': [{'at': 10, 'text': '先打开', 'caption_indices': [0], 'scale': 1},
                      {'at': 11, 'text': '再选择', 'caption_indices': [1], 'scale': 1.08},
                      {'at': 20, 'text': '最后保存', 'caption_indices': [2], 'scale': 1.16}]}])
        self.assertEqual(self.frames(out), self.frames(self.plan))
        self.assertEqual([t['scale'] for t in out['takes']], [1, 1.08, 1.16])
        self.assertEqual(out['captions'], [])
        self.assertEqual([t['start'] for t in out['titles']], [0, 1, 2])
        self.assertEqual(out['titles'][-1]['end'], 2.8)

    def test_rejects_rewrite_duplicate_or_bad_index(self):
        bad = [[self.beat(text='随便改掉')], [self.beat(), self.beat()],
               [self.beat(index=-1)], [self.beat(index=99)],
               [self.beat(style={'unknown': True})]]
        for beats in bad:
            with self.subTest(beats=beats), self.assertRaises(ValueError):
                self.run_beats(beats)

    def test_rejects_skipped_words_and_cumulative_layout(self):
        with self.assertRaises(ValueError):
            self.run_beats([{'type': 'promote', 'reason': 'bad',
                             'caption_indices': [0, 2], 'text': '先打开最后保存'}])
        grouped = copy.deepcopy(self.plan)
        grouped['captions'][0]['end'] = 2
        with self.assertRaises(ValueError):
            self.run_beats([self.beat()], grouped)

    def test_mismatch_does_not_mutate_plan(self):
        before = copy.deepcopy(self.plan)
        with self.assertRaises(ValueError):
            self.run_beats([{'type': 'parallel', 'source': 'raw', 'reason': 'bad',
                             'end': 12, 'items': [{'at': 10, 'text': '再选择',
                                                   'caption_indices': [1]}]}])
        self.assertEqual(self.plan, before)

    def test_additional_title_keeps_captions(self):
        out = self.run_beats([{'type': 'title', 'reason': '概括标题', 'source': 'raw',
                              'start': 10, 'end': 12, 'text': '三个操作'}])
        self.assertEqual(out['captions'], self.plan['captions'])

    def test_source_anchor_in_deleted_range_fails(self):
        with self.assertRaises(ValueError):
            self.run_beats([{'type': 'title', 'reason': 'bad', 'source': 'raw',
                             'start': 15, 'end': 20, 'text': '不能漂移'}])


if __name__ == '__main__':
    unittest.main()
