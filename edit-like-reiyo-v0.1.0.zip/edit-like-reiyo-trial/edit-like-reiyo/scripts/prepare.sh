#!/bin/zsh
set -euo pipefail
script_dir=${0:A:h}
[[ $(uname -s) == Darwin ]] || { echo 'This execution route currently supports macOS only.' >&2; exit 2; }
[[ -d /Applications/VideoFusion-macOS.app ]] || { echo 'Jianying installation not found.' >&2; exit 2; }
"$script_dir/build_jytools.sh"
for name in transcribe_words media_probe; do
 swiftc -parse-as-library -O "$script_dir/$name.swift" -o "$script_dir/$name"
done
for name in decode_audio extract_frames; do
 swiftc -O "$script_dir/$name.swift" -o "$script_dir/$name"
done
