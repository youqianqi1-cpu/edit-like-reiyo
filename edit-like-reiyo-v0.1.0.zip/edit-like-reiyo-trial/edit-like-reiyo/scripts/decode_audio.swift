import Foundation
import AVFoundation

let src = CommandLine.arguments[1]
let dst = CommandLine.arguments[2]
precondition(!FileManager.default.fileExists(atPath: dst))
let asset = AVURLAsset(url: URL(fileURLWithPath: src))
let track = asset.tracks(withMediaType: .audio)[0]
let reader = try AVAssetReader(asset: asset)
let output = AVAssetReaderTrackOutput(track: track, outputSettings: [
    AVFormatIDKey: kAudioFormatLinearPCM, AVLinearPCMBitDepthKey: 16,
    AVLinearPCMIsFloatKey: false, AVLinearPCMIsBigEndianKey: false,
    AVSampleRateKey: 16000, AVNumberOfChannelsKey: 1
])
reader.add(output)
precondition(reader.startReading())
var samples = [Int16](repeating: 0, count: Int(ceil(asset.duration.seconds * 16000)))
var first: Double? = nil
var end = 0.0
while let buffer = output.copyNextSampleBuffer() {
    let pts = CMSampleBufferGetPresentationTimeStamp(buffer).seconds
    if first == nil { first = pts }
    let start = Int(round(pts * 16000))
    let count = CMSampleBufferGetNumSamples(buffer)
    guard let block = CMSampleBufferGetDataBuffer(buffer) else { fatalError("No samples") }
    var raw: UnsafeMutablePointer<Int8>? = nil
    precondition(CMBlockBufferGetDataPointer(block, atOffset: 0, lengthAtOffsetOut: nil, totalLengthOut: nil, dataPointerOut: &raw) == 0)
    raw!.withMemoryRebound(to: Int16.self, capacity: count) { p in
        for i in 0..<count where start + i >= 0 && start + i < samples.count {
            samples[start + i] = p[i]
        }
    }
    end = pts + Double(count) / 16000
}
precondition(reader.status == .completed, reader.error?.localizedDescription ?? "Audio read incomplete")
try samples.withUnsafeBytes { try Data($0).write(to: URL(fileURLWithPath: dst)) }
print("firstPTS=\(first ?? -1) lastEnd=\(end) duration=\(asset.duration.seconds) samples=\(samples.count)")
