"""Flag quiet spans inside takes and accumulated quiet across joins; never approve automatic cuts.
PCM: mono s16le 16 kHz, same source time origin. Review quiet spans against phonemes/expression.
"""
import argparse,json,pathlib
from waveform import envelope

def audit(plan,analysis_root,threshold=.02):
 cache={};records=[];joins=[];cursor=0;fps=plan.get('fps',30)
 for i,t in enumerate(plan['takes']):
  if t['source']not in cache:cache[t['source']]=envelope(pathlib.Path(analysis_root)/t['source']/'audio.pcm',.01)
  e=cache[t['source']];lo=round(t['start']*100);hi=round(t['end']*100)
  if not 0<=lo<hi<=len(e):raise ValueError('Take lies outside decoded audio: '+str(i))
  spans=[];begin=None
  for k in range(lo,hi+1):
   quiet=k<hi and e[k]<threshold
   if quiet and begin is None:begin=k
   if not quiet and begin is not None:
    if k-begin>=12:spans.append(dict(start=begin/100,end=k/100,duration=(k-begin)/100,decision='review_required'))
    begin=None
  head=lo
  while head<hi and e[head]<threshold:head+=1
  tail=hi
  while tail>lo and e[tail-1]<threshold:tail-=1
  record=dict(take=i,source=t['source'],start=t['start'],end=t['end'],quiet_candidates=spans,reviewed=False,
              leading_quiet=dict(start=lo/100,end=head/100,duration=(head-lo)/100),
              trailing_quiet=dict(start=tail/100,end=hi/100,duration=(hi-tail)/100))
  if records:
   prev=records[-1];left=prev['trailing_quiet'];right=record['leading_quiet']
   total=round(left['duration']+right['duration'],2)
   # Two individually short remnants can form one conspicuous pause after joining.
   if total>=.12:
    joins.append(dict(after_take=i-1,before_take=i,timeline_join=cursor/fps,
                      left_source=prev['source'],left_range=left,right_source=t['source'],right_range=right,
                      combined_quiet_seconds=total,decision='review_required'))
  records.append(record);cursor+=round(t['end']*fps)-round(t['start']*fps)
 return dict(threshold_is_candidate_only=threshold,window_seconds=.01,takes=records,joins=joins,
             note='Quiet spans can contain phonemes. Review source edges and the joined sound; these are not automatic cuts.')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('plan',type=pathlib.Path);p.add_argument('analysis_root',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);p.add_argument('--threshold',type=float,default=.02);a=p.parse_args()
 result=audit(json.loads(a.plan.read_text(encoding='utf-8')),a.analysis_root,a.threshold)
 a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2), encoding='utf-8');print('takes covered',len(result['takes']),'quiet candidates',sum(len(t['quiet_candidates'])for t in result['takes']),'joined candidates',len(result['joins']))
