"""Apply reviewed source-time removals to a plan and retime every dependent layer.
Never finds or approves cuts. Input ranges must be individually reviewed.
"""
import copy,json,pathlib,argparse

def apply(plan,cuts):
 p=copy.deepcopy(plan);fps=p.get('fps',30);frame=lambda x:round(x*fps);sec=lambda x:x/fps
 pieces=[];takes=[];old_at=new_at=0
 for take in p['takes']:
  a,b=frame(take['start']),frame(take['end']);ranges=[(a,b)]
  for cut in cuts:
   if cut['source']!=take['source']:continue
   l,r=frame(cut['start']),frame(cut['end']);assert l<r
   out=[]
   for x,y in ranges:
    if r<=x or l>=y:out.append((x,y));continue
    if x<l:out.append((x,l))
    if r<y:out.append((r,y))
   ranges=out
  for x,y in ranges:
   n=copy.deepcopy(take);n.update(start=sec(x),end=sec(y));n.pop('at',None);n.pop('duration',None)
   for prop,pts in n.get('keys',{}).items():
    def val(t):
     if t<=pts[0][0]:return pts[0][1]
     for (l,v),(r,w) in zip(pts,pts[1:]):
      if t<=r:return v+(w-v)*(t-l)/(r-l)
     return pts[-1][1]
    lo,hi=sec(x-a),sec(y-a);n['keys'][prop]=[[0,val(lo)],*[[t-lo,v]for t,v in pts if lo<t<hi],[hi-lo,val(hi)]]
   takes.append(n);pieces.append((old_at+x-a,old_at+y-a,new_at));new_at+=y-x
  old_at+=b-a
 def point(t):
  f=frame(t)
  for a,b,n in pieces:
   if f<a:return sec(n)
   if f<=b:return sec(n+f-a)
  return sec(new_at)
 p['takes']=takes
 for group in ['captions','titles','sounds','overlays']:
  result=[]
  for item in p.get(group,[]):
   a=item['start'];n=copy.deepcopy(item);n['start']=point(a)
   if 'end'in item:
    n['end']=point(item['end'])
    if n['end']<=n['start']:continue
    if group=='overlays' and p['sources'][item['source']].get('type')!='photo':raise ValueError('Moving overlay requires a source-aware split; do not silently retime it')
    for prop,pts in item.get('keys',{}).items():
     keys={}
     for dt,v in pts:keys[max(0,min(n['end']-n['start'],point(a+dt)-n['start']))]=v
     n['keys'][prop]=[[k,v]for k,v in sorted(keys.items())]
   result.append(n)
  p[group]=result
 return p,{'before':sec(old_at),'after':sec(new_at),'pieces':pieces}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('plan',type=pathlib.Path);ap.add_argument('cuts',type=pathlib.Path);ap.add_argument('output',type=pathlib.Path);a=ap.parse_args();p,m=apply(json.loads(a.plan.read_text(encoding='utf-8')),json.loads(a.cuts.read_text(encoding='utf-8')));a.output.write_text(json.dumps(p,ensure_ascii=False,indent=2), encoding='utf-8');a.output.with_suffix('.retiming.json').write_text(json.dumps(m,indent=2), encoding='utf-8');print(m['before'],m['after'],len(p['takes']))
