"""Read drafts; install only into an explicitly named, closed test draft."""
import argparse, hashlib, json, os, pathlib, shutil, subprocess, tempfile
S=pathlib.Path(__file__).resolve().parent
F='/Applications/VideoFusion-macOS.app/Contents/Frameworks'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(folder):
 r=subprocess.run([str(S/'jycat'),str(folder/'draft_info.json'),str(folder)],env={**os.environ,'DYLD_FRAMEWORK_PATH':F},capture_output=True,text=True,check=True)
 return json.loads(r.stdout[r.stdout.index('{'):])
def write_json(p,d):p.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')), encoding='utf-8')
def install(folder,candidate,expect,name,closed):
 if not closed or folder.name!=name or sha(folder/'draft_info.json')!=expect:raise ValueError('Target identity, closed state, or fingerprint mismatch')
 old=read(folder);new=json.loads(candidate.read_text(encoding='utf-8'))
 if old['id']!=new['id']:raise ValueError('Candidate belongs to a different native draft')
 timelines=list((folder/'Timelines').glob('*/draft_info.json'))
 if len(timelines)!=1:raise ValueError('Expected one native timeline')
 # Writer's native bridge deliberately only accepts its temporary sandbox.
 r=subprocess.run([str(S/'jywrite_verify.sh'),str(candidate),str(folder)],capture_output=True,text=True,check=True)
 receipt=dict(x.split('=',1) for x in r.stdout.splitlines() if '=' in x)
 if receipt.get('ROUNDTRIP_OK')!='true' or sha(folder/'draft_info.json')!=expect:raise ValueError('Verification or source concurrency check failed')
 backup=pathlib.Path(tempfile.mkdtemp(prefix='reiyo-before-install-'))
 for i,p in enumerate([folder/'draft_info.json',*timelines]):shutil.copy2(p,backup/f'{i}.json')
 src=pathlib.Path(receipt['LAB'])/'draft/draft_info.json'
 try:
  for target in [folder/'draft_info.json',*timelines]:
   tmp=target.with_name(target.name+'.reiyo-tmp');shutil.copy2(src,tmp);os.replace(tmp,target)
  if read(folder)!=new:raise ValueError('Installed draft differs from candidate')
 except BaseException:
  for i,p in enumerate([folder/'draft_info.json',*timelines]):shutil.copy2(backup/f'{i}.json',p)
  raise
 receipt.update(target=str(folder),backup=str(backup),ui_reopen_verified=False)
 return receipt
if __name__=='__main__':
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='cmd',required=True)
 r=sub.add_parser('read');r.add_argument('draft',type=pathlib.Path);r.add_argument('out',type=pathlib.Path)
 w=sub.add_parser('install');w.add_argument('draft',type=pathlib.Path);w.add_argument('candidate',type=pathlib.Path);w.add_argument('--expected-sha',required=True);w.add_argument('--exact-name',required=True);w.add_argument('--closed',action='store_true');w.add_argument('--receipt',type=pathlib.Path,required=True)
 a=p.parse_args()
 if a.cmd=='read':write_json(a.out,read(a.draft));print(sha(a.draft/'draft_info.json'))
 else:write_json(a.receipt,install(a.draft,a.candidate,a.expected_sha,a.exact_name,a.closed));print(a.receipt)
