"""Windows draft bridge: only a registered, empty trial draft may be edited.

Uses the pinned pyJianYingDraft codec with the user's installed Jianying DLL.
Native calls run in isolated processes. No DLLs or private assets are shipped.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile

MARKER = '.reiyo-trial.json'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_codec(install_dir):
    from vendor.jianying_codec.draft_codec import JianyingDraftCryptoCodec
    from vendor.jianying_codec.draft_crypto import DraftCryptoConfig
    if not (Path(install_dir)/'videoeditor.dll').is_file():
        raise FileNotFoundError('Select the installed Jianying version folder containing videoeditor.dll')
    return JianyingDraftCryptoCodec(DraftCryptoConfig(jy_install_dir=install_dir, isolated=True,
                                                     timeout=60, validate_roundtrip=True))


def decode(raw, codec):
    try:
        value = json.loads(raw.decode('utf-8-sig')); encrypted = False
    except (UnicodeDecodeError, json.JSONDecodeError):
        value = codec.decode(raw); encrypted = True
    if not isinstance(value, dict):
        raise ValueError('Draft is not an object')
    return value, encrypted


def files(folder):
    main = folder/'draft_info.json'
    if not main.is_file():
        main = folder/'draft_content.json'
    if not main.is_file():
        raise FileNotFoundError('No native draft found. Create an empty new draft in Jianying first.')
    timelines = sorted((folder/'Timelines').glob('*/'+main.name))
    if len(timelines) > 1:
        raise ValueError('Multiple timelines: use a fresh, single-timeline trial draft')
    return [main, *timelines]


def read(folder, codec):
    return decode(files(Path(folder))[0].read_bytes(), codec)[0]


def initialize(folder, name, codec, closed):
    folder = Path(folder).resolve()
    if not closed or folder.name != name or (folder/MARKER).exists():
        raise ValueError('Close the new draft and confirm its exact folder name; do not reinitialize')
    targets = files(folder)
    fingerprints = {str(p.relative_to(folder)):digest(p) for p in targets}
    draft = read(folder, codec)
    if not draft.get('id') or any(t.get('segments') for t in draft.get('tracks', [])):
        raise ValueError('Only an empty, native-created trial draft may be initialized')
    # Probe encoding without writing any draft. Library mismatch stops here.
    candidate = json.dumps(draft, ensure_ascii=False, separators=(',',':'))
    if codec.decode(codec.encode(candidate)) != draft:
        raise ValueError('Native codec round-trip failed')
    if any(digest(folder/p) != sha for p,sha in fingerprints.items()):
        raise ValueError('Draft changed during preparation')
    backup = Path(tempfile.mkdtemp(prefix='reiyo-empty-draft-'))
    for n,p in enumerate(targets): shutil.copy2(p, backup/f'{n}.json')
    marker = {'id':draft['id'], 'name':name, 'folder':str(folder), 'initial':fingerprints, 'backup':str(backup)}
    (folder/MARKER).write_text(json.dumps(marker, ensure_ascii=False, indent=2), encoding='utf-8')
    return {'ready_for_trial':True, 'sha256':digest(targets[0]), 'ui_reopen_verified':False}


def install(folder, candidate, expect, name, closed, codec):
    folder = Path(folder).resolve()
    if not closed or folder.name != name:
        raise ValueError('Close the exact new draft before writing')
    marker = json.loads((folder/MARKER).read_text(encoding='utf-8'))
    if marker['name'] != name or marker['folder'] != str(folder):
        raise ValueError('Trial identity mismatch')
    targets = files(folder)
    before = {p:p.read_bytes() for p in targets}
    if digest(targets[0]) != expect:
        raise ValueError('Draft changed since it was read')
    new = json.loads(Path(candidate).read_text(encoding='utf-8'))
    old = decode(before[targets[0]], codec)[0]
    if new.get('id') != marker['id'] or old.get('id') != marker['id']:
        raise ValueError('Candidate or draft belongs to another project')
    serialized = json.dumps(new, ensure_ascii=False, separators=(',',':'))
    prepared = {}
    for target,raw in before.items():
        decoded, encrypted = decode(raw, codec)
        if decoded.get('id') != old['id']:
            raise ValueError('Native timeline identity differs; do not guess')
        encoded = codec.encode(serialized) if encrypted else serialized.encode('utf-8')
        if decode(encoded, codec)[0] != new:
            raise ValueError('Encoded candidate differs after reading back')
        prepared[target] = encoded
    if any(p.read_bytes() != raw for p,raw in before.items()):
        raise ValueError('Draft changed during verification')
    backup = Path(tempfile.mkdtemp(prefix='reiyo-before-install-'))
    for n,(target,raw) in enumerate(before.items()): (backup/f'{n}.json').write_bytes(raw)
    try:
        for target,raw in prepared.items():
            temporary = target.with_name(target.name+'.reiyo-tmp')
            temporary.write_bytes(raw); os.replace(temporary, target)
        if any(decode(p.read_bytes(), codec)[0] != new for p in targets):
            raise ValueError('Installed draft differs from candidate')
    except BaseException:
        for target,raw in before.items(): target.write_bytes(raw)
        raise
    finally:
        for target in targets:
            target.with_name(target.name+'.reiyo-tmp').unlink(missing_ok=True)
    return {'saved':True, 'backup':str(backup), 'target':str(folder), 'ui_reopen_verified':False}


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--install-dir', required=True)
    sub = p.add_subparsers(dest='command', required=True)
    c = sub.add_parser('read'); c.add_argument('draft'); c.add_argument('output')
    for name in ['init','install']:
        c = sub.add_parser(name); c.add_argument('draft'); c.add_argument('--exact-name',required=True)
        c.add_argument('--closed',action='store_true'); c.add_argument('--receipt',required=True)
        if name == 'install': c.add_argument('candidate'); c.add_argument('--expected-sha',required=True)
    a = p.parse_args(); codec = make_codec(a.install_dir)
    if a.command == 'read':
        Path(a.output).write_text(json.dumps(read(a.draft,codec),ensure_ascii=False), encoding='utf-8')
        print(digest(files(Path(a.draft))[0]))
    else:
        if a.command == 'init': result = initialize(a.draft,a.exact_name,codec,a.closed)
        else: result = install(a.draft,a.candidate,a.expected_sha,a.exact_name,a.closed,codec)
        Path(a.receipt).write_text(json.dumps(result,ensure_ascii=False,indent=2), encoding='utf-8')
        print(json.dumps(result,ensure_ascii=False))
