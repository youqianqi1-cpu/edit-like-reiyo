# 单片剪辑计划

这是模型根据原片生成的内部文件，用户只需指定素材和需求。工具不会替模型决定什么话该删。

所有时间单位为秒。时间轴起点从 0 开始；素材中的时间必须来自对应原片，不能从别的识别音轨或旧成片搬来。

- `canvas`: `{"ratio":"9:16","width":1080,"height":1920}`，以用户要求/原片为准。
- `fps`: 草稿帧率。
- `sources`: 源名称到 `{path,duration,width,height,type}` 的映射；type 默认为 video，静态图为 photo。
- `takes`: 按成片顺序列出 `{source,start,end,reason}`。start/end 是原片位置；可加 scale/x/y/volume（默认1）。先保全独有信息，再比较重说、收紧气口。所有删除理由在本次工作目录留底。
- `captions`: `{text,start,end,size?,x?,y?,lane?,color?,background?}`，start/end 是成片位置，按字词实际时间映射并校对。默认蓝字白底短句。累积块分到独立 lane，同一 lane 不重叠；background 可为颜色或 false。原声时点不因排版变化。
- `titles`: `{text,start,end,size?,x?,y?,color?,pop?}`，与普通字幕分开，默认有深蓝偏移投影。标题的语义和落点由原片决定。
- `overlays`: `{source,start,end,source_start,scale?,x?,y?,volume?}`，source_start 是对应素材时间，默认静音。
- `sounds`: `{path,start,volume?,reason}`，素材为 WAV。默认正常音量 1.0，不因为是音效就压低；声效时长来自实际文件。避免长音效重叠盖讲话。
- `font` / `title_font`: 当前机器实际存在的字体文件。Mac 未提供时用剪映随附中文字体；Windows 必须明确填写本机存在的中文字体，preflight.py 会列候选。
- takes 和 overlays 可加 `keys`，例如 `{"KFTypeScaleX":[[0,1],[0.4,1.12]],"KFTypeScaleY":[[0,1],[0.4,1.12]]}`。这里是相对片段的秒数；工具负责加回源素材起点。不要再次手动加源起点。跳切用相邻帧的两个关键帧表示，不能以长缓推代替。

生成候选后检查连续两段是否真正衔接；必要的表情停留在 takes 中保留，不拿动画覆盖吞字或生硬剪口。若要改变已经获认可的剪点，单独验证原声和所有关联层的同步。

多个同时出现的重点字可给 titles 指定不同 `lane`（字符串或整数）；同一 lane 内不允许重叠。章节提示也用独立 lane，避免占用普通字幕位置。音效和重点字的落点先定位原片真正说到该词的位置，再按 takes 映射到成片，不能给整段随意加固定偏移。
