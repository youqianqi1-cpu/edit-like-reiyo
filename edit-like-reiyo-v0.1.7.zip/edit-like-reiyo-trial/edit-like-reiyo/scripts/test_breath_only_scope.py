import unittest
from assemble import check_spacing_for_scope
from sound_density import review


class BreathOnlyScopeTests(unittest.TestCase):
    def test_no_sounds_only_allowed_for_requested_stage(self):
        plan = {'takes': [{'source': 'main', 'start': 0, 'end': 30}]}
        with self.assertRaises(ValueError):
            check_spacing_for_scope(plan, review(30, []))
        plan['editing_scope'] = 'breath_only'
        self.assertEqual(check_spacing_for_scope(plan, review(30, []))['status'], 'not_applicable')

    def test_partial_stage_rejects_packaging(self):
        for key, value in [('captions', [{'text': 'hello'}]), ('sounds', [{'path': 'sound.wav'}]),
                           ('takes', [{'keys': {'KFTypeScaleX': [[0, 1.2]]}}])]:
            plan = {'editing_scope': 'breath_only', 'takes': [{}], key: value}
            with self.assertRaises(ValueError):
                check_spacing_for_scope(plan, review(30, []))
