import copy
import unittest
from unittest.mock import patch
from replace_sounds import replace

class ReplaceTests(unittest.TestCase):
    def test_preserves_picture_text_native_effect_and_music(self):
        saved={'tracks':[{'type':'video','segments':[{'id':'v','extra_material_refs':['voice']}]},
                         {'type':'text','segments':[{'id':'caption'}]},
                         {'type':'audio','segments':[{'material_id':'old'}]},
                         {'type':'audio','segments':[{'material_id':'bgm'}]}],
               'materials':{'audios':[{'id':'old','type':'sound'},{'id':'bgm','type':'music'}],
                            'audio_effects':[{'id':'voice','name':'扩音器'}],'texts':[{'id':'caption'}]}}
        fresh={'tracks':[{'type':'audio','segments':[{'material_id':'new'}]}],
               'materials':{'audios':[{'id':'new','type':'sound'}]}}
        before=copy.deepcopy(saved)
        with patch('replace_sounds.build',return_value=(fresh,[])),patch('replace_sounds.from_native'),patch('replace_sounds.check_spacing_for_scope'),patch('replace_sounds.check_native'),patch('replace_sounds.check_punchlines'),patch('replace_sounds.require_review'),patch('replace_sounds.output_record',return_value={'pending':True}):
            result,_=replace(saved,{},True)
        self.assertEqual(saved,before)
        self.assertEqual(result['tracks'][:2],saved['tracks'][:2])
        self.assertEqual(result['tracks'][2],saved['tracks'][3])
        self.assertEqual(result['materials']['audio_effects'],saved['materials']['audio_effects'])
        self.assertEqual(result['materials']['texts'],saved['materials']['texts'])
        self.assertEqual([x['id'] for x in result['materials']['audios']],['bgm','new'])

    def test_mixed_music_sound_track_is_not_removed(self):
        saved={'tracks':[{'type':'audio','segments':[{'material_id':'s'},{'material_id':'m'}]}],
               'materials':{'audios':[{'id':'s','type':'sound'},{'id':'m','type':'music'}]}}
        with patch('replace_sounds.build',return_value=({'tracks':[],'materials':{'audios':[]}},[])):
            with self.assertRaisesRegex(ValueError,'Mixed music'):replace(saved,{},True)
