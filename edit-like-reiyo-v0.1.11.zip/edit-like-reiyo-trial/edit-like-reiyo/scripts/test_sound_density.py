import copy
import unittest
from sound_density import from_plan, from_native, require_spacing


def sentences(ends):
    return [{'text':f'完整的第{i+1}句话。','start':a,'end':b} for i,(a,b) in enumerate(zip([0]+ends[:-1],ends))]

class DensityTests(unittest.TestCase):
    def plan(self, starts=(1,21), ends=(5,10,15,20,25,30,35,40)):
        return {'fps':24,'takes':[{'source':'v','start':0,'end':ends[-1]}],
                'sound_sentences':sentences(list(ends)),
                'sounds':[{'start':t,'path':'example.wav'} for t in starts]}

    def test_long_sentences_pass_without_seconds_limit(self):
        r=from_plan(self.plan((15,95),(20,40,60,80,100,120)));require_spacing(r)
        self.assertEqual(r['largest_gap_seconds'],80)
        self.assertFalse(r['actual_listening'])

    def test_every_sliding_four_including_ending(self):
        r=from_plan(self.plan((1,)))
        self.assertEqual(r['violations'][0]['first_sentence'],2)
        self.assertEqual(r['violations'][-1]['last_sentence'],8)
        with self.assertRaisesRegex(ValueError,'sentence coverage incomplete'):require_spacing(r)

    def test_four_short_sentences_still_need_sound(self):
        with self.assertRaises(ValueError):require_spacing(from_plan(self.plan((),(1,2,3,4))))
        require_spacing(from_plan(self.plan((),(1,2,3))))

    def test_caption_blocks_cannot_substitute_for_sentences(self):
        p=self.plan();p.pop('sound_sentences');p['captions']=[{'text':'短语'}]*100
        with self.assertRaisesRegex(ValueError,'sound_sentences'):require_spacing(from_plan(p))

    def test_sentence_ranges_cover_whole_edit(self):
        p=self.plan();p['sound_sentences'][1]['start']+=.1
        with self.assertRaisesRegex(ValueError,'whole edit'):from_plan(p)

    def test_muted_music_duplicates_long_tail_not_extra_events(self):
        p=self.plan((1,1,21,22))
        p['sounds'][2]['volume']=0;p['sounds'][3]['kind']='music'
        for c in p['sounds']:c['duration']=39
        r=from_plan(p);self.assertEqual(r['distinct_event_count'],1)
        with self.assertRaises(ValueError):require_spacing(r)
        p['sounds'][0]['start']=float('nan')
        with self.assertRaises(ValueError):from_plan(p)

    def test_native_uses_actual_clips_and_requires_sentence_plan(self):
        d={'fps':24,'duration':40000000,'materials':{'audios':[{'id':'s','type':'sound','path':'example.wav'}]},
           'tracks':[{'type':'audio','segments':[{'material_id':'s','target_timerange':{'start':t*1000000,'duration':500000}} for t in (1,21)]}]}
        p=self.plan();before=copy.deepcopy(d)
        require_spacing(from_native(d,p));self.assertEqual(d,before)
        with self.assertRaisesRegex(ValueError,'sound_sentences'):require_spacing(from_native(d))
        d['tracks'][0]['segments'].pop()
        with self.assertRaises(ValueError):require_spacing(from_native(d,p))

    def test_onset_offset_is_respected(self):
        p=self.plan((1,21))
        for c in p['sounds']:c.update(duration=8,selection={'anchor':{'sound_offset_seconds':4}})
        self.assertEqual([e['at'] for e in from_plan(p)['events']],[5,25])
