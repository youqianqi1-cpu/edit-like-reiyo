from test_external_fixtures import metadata,review
import copy
import json
from pathlib import Path
import tempfile
import unittest
import wave

from compose_beats import compose
from assemble import build
from punchline_events import check_plan, check_native
import draft_io


class PunchlineTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.raw=self.root/'raw.mp4';self.raw.touch()
        self.sound=self.root/'reaction.wav'
        with wave.open(str(self.sound),'wb') as w:
            w.setparams((1,2,16000,0,'NONE','not compressed'));w.writeframes(b'\x00\x01'*6400)
        self.plan={'fps':24,'sound_sentences':[{'text':'Synthetic setup and self-correction.','start':0,'end':5}],'canvas':{'width':1080,'height':1920,'ratio':'9:16'},'font':str(self.raw),
          'sources':{'raw':{'path':str(self.raw),'duration':15,'width':1080,'height':1920}},
          'takes':[{'source':'raw','start':10,'end':15,'scale':1.185,'x':.1,'y':-.1,'volume':.9}],
          'captions':[{'text':'合成测试句','start':0,'end':5}],
          'punchline_review':{'reason':'Synthetic fixture, not real footage judgement','candidates':[
            {'id':'j1','source':'raw','start':10,'end':15,'quote':'Synthetic setup and self-correction',
             'evidence':'synthetic fixture only','selected':True,'reason':'Synthetic contrasting reveal'}]}}
        self.beat={'type':'punchline','candidate_id':'j1','source':'raw','reason':'Synthetic contrast',
          'start':10,'shrink_at':11,'restore_at':12,'end':13,'scale':.75,
          'sound':{'path':str(self.sound),'at':11,'duration':.4}}

    def compose(self, beats=None):
        return compose(self.plan,beats or [self.beat],self.root/'generated')

    def native(self, plan=None):
        return build({'id':'synthetic'},plan or self.compose(),settings={'fps':24})[0]

    def test_linked_event_preserves_cuts_voice_captions_and_input(self):
        before=copy.deepcopy(self.plan);p=self.compose();d=self.native(p)
        self.assertEqual(before,self.plan)
        self.assertEqual(p['captions'],before['captions'])
        self.assertEqual([(t['start'],t['end']) for t in p['takes']],[(10,11),(11,12),(12,15)])
        self.assertEqual([t['volume'] for t in p['takes']],[.9]*3)
        self.assertEqual([t['scale'] for t in p['takes']],[1.185,.75,1.185])
        self.assertEqual(d['duration'],5000000)
        self.assertEqual(check_native(p,d)['selected'],1)

    def test_pending_track_alias_still_requires_one_identifiable_main_track(self):
        p=self.compose();draft=self.native(p)
        main=next(t for t in draft['tracks'] if t['name']=='原素材 · 独立选段')
        main['name']='待审预览 · 气口未验收'
        self.assertEqual(check_native(p,draft)['selected'],1)
        bad=copy.deepcopy(draft);duplicate=copy.deepcopy(main);duplicate['name']='原素材 · 独立选段';bad['tracks'].append(duplicate)
        with self.assertRaisesRegex(ValueError,'identify'):check_native(p,bad)
        main['name']='unrelated track'
        with self.assertRaisesRegex(ValueError,'identify'):check_native(p,draft)

    def test_native_omitted_zero_starts_preserve_checks(self):
        self.beat['sound']['volume']=1
        p=self.compose();d=self.native(p)
        for track in d['tracks']:
            for seg in track['segments']:
                if seg.get('volume')==1:seg.pop('volume')
                for field in ('source_timerange','target_timerange'):
                    if seg.get(field,{}).get('start')==0:seg[field].pop('start')
        d['tracks'][0]['segments'][0]['source_timerange']['duration']+=1
        self.assertEqual(check_native(p,d)['selected'],1)
        bad=copy.deepcopy(d)
        bad['tracks'][0]['segments'][0]['source_timerange']['duration']+=41667
        with self.assertRaisesRegex(ValueError,'source/voice'):check_native(p,bad)
        bad=copy.deepcopy(d)
        next(t for t in bad['tracks'] if t['type']=='text')['segments'][0]['target_timerange']['start']=41667
        with self.assertRaisesRegex(ValueError,'captions changed'):check_native(p,bad)
        bad=copy.deepcopy(d)
        next(t for t in bad['tracks'] if t['type']=='audio')['segments'][0]['source_timerange']['start']=41667
        with self.assertRaisesRegex(ValueError,'sound muted'):check_native(p,bad)

    def test_missing_review_selected_event_and_unselected_reason_are_rejected(self):
        for change in ['missing_review','missing_event','missing_reason']:
            p=copy.deepcopy(self.plan)
            if change=='missing_review':p.pop('punchline_review')
            elif change=='missing_reason':
                p['punchline_review']['candidates'][0].update(selected=False,reason='')
            with self.subTest(change=change),self.assertRaises(ValueError):check_plan(p,24)

    def test_decline_and_no_candidates_do_not_force_effects(self):
        for candidates in [[],[dict(self.plan['punchline_review']['candidates'][0],selected=False,reason='A serious correction; preserve tone')]]:
            self.plan['punchline_review']['candidates']=candidates
            p=compose(self.plan,[],self.root)
            self.assertEqual(p['takes'],self.plan['takes']);self.assertEqual(p['sounds'],[])
            self.native(p)

    def test_return_to_baseline_is_not_shrink(self):
        self.beat['scale']=1.185
        with self.assertRaisesRegex(ValueError,'NORMAL'):self.compose()

    def test_overwrite_after_event_or_before_event_fails(self):
        overwrite={'type':'scene','source':'raw','start':11,'end':12,'scale':1.30,'reason':'test override'}
        with self.assertRaisesRegex(ValueError,'overwritten'):self.compose([self.beat,overwrite])
        overwrite.update(start=10,end=11)
        with self.assertRaisesRegex(ValueError,'overwritten'):self.compose([overwrite,self.beat])

    def test_no_existing_motion_or_personal_framing_overwrite(self):
        self.plan['takes'][0]['keys']={'KFTypeScaleX':[(0,1.185),(.5,1.3)]}
        with self.assertRaisesRegex(ValueError,'overwrite existing'):self.compose()

    def test_bad_landing_and_missing_fps_fail(self):
        self.beat['sound']['at']=11.5
        with self.assertRaisesRegex(ValueError,'landing'):self.compose()
        self.beat['sound']['at']=11;self.plan.pop('fps')
        with self.assertRaisesRegex(ValueError,'actual fps'):self.compose()

    def test_native_missing_shrink_restore_sound_and_muted_sound_fail(self):
        p=self.compose();native=self.native(p)
        for mode in ['shrink','restore','sound','muted','key_override','source_cut','voice','sound_tail']:
            d=copy.deepcopy(native);main=next(t for t in d['tracks'] if t['type']=='video')['segments']
            audio=next(t for t in d['tracks'] if t['type']=='audio')['segments']
            if mode=='shrink':main[1]['clip']['scale']={'x':1.185,'y':1.185}
            elif mode=='restore':main[2]['clip']['scale']={'x':.75,'y':.75}
            elif mode=='sound':audio.clear()
            elif mode=='muted':audio[0]['volume']=0
            elif mode=='key_override':main[1]['common_keyframes']=[{'property_type':'KFTypeScaleX'}]
            elif mode=='source_cut':main[1]['source_timerange']['start']+=41667
            elif mode=='voice':main[1]['volume']=.5
            elif mode=='sound_tail':audio[0]['target_timerange']['duration']=41667
            with self.subTest(mode=mode),self.assertRaises(ValueError):check_native(p,d)

    def test_plan_sound_loss_or_change_fails_assembly(self):
        for mode in ['remove','mute','shift']:
            p=self.compose()
            if mode=='remove':p['sounds']=[]
            elif mode=='mute':p['sounds'][0]['volume']=0
            else:p['sounds'][0]['start']+=.5
            with self.subTest(mode=mode),self.assertRaises(ValueError):self.native(p)

    def test_native_caption_loss_or_retime_is_rejected(self):
        p=self.compose();d=self.native(p)
        captions=next(t for t in d['tracks'] if t['type']=='text')
        captions['segments'][0]['target_timerange']['start']+=41667
        with self.assertRaisesRegex(ValueError,'captions changed'):check_native(p,d)

    def test_fps_mismatch_and_duplicate_event_are_rejected(self):
        p=self.compose()
        with self.assertRaisesRegex(ValueError,'fps differs'):check_plan(p,30)
        p['punchline_events']*=2
        with self.assertRaisesRegex(ValueError,'duplicated'):check_plan(p,24)

    def test_later_plan_cannot_change_approved_source_cuts_or_voice(self):
        for field,value in [('start',11.25),('volume',.2)]:
            p=self.compose();p['takes'][1][field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):check_plan(p,24)

    def test_cut_before_linked_punchline_retimes_all_phases_and_sound(self):
        from apply_cuts import apply
        self.plan['takes'].insert(0,{'source':'raw','start':0,'end':1,'scale':1.185,'x':.1,'y':-.1,'volume':.9})
        self.plan['captions'][0].update(start=1,end=6)
        self.plan['sound_sentences'][0]['end']=6
        p=self.compose();q,_=apply(p,[{'source':'raw','start':.5,'end':1}])
        self.assertEqual(q['sound_sentences'][0]['end'],5.5)
        self.assertEqual(q['punchline_events'][0]['shrink_at'],1.5)
        self.assertEqual(q['punchline_events'][0]['sound']['start'],1.5)
        check_plan(q,24);self.native(q)
        with self.assertRaisesRegex(ValueError,'intersects a linked punchline'):
            apply(p,[{'source':'raw','start':11.5,'end':11.75}])

    def test_save_readback_checks_selected_event_before_write(self):
        p=self.compose();d=self.native(p);folder=self.root/'synthetic-closed';folder.mkdir()
        active=folder/'draft_info.json';active.write_text(json.dumps({'id':'synthetic','tracks':[]}))
        candidate=self.root/'candidate.json';candidate.write_text(json.dumps(d));metadata(folder);review(candidate)
        from unittest.mock import patch
        with patch('draft_io.require_breath_review',return_value={'fixture_only':True}):
            receipt=draft_io.install(folder,candidate,draft_io.sha(active),folder.name,True,plan=p)
        self.assertTrue(receipt['punchline_structure_verified'])
        self.assertEqual(check_native(p,draft_io.read(folder))['selected'],1)
        d['tracks'][0]['segments'][1]['clip']['scale']={'x':1.185,'y':1.185}
        candidate.write_text(json.dumps(d));protected=active.read_bytes()
        with self.assertRaises(ValueError):draft_io.install(folder,candidate,draft_io.sha(active),folder.name,True,plan=p)
        self.assertEqual(active.read_bytes(),protected)


if __name__=='__main__':unittest.main()

# These fixtures have dummy video files; real final-signal gate tests live in test_final_breaths.
def setUpModule():
    from unittest.mock import patch
    global _signal_patch
    _signal_patch = patch('assemble.require_breath_review', return_value={'fixture_only': True})
    _signal_patch.start()
def tearDownModule():
    _signal_patch.stop()
