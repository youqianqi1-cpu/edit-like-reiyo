"""Replace SFX only in a read-back draft, preserving picture, text and native voice effects."""
import argparse, copy, json
from pathlib import Path
from assemble import build, check_spacing_for_scope
from sound_density import from_native
from breath_review import require_review, output_record, check_native
from punchline_events import check_native as check_punchlines


def replace(saved, plan, pending_preview=False):
    fresh,_=build(saved,plan,pending_preview=pending_preview)
    result=copy.deepcopy(saved)
    audio={m['id']:m for m in saved['materials'].get('audios',[])}
    old_ids=set()
    tracks=[]
    for track in result['tracks']:
        flags=[audio.get(s.get('material_id'),{}).get('type')=='sound' for s in track.get('segments',[])] if track['type']=='audio' else []
        if any(flags):
            if not all(flags):raise ValueError('Mixed music/SFX track; separate it before replacing SFX')
            old_ids.update(s['material_id'] for s in track['segments'])
        else:tracks.append(track)
    result['tracks']=tracks+[t for t in fresh['tracks'] if t['type']=='audio']
    result['materials']['audios']=[m for m in result['materials'].get('audios',[]) if m['id'] not in old_ids]+fresh['materials']['audios']
    check_spacing_for_scope(plan,from_native(result,plan))
    check_native(plan,result);check_punchlines(plan,result)
    record=output_record(require_review(plan,final=not pending_preview,pending_preview=pending_preview),pending_preview,result)
    result['reiyo_breath_review']=record
    return result,record


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('saved',type=Path);ap.add_argument('plan',type=Path);ap.add_argument('output',type=Path);ap.add_argument('--pending-preview',action='store_true');a=ap.parse_args()
    rp=Path(str(a.output)+'.breath-review.json')
    if a.output.exists() or rp.exists():raise ValueError('Use a new output name')
    result,record=replace(json.loads(a.saved.read_text()),json.loads(a.plan.read_text()),a.pending_preview)
    a.output.write_text(json.dumps(result,ensure_ascii=False));rp.write_text(json.dumps(record,ensure_ascii=False,indent=2))
    print('SFX replaced; picture, captions and native voice effects preserved. Listening remains separate.')
