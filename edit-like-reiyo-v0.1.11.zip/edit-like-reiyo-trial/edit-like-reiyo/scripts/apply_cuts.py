"""Apply reviewed source-time removals to a plan and retime every dependent layer.
Never finds or approves cuts. Input ranges must be individually reviewed.
"""
import copy,json,pathlib,argparse,wave
from media_settings import plan_fps

def apply(plan,cuts,review_output=None,analysis_root=None):
 p=copy.deepcopy(plan);fps=plan_fps(p);frame=lambda x:round(x*fps);sec=lambda x:x/fps
 pieces=[];takes=[];old_at=new_at=0
 for take in p['takes']:
  a,b=frame(take['start']),frame(take['end']);ranges=[(a,b)]
  for cut in cuts:
   if cut['source']!=take['source']:continue
   l,r=frame(cut['start']),frame(cut['end']);assert l<r
   out=[]
   for x,y in ranges:
    if r<=x or l>=y:out.append((x,y));continue
    if x<l:out.append((x,l))
    if r<y:out.append((r,y))
   ranges=out
  for x,y in ranges:
   n=copy.deepcopy(take);n.update(start=sec(x),end=sec(y));n.pop('at',None);n.pop('duration',None)
   for prop,pts in n.get('keys',{}).items():
    def val(t):
     if t<=pts[0][0]:return pts[0][1]
     for (l,v),(r,w) in zip(pts,pts[1:]):
      if t<=r:return v+(w-v)*(t-l)/(r-l)
     return pts[-1][1]
    lo,hi=sec(x-a),sec(y-a);n['keys'][prop]=[[0,val(lo)],*[[t-lo,v]for t,v in pts if lo<t<hi],[hi-lo,val(hi)]]
   takes.append(n);pieces.append((old_at+x-a,old_at+y-a,new_at));new_at+=y-x
  old_at+=b-a
 def point(t):
  f=frame(t)
  for a,b,n in pieces:
   if f<a:return sec(n)
   if f<=b:return sec(n+f-a)
  return sec(new_at)
 p['takes']=takes
 for event in p.get('punchline_events',[]):
  if frame(point(event['end'])-point(event['start']))!=frame(event['end']-event['start']):raise ValueError('Cut intersects a linked punchline; re-plan its phases and sound together')
 for group in ['captions','titles','sounds','overlays','caption_promotions']+(['sound_sentences'] if p.get('sound_sentences') else []):
  result=[]
  for item in p.get(group,[]):
   a=item['start'];n=copy.deepcopy(item);n['start']=point(a)
   moving=group=='overlays' and p['sources'][item['source']].get('type')!='photo'
   if group=='sounds' or moving:
    if group=='sounds':
     if 'duration' in item:duration=item['duration']
     else:
      with wave.open(item['path']) as w:duration=w.getnframes()/w.getframerate()-item.get('source_start',0)
     end=min(sec(old_at),a+duration)
    else:end=item['end']
    if frame(end)<=frame(a):continue
    intersections=[]
    for old_start,old_end,new_start in pieces:
     lo=max(frame(a),old_start);hi=min(frame(end),old_end)
     if hi>lo:
      row=(lo,hi,new_start+lo-old_start)
      if intersections and intersections[-1][1]==lo and intersections[-1][2]+intersections[-1][1]-intersections[-1][0]==row[2]:
       intersections[-1]=(intersections[-1][0],hi,intersections[-1][2])
      else:intersections.append(row)
    for lo,hi,at in intersections:
     segment=copy.deepcopy(item);segment['start']=sec(at)
     segment['source_start']=item.get('source_start',0)+sec(lo-frame(a))
     if group=='sounds':segment['duration']=sec(hi-lo)
     else:segment['end']=sec(at+hi-lo)
     for prop,pts in item.get('keys',{}).items():
      def value(dt):
       if dt<=pts[0][0]:return pts[0][1]
       for (x,v),(y,w) in zip(pts,pts[1:]):
        if dt<=y:return v+(w-v)*(dt-x)/(y-x)
       return pts[-1][1]
      begin=sec(lo-frame(a));stop=sec(hi-frame(a))
      segment['keys'][prop]=[[0,value(begin)],*[[dt-begin,v]for dt,v in pts if begin<dt<stop],[stop-begin,value(stop)]]
     anchor=segment.get('selection',{}).get('anchor',{})
     if 'timeline_seconds' in anchor:
      anchor['timeline_seconds']=point(anchor['timeline_seconds'])
      anchor['sound_offset_seconds']=anchor['timeline_seconds']-segment['start']
     if len(intersections)>1 or sum(y-x for x,y,z in intersections)!=frame(end)-frame(a):
      segment['retiming_review_required']='Source split at removed speech; review continuity and perceptual sound anchor before delivery'
     result.append(segment)
    continue
   if 'end'in item:
    n['end']=point(item['end'])
    if n['end']<=n['start']:continue
    for prop,pts in item.get('keys',{}).items():
     keys={}
     for dt,v in pts:keys[max(0,min(n['end']-n['start'],point(a+dt)-n['start']))]=v
     n['keys'][prop]=[[k,v]for k,v in sorted(keys.items())]
   result.append(n)
  p[group]=result
 for event in p.get('punchline_events',[]):
  for field in ('start','shrink_at','restore_at','end'):event[field]=point(event[field])
  event['sound']=copy.deepcopy(next(c for c in p['sounds'] if c.get('punchline_id')==event['id']))
 if p.get('punchline_events'):
  from punchline_events import protected_takes,check_plan
  p['punchline_protected_takes']=protected_takes(p,fps);check_plan(p,fps)
 from breath_review import cut_signature,cut_rows,pending_decisions
 before_sig=cut_signature(plan);after_sig=cut_signature(p)
 metadata={'before':sec(old_at),'after':sec(new_at),'pieces':pieces}
 if before_sig!=after_sig:
  prior=p.pop('breath_review',None)
  closure={'previous_cut_signature':before_sig,'cut_signature':after_sig,'old_review_invalidated':True,
           'formal_accepted':False,'actual_listening':False,'status':'rescan_required'}
  p['breath_review_state']=closure
  try:
   root=analysis_root
   threshold=.02
   if prior and prior.get('report') and (root is None or pathlib.Path(prior['report']).is_file()):
    old=json.loads(pathlib.Path(prior['report']).read_text(encoding='utf-8'))
    if root is None:root=old['analysis_root']
    threshold=old['threshold_is_candidate_only']
   if root is None:
    root=plan.get('breath_review_state',{}).get('analysis_root')
   if root is not None:
    from audit_breaths import audit
    closure['analysis_root']=str(pathlib.Path(root).resolve())
    scan_plan=dict(p,takes=[{'source':k,'start':a/fps,'end':b/fps}for k,a,b in cut_rows(p)])
    report=audit(scan_plan,root,threshold);decisions=pending_decisions(report)
    metadata['post_edit_scan']=report;metadata['post_edit_decisions']=decisions
    closure.update(status='review_pending',scan_signature=report['scan_signature'])
    if review_output is not None:
     folder=pathlib.Path(review_output);folder.mkdir(parents=True,exist_ok=True)
     rp=folder/'scan.json';dp=folder/'decisions.json'
     if rp.exists() or dp.exists():raise ValueError('Review output already exists; choose a fresh folder')
     rp.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
     dp.write_text(json.dumps(decisions,ensure_ascii=False,indent=2),encoding='utf-8')
     p['breath_review']={'report':str(rp.resolve()),'decisions':str(dp.resolve())}
   else:closure['reason']='No analysis_root available; cuts retained but review is invalid until a new scan'
  except (OSError,ValueError,KeyError,TypeError) as error:
   p.pop('breath_review',None);closure.update(status='rescan_failed',reason=str(error))
  metadata['breath_review_state']=closure
 return p,metadata
if __name__=='__main__':
 ap=argparse.ArgumentParser()
 ap.add_argument('plan',type=pathlib.Path);ap.add_argument('cuts',type=pathlib.Path);ap.add_argument('output',type=pathlib.Path)
 ap.add_argument('--analysis-root',type=pathlib.Path)
 a=ap.parse_args()
 if a.output.resolve()==a.plan.resolve() or a.output.exists():raise ValueError('Use a new output plan; preserve the original')
 p,m=apply(json.loads(a.plan.read_text(encoding='utf-8')),json.loads(a.cuts.read_text(encoding='utf-8')),
           review_output=a.output.with_suffix('.breath-review'),analysis_root=a.analysis_root)
 a.output.write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
 a.output.with_suffix('.retiming.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
 print(m['before'],m['after'],len(p['takes']),p.get('breath_review_state',{}).get('status','cuts_unchanged'))
