import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import wave
from prepare_assets import prepare
from assemble import build


class StarterAssetsTest(unittest.TestCase):
    def test_empty_library_can_build_and_keeps_modified_resources(self):
        with tempfile.TemporaryDirectory(prefix='reiyo 空素材 ') as tmp:
            project = Path(tmp)
            resources = prepare(project)
            self.assertEqual(resources, prepare(project))
            self.assertEqual(len(resources['sounds']), 18)
            for cue in resources['sounds']:
                with wave.open(cue['path']) as audio:
                    self.assertEqual(audio.getsampwidth(), 2)
                    self.assertEqual(audio.getframerate(), 48000)
                    self.assertGreater(audio.getnframes(), 0)
            # Mock only media probing; this fixture tests real resource binding.
            video = project / 'source.mp4'
            video.touch()
            plan = dict(sound_sentences=[dict(text='Synthetic resource-binding sentence.',start=0,end=6)],fps=25,canvas=dict(width=1080, height=1920, ratio='9:16'),
                        sources={'v': dict(path=str(video), duration=6, width=1080, height=1920)},
                        takes=[dict(source='v', start=0, end=6)],
                        font=resources['font'], title_font=resources['title_font'],
                        captions=[dict(text='先把话讲清楚', start=0, end=2)],
                        titles=[dict(text='老板，你挑吧！', start=2, end=4)],
                        sounds=[dict(path=resources['sounds'][0]['path'], start=2)])
            with patch('media_settings.probe_source', return_value={'fps': 25}):
                plan['punchline_review']={'reason':'Synthetic assets fixture; no humour candidates','candidates':[]}
                draft, mapping = build({'id':'fixture'}, plan)
            self.assertEqual(draft['duration'], 6000000)
            self.assertEqual({t['font_path'] for t in draft['materials']['texts']},
                             {resources['font'], resources['title_font']})
            self.assertEqual(draft['materials']['audios'][0]['path'], resources['sounds'][0]['path'])
            sound_track = next(t for t in draft['tracks'] if t['type'] == 'audio')
            self.assertEqual(sound_track['segments'][0]['volume'], 1.0)
            changed = Path(resources['sounds'][0]['path'])
            changed.write_bytes(b'user-edited')
            with self.assertRaises(ValueError):
                prepare(project)
            self.assertEqual(changed.read_bytes(), b'user-edited')




# These fixtures have dummy video files; real final-signal gate tests live in test_final_breaths.
def setUpModule():
    from unittest.mock import patch
    global _signal_patch
    _signal_patch = patch('assemble.require_breath_review', return_value={'fixture_only': True})
    _signal_patch.start()
def tearDownModule():
    _signal_patch.stop()

if __name__ == '__main__': unittest.main()
