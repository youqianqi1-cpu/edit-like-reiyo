"""Adopt explicitly planned UI voice effects after saving; never edit a draft or approve hearing."""
import argparse,copy,json,pathlib
from breath_review import check_native,require_review,output_record


def normalized(draft):
 d=copy.deepcopy(draft);d.pop('reiyo_breath_review',None)
 for m in d['materials'].get('sound_channel_mappings',[]):
  if m=={'id':m.get('id'),'type':''}:m['type']='none'
 for m in d['materials'].get('audio_effects',[]):
  m.pop('category_id',None);m.pop('category_name',None)
 return d


def adopt(plan,before,saved):
 expected=plan.get('native_voice_effects',[])
 if not expected:raise ValueError('Record native_voice_effects with timeline start,end,name before applying effects')
 a,b=normalized(before),normalized(saved)
 if a.get('id')!=b.get('id'):raise ValueError('Different draft identity')
 main=next(t for t in b['tracks'] if t['type']=='video');old=next(t for t in a['tracks'] if t['type']=='video')
 effects={m['id']:m for m in b['materials'].get('audio_effects',[])};old_effects={m['id']:m for m in a['materials'].get('audio_effects',[])}
 fps=b['fps'];covered=[0]*len(expected)
 if len(main['segments'])!=len(old['segments']):raise ValueError('Segment boundaries changed; inspect and update the plan separately')
 for previous,seg in zip(old['segments'],main['segments']):
  r=seg['target_timerange'];lo=round(r.get('start',0)*fps/1e6);hi=lo+round(r['duration']*fps/1e6)
  matches=[i for i,e in enumerate(expected) if lo<round(e['end']*fps) and hi>round(e['start']*fps)]
  actual=[effects[x] for x in seg.get('extra_material_refs',[]) if x in effects]
  if matches:
   if len(matches)!=1:raise ValueError('Overlapping voice effect ranges')
   i=matches[0];e=expected[i];start,end=round(e['start']*fps),round(e['end']*fps)
   if not start<=lo<hi<=end or len(actual)!=1 or actual[0].get('name')!=e['name']:raise ValueError('Effect missing, wrong or extends outside its intended range')
   covered[i]+=hi-lo
  elif actual!=[old_effects[x] for x in previous.get('extra_material_refs',[]) if x in old_effects]:raise ValueError('An unplanned voice effect changed')
  seg['extra_material_refs']=[x for x in seg.get('extra_material_refs',[]) if x not in effects]
  previous['extra_material_refs']=[x for x in previous.get('extra_material_refs',[]) if x not in old_effects]
 for i,e in enumerate(expected):
  if e['name']!='扩音器' or covered[i]!=round(e['end']*fps)-round(e['start']*fps):raise ValueError('Voice effect range is incomplete')
 a['materials'].pop('audio_effects',None);b['materials'].pop('audio_effects',None)
 if a!=b:raise ValueError('Other picture, text, timing or sound changed; inspect separately')
 check_native(plan,saved);r=require_review(plan,final=False,pending_preview=True)
 result=copy.deepcopy(saved);record=output_record(r,True,result);result['reiyo_breath_review']=record
 return result,record


if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('plan',type=pathlib.Path);ap.add_argument('before',type=pathlib.Path);ap.add_argument('saved',type=pathlib.Path);ap.add_argument('output',type=pathlib.Path);args=ap.parse_args()
 if args.output.exists() or pathlib.Path(str(args.output)+'.breath-review.json').exists():raise ValueError('Use a new output path')
 d,r=adopt(*[json.loads(p.read_text()) for p in (args.plan,args.before,args.saved)])
 args.output.write_text(json.dumps(d,ensure_ascii=False));pathlib.Path(str(args.output)+'.breath-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
 print('Native effects checked; new pending-preview record prepared. Existing draft untouched; actual listening still pending.')
