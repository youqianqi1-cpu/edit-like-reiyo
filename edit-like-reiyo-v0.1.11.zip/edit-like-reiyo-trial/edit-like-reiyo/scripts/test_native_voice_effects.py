import copy,unittest
from unittest.mock import patch
from native_voice_effects import adopt
class NativeVoiceEffectsTests(unittest.TestCase):
 def setUp(self):
  for name,value in [('check_native',None),('require_review',{}),('output_record',{'mode':'pending_preview'})]:
   p=patch('native_voice_effects.'+name,return_value=value);p.start();self.addCleanup(p.stop)
  self.plan={'native_voice_effects':[{'start':0,'end':1,'name':'扩音器'}]}
  self.before={'id':'test','fps':24,'materials':{'videos':[],'audio_effects':[]},'tracks':[{'type':'video','segments':[{'id':'s','target_timerange':{'start':0,'duration':1000000},'extra_material_refs':[],'volume':1}]}]}
  self.saved=copy.deepcopy(self.before);self.saved['materials']['audio_effects']=[{'id':'fx','name':'扩音器','resource_id':'real','category_name':'热门'}];self.saved['tracks'][0]['segments'][0]['extra_material_refs']=['fx']
 def test_adopts_only_planned_effect_without_mutating_input(self):
  old=copy.deepcopy(self.saved);d,r=adopt(self.plan,self.before,self.saved);self.assertEqual(self.saved,old);self.assertEqual(r['mode'],'pending_preview');self.assertEqual(d['materials']['audio_effects'][0]['name'],'扩音器')
 def test_rejects_unrelated_volume_or_caption_change(self):
  for kind in ('volume','text'):
   d=copy.deepcopy(self.saved)
   if kind=='volume':d['tracks'][0]['segments'][0]['volume']=.5
   else:d['materials']['texts']=[{'text':'changed'}]
   with self.assertRaises(ValueError):adopt(self.plan,self.before,d)
 def test_rejects_wrong_effect_and_incomplete_range(self):
  d=copy.deepcopy(self.saved);d['materials']['audio_effects'][0]['name']='机器人'
  with self.assertRaises(ValueError):adopt(self.plan,self.before,d)
  p=copy.deepcopy(self.plan);p['native_voice_effects'][0]['end']=2
  with self.assertRaises(ValueError):adopt(p,self.before,self.saved)
 def test_allows_only_category_metadata_on_saved_effect(self):
  b=copy.deepcopy(self.saved);b['materials']['audio_effects'][0]['category_name']='模拟'
  adopt(self.plan,b,self.saved)
if __name__=='__main__':unittest.main()
