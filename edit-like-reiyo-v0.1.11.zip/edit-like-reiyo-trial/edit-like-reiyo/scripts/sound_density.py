from media_settings import plan_fps
"""Check SFX event spacing over the WHOLE edit; never inserts or selects a sound.

Seek a suitable cue every three complete spoken sentences; any four must contain one.
Events are onsets, not the duration of a long sound or background music.
Native checks prove track structure, not actual hearing or perceptual suitability.
"""
import argparse
import json
import math
from pathlib import Path



def number(value, label):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError(label + ' must be finite')
    return value


def review(duration, events, sentences=None):
    duration = number(duration, 'duration')
    if duration <= 0:
        raise ValueError('Duration must be positive')
    events = sorted(events, key=lambda e: e['at'])
    for event in events:
        if not 0 <= number(event['at'], 'sound event') < duration:
            raise ValueError('Sound event outside edit')
    times = sorted(set(e['at'] for e in events))
    bounds = [0., *times, duration]
    gaps = [{'start': a, 'end': b, 'seconds': b-a}
            for a,b in zip(bounds,bounds[1:]) if b>a]
    groups, violations, suggestions = [], [], []
    if sentences is not None:
        if not sentences:
            raise ValueError('Record complete spoken sentences, not caption blocks')
        cursor = 0.
        for i, item in enumerate(sentences):
            a = number(item['start'], 'sentence start')
            b = number(item['end'], 'sentence end')
            if not item.get('text','').strip() or abs(a-cursor)>.00001 or not a<b<=duration+.00001:
                raise ValueError('Sentences must cover the whole edit in order, with complete spoken text')
            groups.append(dict(item, index=i+1, event_count=sum(a<=t<b for t in times)))
            cursor=b
        if abs(cursor-duration)>.00001:
            raise ValueError('Sentence coverage does not reach the end')
        for i in range(len(groups)-3):
            window=groups[i:i+4]
            if not sum(x['event_count'] for x in window):
                violations.append({'first_sentence':i+1,'last_sentence':i+4,
                                   'start':window[0]['start'],'end':window[-1]['end']})
        for i in range(0,len(groups)-2,3):
            window=groups[i:i+3]
            if not sum(x['event_count'] for x in window):
                suggestions.append({'first_sentence':i+1,'last_sentence':i+3,
                                    'within':[window[0]['start'],window[-1]['end']],
                                    'action':'Find a suitable stress, reaction, reveal or transition in these complete sentences'})
    repeated=[]
    run=[]
    for e in events+[{'key':None,'at':duration}]:
        if run and e.get('key')!=run[-1].get('key'):
            if len(run)>=3:repeated.append({'key':run[0].get('key'),'count':len(run),'start':run[0]['at'],'end':run[-1]['at']})
            run=[]
        run.append(e)
    return {'status':'sentence_review_pending' if sentences is None else 'needs_more_events' if violations else 'spacing_passed',
            'duration':duration,'rule':'seek a cue every three complete spoken sentences; at least one cue in any four consecutive sentences',
            'events':events,'distinct_event_count':len(times),'sentences':groups,
            'largest_gap_seconds':max((g['seconds'] for g in gaps),default=duration),
            'gaps':gaps,'violations':violations,'planning_search_points':suggestions,
            'repeated_runs_to_review':repeated,'actual_listening':False,'semantic_or_aesthetic_approval':False}


def from_plan(plan, fps=None):
    fps = plan_fps(plan) if fps is None else plan_fps(plan, fps)
    if fps <= 0:
        raise ValueError('Positive verified fps required')
    snap = lambda x: round(round(number(x, 'time')*fps)*1e6/fps)
    duration_us = sum(snap(t['end'])-snap(t['start']) for t in plan['takes'])
    duration = snap(duration_us/1e6)/1e6
    events = []
    for i, cue in enumerate(plan.get('sounds', [])):
        if cue.get('kind', 'sound') != 'sound' or cue.get('muted') or number(cue.get('volume', 1), 'volume') <= 0:
            continue
        anchor = (cue.get('selection') or {}).get('anchor') or {}
        offset = number(anchor.get('sound_offset_seconds', 0), 'sound offset')
        if offset < 0 or ('duration' in cue and offset >= number(cue['duration'], 'sound duration')):
            raise ValueError('Sound anchor lies outside selected sound')
        at = snap(cue['start'])/1e6 + offset
        events.append({'at': at, 'key': cue.get('path'), 'cue_index': i,
                       'timing_basis': 'recorded_event_offset' if anchor else 'clip_start_only'})
    result = review(duration, events, plan.get('sound_sentences'))
    result['source'] = 'plan'
    return result


def from_native(draft, plan=None):
    materials = {m['id']: m for m in draft.get('materials', {}).get('audios', [])}
    events, ignored = [], []
    for tr in draft.get('tracks', []):
        if tr.get('type') != 'audio':
            continue
        for seg in tr.get('segments', []):
            mat = materials.get(seg.get('material_id'), {})
            if mat.get('type') != 'sound':
                ignored.append({'segment_id': seg.get('id'), 'reason': 'not explicitly a sound-effect material'})
                continue
            if tr.get('muted') or tr.get('is_muted') or seg.get('muted') or seg.get('is_muted') or number(seg.get('volume', 1), 'volume') <= 0:
                continue
            r = seg['target_timerange']
            if r['duration'] <= 0:
                continue
            events.append({'at': r.get('start', 0)/1e6, 'key': mat.get('path') or mat.get('name'),
                           'segment_id': seg.get('id'), 'timing_basis': 'saved_clip_start_only'})
    if plan:
        # Match saved clips before using the selected file's measured onset offset.
        cues={(str(Path(c['path']).resolve()),round(c['start']*draft['fps'])):c for c in plan.get('sounds',[])}
        for event in events:
            cue=cues.get((str(Path(event['key']).resolve()),round(event['at']*draft['fps'])))
            if cue:
                anchor=(cue.get('selection') or {}).get('anchor') or {}
                event['at']+=number(anchor.get('sound_offset_seconds',0),'sound offset')
                event['timing_basis']='saved_clip_with_plan_onset' if anchor else 'saved_clip_start_only'
    result = review(draft['duration']/1e6, events, plan.get('sound_sentences') if plan else None)
    result.update(source='saved_native_structure', ignored_audio=ignored,
                  unknown_platform_mute_flags_verified=False,
                  note='Compare these saved segments with plan anchors; unknown platform flags and actual audio need playback.')
    return result


def require_spacing(report):
    if report['status']=='sentence_review_pending':
        raise ValueError('Record sound_sentences with complete spoken sentences before checking sound coverage')
    if report['violations']:
        spans=', '.join(f"sentences {x['first_sentence']}–{x['last_sentence']}" for x in report['violations'])
        raise ValueError('SFX sentence coverage incomplete (at least one cue in any four consecutive sentences): '+spans)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('input', type=Path); p.add_argument('output', type=Path)
    p.add_argument('--plan', type=Path, help='Sentence plan for saved native checks'); p.add_argument('--native', action='store_true'); p.add_argument('--require-pass', action='store_true')
    a = p.parse_args(); data = json.loads(a.input.read_text(encoding='utf-8'))
    plan=json.loads(a.plan.read_text(encoding='utf-8')) if a.plan else None
    report = from_native(data, plan) if a.native else from_plan(data)
    a.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(report['status'], 'largest gap', round(report['largest_gap_seconds'], 3))
    if a.require_pass: require_spacing(report)
