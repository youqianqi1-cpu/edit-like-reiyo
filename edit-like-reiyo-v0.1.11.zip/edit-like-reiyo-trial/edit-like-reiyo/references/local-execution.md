# 执行入口

先按 [版本与短段验证](compatibility.md#版本与短段验证) 核对实际安装环境。首次或环境变化时，先完成独立短段的读写、重开播放和改字保存验证，再执行整片制作。

先用 `python scripts/preflight.py` 确认本机条件。Mac 已有 Apple Silicon、macOS 26、剪映11.6.0 的历史试剪记录；Windows 使用 [对应入口](windows-execution.md) 先做本机短段。其他系统报告实际缺项。电脑操作来自当前实际工具，本包提供判断与本地辅助程序。

`<skill>` 表示当前交付目录。优先使用匹配本机的随包程序；仅声音工具需重建时运行 `zsh <skill>/scripts/prepare.sh decode_audio`，其他程序确认需重建后才运行完整 prepare。程序使用用户已安装剪映，缺项按本包说明处理。已有稿按 [接续修改](existing-edits.md) 保留手改；随包文件写入工具处理唯一时间线。

## 实际步骤

1. 使用64位Python3.10–3.12运行 `python scripts/preflight.py --source 原片 --output 本次分析目录`，实测声音、原声大小、逐字识别与帧率。复用通过校验的成功步骤，缺依赖时按需准备；环境禁止下载时说明具体缺项。
2. 在剪映创建准确命名的新草稿，保存关闭；无电脑操作工具时请用户完成一次。读取 `root_meta_info.json` 的 `all_draft_store`，按准确 `draft_name` 找 `draft_fold_path/draft_json_file`；支持自定义保存位置。运行 `python scripts/draft_io.py check 新草稿目录 draft-check.json` 在临时副本验证。保留 `draft_info.json` 或 `draft_content.json` 原格式，多时间线或冲突文件先定位处理。
3. `scripts/extract_frames 原片 输出目录 秒数...` 查看关键帧，可用 `swift scripts/contact_sheet.swift 输出.png 输入图片...` 拼图；连续动作和实际听审另行完成。选段使用 `select_takes.py`，按 [气口](breath-cuts.md) 判断真实声音边缘。
4. `python3 scripts/draft_io.py read 新草稿目录 blank.json` 读取空白稿，按 [计划格式](plan-format.md) 组织本片内容。选段前用 `media_settings.py 原计划.json 已核帧率计划.json` 明确帧率，所有后续步骤使用该计划。先校对并对齐短语，再 compose 重点/景别/声音/B-roll；普通字幕随讲话逐条替换。
5. 首次审看或仍未决时，`python3 scripts/assemble.py blank.json plan.json candidate.json --pending-preview` 生成待审稿。生成前核对短语与声音密度，输出声音、包袱、决策对照及气口记录。声音默认1.0；名称暂选保持未听，要求实际听审通过时才加 `--require-reviewed-sound`。
6. 确认准确新草稿关闭，取得当前指纹，执行 `python3 scripts/draft_io.py install 新草稿目录 candidate.json --plan plan.json --expected-sha 指纹 --exact-name 准确草稿名 --closed --receipt receipt.json --pending-preview`。工具临时试写、核对身份与指纹、保留恢复副本、读回一致后提交。
7. 重开检查时长、素材、字幕、画幅、帧率、动作与声音；保存关闭后执行 `python3 scripts/draft_io.py verify 新草稿目录 --plan plan.json --review candidate.json.breath-review.json --receipt native-review.json --pending-preview`。按 [交付检查](quality-and-delivery.md) 记录实际听看范围，用户需要时再导出。

## 剪口与字幕

用户要求只做到选段、剪气口时，在计划中设置 `editing_scope: "breath_only"`，只保留原片片段，不添加字幕、景别、素材或音效。仍按上述生成、写入和气口核对步骤交付；音效密度检查在此阶段不适用。

用户要求剪气口加普通字幕时，先按同样方法完成本次气口，再设置 `editing_scope: "breath_and_captions"` 并按字幕制作说明添加字幕。此范围保留原构图，不添加重点字、画中画或音效。用户要求从原片重新验证时，重新选段和确定剪口，不沿用以前试剪的剪点。

用户要求气口、字幕加大字景别时，设置 `editing_scope: "breath_captions_emphasis"`。按相同气口方法重新处理原片，再添加普通字幕，用 `promote` 与 `scene` 或 `parallel` 配合大字和景别；此阶段不添加音效、B-roll 或 MG，音效密度检查不适用。大字景别沿用上述五条规则，处理时保持当前原声、剪口和字幕时点。

只剪气口时，可用 `breath_plan.py` 整理本片决定，省去临时编写选句和边界整理程序：

1. 通读本次转写后，将选中的原话写成 `choices.json` 数组，每项为 `{text, after, reason}`；`after` 是本次原片中查找该遍重说的起点。执行 `python scripts/breath_plan.py select source.json words.jsonl choices.json plan-initial.json`，再用 `media_settings.py` 核对帧率。
2. 按气口方法查看波形，将逐处决定的首尾写成 `edges.json` 数组，按选句顺序各一项 `{source, start, end, reason}`。执行 `python scripts/breath_plan.py edges plan-fps.json edges.json plan-edges.json`。它只把决定对应到视频帧，并要求重新检查当前剪点。
3. 句内要删的空白交给下方 `apply_cuts.py`；随后走同一套最终扫描、生成、保存和重开步骤。选句、边界和检查记录由模型根据本片生成，用户无需填写；工具内不预置任何视频的句子或剪点。

声音、转写和视频使用同一时间起点。`waveform.py` 输出波形数值，`wave_sheet.swift INPUT.json OUTPUT.png` 放大选段两端。按字音而非识别词的整体空白定位边缘；连续讲话的字幕切换独立于原声剪口。

`check_cut_audio.py PLAN ANALYSIS_ROOT OUTPUT_FOLDER` 生成当前剪点对应的工作声音并再次识别，寻找重复、漏字与异常。`align_captions.py 成片识别words.jsonl 校对短句.txt captions.json` 将竖线/换行分好的短语对回实际词时；differences逐条核对，词内估算留待播放确认。

### 最终气口检查必须跟着最终剪点走

`check_cut_audio.py` 输出 `final-breath-scan.json`，覆盖所有当前源段、接缝及内部低声段；只做声音拼接和信号检查用 `--no-transcribe`。每次延长、收紧或新增剪口后重扫最终版本，标点时长仅作定位。

`audit_breaths.py PLAN ANALYSIS_ROOT scan.json --pending decisions.json` 生成扫描和处置模板。接缝两侧各最多0.65秒是观察范围，含短峰后不足0.12秒的残余；具体切点沿字音边缘决定。全部候选和未报警接缝均逐项核对。

计划附 `breath_review: {"report":"scan.json绝对路径","decisions":"decisions.json绝对路径"}`。处置如下：

- `items` 对应全部候选，`action` 为 `keep` 或 `unresolved`；内部候选以 `segments` 无缝覆盖源范围，接缝解释写入 `join_reviews`。
- 每段 `source/start/end/disposition/reason/evidence`；`weak_speech`为弱字音，`expressive_pause`为有作用停顿，`tighten_wait`和`uncertain`保持未决。明确等待实际收紧，弱字音保留，表达停顿按连续前中后观察及边界说明时长作用。
- `evidence`绑定同源区间、`pcm_sha256/scan_signature`，`kind`区分`signal/visual/listening`，`observation`写实际观察。只有实际听到才记录听觉结果。程序核对应与覆盖，观察是否充分由片段核实。
- `join_reviews`覆盖每个接缝的`left/right`及扫描里的`left_context/right_context`，分段尊重低声/活动边界；活动段可用`voiced_context`，低声段具体解释。

核准删除范围后用 `apply_cuts.py PLAN CUTS NEW_OUTPUT --analysis-root ANALYSIS_ROOT` 保留原计划、执行修改、重扫并生成新模板。分析目录已有时可省参数。复扫失败保存编辑结果与失败原因，旧验收失效；新扫描的完整记录可参考未变范围的既有观察。

## 待审预览与正式验收

两条路线都核对当前剪点、帧率、源文件、PCM及完整候选/接缝清单。

**待审预览**：首次看片、仍有未决或未听审时，assemble及install都带`--pending-preview`；API对应`build(..., pending_preview=True)`和`install(..., pending_preview=True)`。保留不确定字音与真实未决记录。主轨显示“待审预览 · 气口未验收”，外部记录列出模式、未决ID、源区间和证据指纹；标签用于显示，完整有效记录用于核验。

**正式验收**：处置完整、正常速度听审通过后，在`listening`记录当前`scan_signature/cut_signature`、`scope:"main_speech"`、`speed:1`、`complete:true`、实际`reviewer/note`和`result:"passed"`；需改写`needs_changes`。使用新候选文件名，生成/安装去掉`--pending-preview`，再运行 `python3 scripts/draft_io.py verify 草稿目录 --plan PLAN --review 本次candidate.json.breath-review.json --receipt formal-review.json`。它读取实际保存文件并核对正式记录。混音、字幕、画面及发布许可各自核验。

待审交付说清已生成、已写入、已重开及尚待确认的位置；重叠候选与接缝记录按实际问题汇总。后续针对核实问题修改，观察记录随真实执行更新。

### 外部复核记录与中断恢复

每次生成使用新文件名，保留候选旁`.breath-review.json`及其扫描、处置和声音分析材料，位置在本次工作目录且在剪映工程目录之外。install默认读取该外部文件，可用`--review`明确指定。

安装从真实`root_meta_info.json`取得准确工程目录和项目ID；自定义登记位置用`--project-meta`。绑定内容ID、主轨ID、实际主文件及唯一时间线相对路径、按帧归一的源/目标范围、帧率、人声音频设置，以及源文件/PCM/扫描/处置指纹。缺登记、重复登记、多时间线或证据错配时报告具体冲突并停止写入。

剪映省略零起点、默认速度/音量或四舍五入一微秒，仍可对应同一帧；仅视觉分段保持同一源覆盖时复用检查。真实剪口、帧率、人声音频、内容或主轨身份改变后重新复核。内嵌`reiyo_breath_review`可缺失，若存在则与外部记录一致。

保存前备份实际文件和旧外部记录，建立`.pending.json`；全部写入读回一致后提交外部记录，清除中断标记。失败恢复旧文件；发现并发编辑时保留对方修改、备份和中断记录，等待核对。中断标记存在时保存及验收停止。

准确草稿关闭后，用 `python3 scripts/draft_io.py recover 草稿目录 --review 本次外部记录 --exact-name 准确草稿名 --closed --receipt recovery.json` 恢复写入前版本；自定义登记同样传`--project-meta`。项目、目标和备份完整匹配才恢复；并发修改或损坏保留供比较。恢复后按当前计划重新生成或核验。

verify证明实际保存文件与提交记录对应；重开、连续听审和主观效果另有记录。旧版未绑定项目的记录需依据当前真实计划和材料生成新候选。实际改剪口后同步字幕、B-roll、动画、声音；跨删除区间的素材按源位置分段并待复听，关联包袱一起重排。

## 包装与结果对照

使用同一交付包的工具，记录文件指纹。按 [表现方法](performance-recipes.md) 组织本片方案；字幕运行`caption_phrases.py`，声音运行`sound_density.py`，解决短语候选和连续四句没有音效的位置。生成自动执行这些检查，输出`.decision-trace.json`供核对判断与具体位置，详见 [对照说明](decision-trace.md)。

保存读回用 `sound_density.py saved.json saved-density.json --native --plan plan.json --require-pass` 对照真实声音轨。包袱已选事件按`.punchlines.json`核结构，未选候选回查保留/替代处理。名称选用的未听状态保留。正式流程以已核剪口包装，待审稿可先包装当前剪点，后续修改同步全部关联层。

## 资源与失败接续

字体按 [基础资源](starter-assets.md)，音效按 [收藏检索](reiyo-favorite-sounds.md)，素材来自本用户授权范围；研究档案和作者私人文件不是运行输入。实际本机声音需要WAV时，用系统`afconvert`另存工作副本。

`analyze_media.py`分别缓存信息、音量、解码和识别结果。Mac系统办法失败/超时后，每步改用PyAV/本地Whisper一次，保留原视频时间、开头静音和空隙。成功步骤复用，`failure.json`记卡点，`progress.json`记路线。

读取上限120秒，识别300秒，首次依赖安装240秒、模型下载300秒。缺依赖才准备；网络失败修复后接续，备用仍失败则报告已保留结果并停止该步。原片在本地处理；下载取得程序和模型。识别提供文字与时间候选，气口继续按声音边缘判断。

写入仍核关闭、准确名称和当前指纹。手动字幕备用路线先确认片段确实进入时间线，再识别；两次有依据的添加仍无效时保留现场查因。安装、文件读回、剪映重开和实际播放分别报告。
