"""Read either native draft layout; write only a named closed draft after round-trip."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import review_storage
from punchline_events import check_native as check_native_punchlines

from breath_review import require_review as require_breath_review, check_native as check_native_breaths, check_output_record

S=Path(__file__).resolve().parent
F='/Applications/VideoFusion-macOS.app/Contents/Frameworks'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write_json(p,d): p.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')),encoding='utf-8')

def files(folder):
    folder=Path(folder)
    mains=[folder/n for n in ('draft_info.json','draft_content.json') if (folder/n).is_file()]
    if len(mains)!=1: raise ValueError('Expected exactly one active draft_info.json or draft_content.json; do not guess')
    timelines=sorted((folder/'Timelines').glob('*/*')) if (folder/'Timelines').exists() else []
    timelines=[p for p in timelines if p.name in ('draft_info.json','draft_content.json') and p.is_file()]
    if len(timelines)>1: raise ValueError('Use a new single-timeline draft; multiple timelines are protected')
    return [*mains,*timelines]

def decode(path,folder):
    raw=path.read_bytes()
    try: value=json.loads(raw.decode('utf-8-sig'))
    except (UnicodeDecodeError,json.JSONDecodeError):
        r=subprocess.run([str(S/'jycat'),str(path),str(folder)],env={**os.environ,'DYLD_FRAMEWORK_PATH':F},
                         capture_output=True,text=True,check=True,timeout=30)
        value=json.loads(r.stdout[r.stdout.index('{'):])
    if not isinstance(value,dict) or not value.get('id'): raise ValueError('Invalid draft identity')
    return value

def read(folder): return decode(files(folder)[0],folder)

def prepare(folder,candidate):
    targets=files(folder); before={p:p.read_bytes() for p in targets}
    old=decode(targets[0],folder); new=json.loads(Path(candidate).read_text(encoding='utf-8'))
    if old.get('id')!=new.get('id'): raise ValueError('Candidate belongs to a different native draft')
    for target in targets:
        if decode(target,folder).get('id')!=old['id']: raise ValueError('Timeline identity differs; do not guess')
    serialized=json.dumps(new,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    prepared={}
    for target,raw in before.items():
        try:
            json.loads(raw.decode('utf-8-sig')); prepared[target]=serialized
        except (UnicodeDecodeError,json.JSONDecodeError):
            # Adapt the filename only inside a disposable copy, never in the user's draft.
            with tempfile.TemporaryDirectory(prefix='reiyo-codec-') as tmp:
                staging=Path(tmp)/'draft'; shutil.copytree(folder,staging)
                for name in ('draft_info.json','draft_content.json'): (staging/name).unlink(missing_ok=True)
                (staging/'draft_info.json').write_bytes(raw)
                normalized=Path(tmp)/'candidate.json'; normalized.write_bytes(serialized)
                r=subprocess.run([str(S/'jywrite_verify.sh'),str(normalized),str(staging)],
                                  capture_output=True,text=True,check=True,timeout=60)
                receipt=dict(x.split('=',1) for x in r.stdout.splitlines() if '=' in x)
                if receipt.get('ROUNDTRIP_OK')!='true': raise ValueError('Native round-trip failed')
                lab=Path(receipt['LAB']); prepared[target]=(lab/'draft/draft_info.json').read_bytes()
                # Helper creates only this disposable sandbox; leave the original unchanged.
                if lab.name.startswith('jy-writer.') and lab.parent.resolve()==Path('/tmp').resolve(): shutil.rmtree(lab)
        with tempfile.TemporaryDirectory(prefix='reiyo-readback-') as tmp:
            p=Path(tmp)/target.name; p.write_bytes(prepared[target])
            if decode(p,Path(tmp))!=new: raise ValueError('Prepared draft differs after readback')
    if any(p.read_bytes()!=raw for p,raw in before.items()): raise ValueError('Draft changed during verification')
    return before,prepared,new

def check(folder):
    """Probe the real codec on a temporary copy before any editing; no target write."""
    with tempfile.TemporaryDirectory(prefix='reiyo-draft-check-') as tmp:
        candidate=Path(tmp)/'same.json'; write_json(candidate,read(folder))
        before,_,_=prepare(folder,candidate)
    return {'draft_read_write_ready':True,'files':[p.name for p in before],
            'sha256':sha(files(folder)[0]),'target_unchanged':True,'ui_reopen_verified':False}

def install(folder,candidate,expect,name,closed,plan=None,pending_preview=False,review_path=None,project_meta=None):
    folder=Path(folder).resolve()
    if not closed or folder.name!=name or sha(files(folder)[0])!=expect:
        raise ValueError('Target identity, closed state, or fingerprint mismatch')
    if plan is None:
        sidecar=Path(str(candidate)+'.punchline-plan.json')
        if sidecar.is_file(): plan=json.loads(sidecar.read_text(encoding='utf-8'))
    if plan is None: raise ValueError('Final plan with breath review is required before install')
    breath_result=require_breath_review(plan,final=not pending_preview,pending_preview=pending_preview)
    native=json.loads(Path(candidate).read_text(encoding='utf-8'))
    review_path=Path(review_path) if review_path else Path(str(candidate)+'.breath-review.json')
    external=review_storage.load_review(review_path)
    check_output_record(native,breath_result,pending_preview,external=external)
    check_native_breaths(plan,native)
    check_native_punchlines(plan,native)
    before,prepared,new=prepare(folder,candidate)
    if sha(files(folder)[0])!=expect: raise ValueError('Source changed after verification')
    target=review_storage.identity(folder,list(before),project_meta)
    def validate(record):
        if review_storage.identity(folder,files(folder),project_meta)!=target:raise ValueError('Project/timeline identity changed during save')
        fresh=require_breath_review(plan,final=not pending_preview,pending_preview=pending_preview)
        for path in before:
            reopened=decode(path,folder)
            if reopened!=new:raise ValueError('Installed draft differs from candidate')
            check_native_punchlines(plan,reopened);check_native_breaths(plan,reopened)
            check_output_record(reopened,fresh,pending_preview,external=record)
    saved=review_storage.save(before,prepared,review_path,external,target,validate)
    return {'breath_review':breath_result,'mode':external['mode'],'formal_breath_accepted':not pending_preview and bool(breath_result.get('formal_accepted')),
            'saved':True,'target':str(folder),'backup':saved['backup'],'review_path':saved['review_path'],'external_record_committed':True,
            'ui_reopen_verified':False,'punchline_structure_verified':True}


def verify(folder,plan,review_path,pending_preview=False,project_meta=None):
    folder=Path(folder).resolve();targets=files(folder)
    review_storage.load_review(review_path)
    before={p:p.read_bytes()for p in targets};record_before=Path(review_path).read_bytes()
    target_before=review_storage.identity(folder,targets,project_meta)
    result=review_storage.verify_saved(folder,targets,[decode(p,folder)for p in targets],plan,review_path,pending_preview,project_meta)
    if (files(folder)!=targets or review_storage.identity(folder,targets,project_meta)!=target_before
            or any(p.read_bytes()!=raw for p,raw in before.items()) or Path(review_path).read_bytes()!=record_before
            or review_storage.pending_path(Path(review_path).resolve()).exists()):
        raise ValueError('Project or external review changed during verification')
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='cmd',required=True)
    for name in ['read','check']:
        r=sub.add_parser(name); r.add_argument('draft',type=Path); r.add_argument('out',type=Path)
    w=sub.add_parser('install'); w.add_argument('draft',type=Path); w.add_argument('candidate',type=Path)
    w.add_argument('--plan',type=Path,required=True); w.add_argument('--expected-sha',required=True); w.add_argument('--exact-name',required=True)
    w.add_argument('--pending-preview',action='store_true'); w.add_argument('--closed',action='store_true'); w.add_argument('--receipt',type=Path,required=True)
    w.add_argument('--review',type=Path);w.add_argument('--project-meta',type=Path)
    v=sub.add_parser('verify');v.add_argument('draft',type=Path);v.add_argument('--plan',type=Path,required=True);v.add_argument('--review',type=Path,required=True)
    v.add_argument('--pending-preview',action='store_true');v.add_argument('--project-meta',type=Path);v.add_argument('--receipt',type=Path,required=True)
    v=sub.add_parser('recover');v.add_argument('draft',type=Path);v.add_argument('--review',type=Path,required=True);v.add_argument('--project-meta',type=Path)
    v.add_argument('--closed',action='store_true');v.add_argument('--exact-name',required=True);v.add_argument('--receipt',type=Path,required=True)
    a=p.parse_args()
    if a.cmd=='read': write_json(a.out,read(a.draft)); print(sha(files(a.draft)[0]))
    elif a.cmd=='check': write_json(a.out,check(a.draft)); print(a.out)
    elif a.cmd=='verify':write_json(a.receipt,verify(a.draft,json.loads(a.plan.read_text(encoding='utf-8')),a.review,a.pending_preview,a.project_meta));print(a.receipt)
    elif a.cmd=='recover':
        if not a.closed or a.draft.name!=a.exact_name:raise ValueError('Close the exact draft before recovery')
        write_json(a.receipt,review_storage.recover(a.draft,files(a.draft),a.review,a.project_meta));print(a.receipt)
    else: write_json(a.receipt,install(a.draft,a.candidate,a.expected_sha,a.exact_name,a.closed,json.loads(a.plan.read_text(encoding='utf-8')),pending_preview=a.pending_preview,review_path=a.review,project_meta=a.project_meta)); print(a.receipt)
