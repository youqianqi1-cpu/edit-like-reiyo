"""Windows draft bridge: only a registered, empty trial draft may be edited.

Uses the pinned pyJianYingDraft codec with the user's installed Jianying DLL.
Native calls run in isolated processes. No DLLs or private assets are shipped.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import review_storage

from breath_review import require_review as require_breath_review, check_native as check_native_breaths, check_output_record
from punchline_events import check_native as check_native_punchlines

MARKER = '.reiyo-trial.json'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_codec(install_dir):
    from vendor.jianying_codec.draft_codec import JianyingDraftCryptoCodec
    from vendor.jianying_codec.draft_crypto import DraftCryptoConfig
    if not (Path(install_dir)/'videoeditor.dll').is_file():
        raise FileNotFoundError('Select the installed Jianying version folder containing videoeditor.dll')
    return JianyingDraftCryptoCodec(DraftCryptoConfig(jy_install_dir=install_dir, isolated=True,
                                                     timeout=60, validate_roundtrip=True))


def decode(raw, codec):
    try:
        value = json.loads(raw.decode('utf-8-sig')); encrypted = False
    except (UnicodeDecodeError, json.JSONDecodeError):
        value = codec.decode(raw); encrypted = True
    if not isinstance(value, dict):
        raise ValueError('Draft is not an object')
    return value, encrypted


def files(folder):
    folder=Path(folder)
    mains=[folder/n for n in ('draft_info.json','draft_content.json') if (folder/n).is_file()]
    if len(mains)!=1:raise ValueError('Expected exactly one native draft file; do not guess')
    main=mains[0]
    timelines=sorted(p for p in (folder/'Timelines').glob('*/*')if p.name in ('draft_info.json','draft_content.json')and p.is_file())
    if len(timelines) > 1:
        raise ValueError('Multiple timelines: use a fresh, single-timeline trial draft')
    return [main, *timelines]


def read(folder, codec):
    return decode(files(Path(folder))[0].read_bytes(), codec)[0]


def initialize(folder, name, codec, closed):
    folder = Path(folder).resolve()
    if not closed or folder.name != name or (folder/MARKER).exists():
        raise ValueError('Close the new draft and confirm its exact folder name; do not reinitialize')
    targets = files(folder)
    fingerprints = {str(p.relative_to(folder)):digest(p) for p in targets}
    draft = read(folder, codec)
    if not draft.get('id') or any(t.get('segments') for t in draft.get('tracks', [])):
        raise ValueError('Only an empty, native-created trial draft may be initialized')
    # Probe encoding without writing any draft. Library mismatch stops here.
    candidate = json.dumps(draft, ensure_ascii=False, separators=(',',':'))
    if codec.decode(codec.encode(candidate)) != draft:
        raise ValueError('Native codec round-trip failed')
    if any(digest(folder/p) != sha for p,sha in fingerprints.items()):
        raise ValueError('Draft changed during preparation')
    backup = Path(tempfile.mkdtemp(prefix='reiyo-empty-draft-'))
    for n,p in enumerate(targets): shutil.copy2(p, backup/f'{n}.json')
    marker = {'id':draft['id'], 'name':name, 'folder':str(folder), 'initial':fingerprints, 'backup':str(backup)}
    (folder/MARKER).write_text(json.dumps(marker, ensure_ascii=False, indent=2), encoding='utf-8')
    return {'ready_for_trial':True, 'sha256':digest(targets[0]), 'ui_reopen_verified':False}


def install(folder, candidate, expect, name, closed, codec, plan=None, pending_preview=False, review_path=None, project_meta=None):
    folder = Path(folder).resolve()
    if not closed or folder.name != name:
        raise ValueError('Close the exact new draft before writing')
    marker = json.loads((folder/MARKER).read_text(encoding='utf-8'))
    if marker['name'] != name or marker['folder'] != str(folder):
        raise ValueError('Trial identity mismatch')
    targets = files(folder)
    before = {p:p.read_bytes() for p in targets}
    if digest(targets[0]) != expect:
        raise ValueError('Draft changed since it was read')
    new = json.loads(Path(candidate).read_text(encoding='utf-8'))
    old = decode(before[targets[0]], codec)[0]
    if new.get('id') != marker['id'] or old.get('id') != marker['id']:
        raise ValueError('Candidate or draft belongs to another project')
    if plan is None:
        sidecar=Path(str(candidate)+'.punchline-plan.json')
        if sidecar.is_file():plan=json.loads(sidecar.read_text(encoding='utf-8'))
    if plan is None:raise ValueError('Final plan with breath review is required before install')
    breath_result=require_breath_review(plan,final=not pending_preview,pending_preview=pending_preview)
    review_path=Path(review_path) if review_path else Path(str(candidate)+'.breath-review.json')
    external=review_storage.load_review(review_path)
    check_output_record(new,breath_result,pending_preview,external=external)
    check_native_breaths(plan,new)
    check_native_punchlines(plan,new)
    serialized = json.dumps(new, ensure_ascii=False, separators=(',',':'))
    prepared = {}
    for target,raw in before.items():
        decoded, encrypted = decode(raw, codec)
        if decoded.get('id') != old['id']:
            raise ValueError('Native timeline identity differs; do not guess')
        encoded = codec.encode(serialized) if encrypted else serialized.encode('utf-8')
        if decode(encoded, codec)[0] != new:
            raise ValueError('Encoded candidate differs after reading back')
        prepared[target] = encoded
    if any(p.read_bytes() != raw for p,raw in before.items()):
        raise ValueError('Draft changed during verification')
    target=review_storage.identity(folder,targets,project_meta)
    def validate(record):
        if review_storage.identity(folder,files(folder),project_meta)!=target:raise ValueError('Project/timeline identity changed during save')
        fresh=require_breath_review(plan,final=not pending_preview,pending_preview=pending_preview)
        for path in targets:
            reopened=decode(path.read_bytes(),codec)[0]
            if reopened!=new:raise ValueError('Installed draft differs from candidate')
            check_native_breaths(plan,reopened);check_native_punchlines(plan,reopened)
            check_output_record(reopened,fresh,pending_preview,external=record)
    saved=review_storage.save(before,prepared,review_path,external,target,validate)
    return {'breath_review':breath_result,'mode':external['mode'],'formal_breath_accepted':not pending_preview and bool(breath_result.get('formal_accepted')),
            'saved':True,'backup':saved['backup'],'target':str(folder),'review_path':saved['review_path'],'external_record_committed':True,'ui_reopen_verified':False}


def verify(folder,plan,review_path,codec,pending_preview=False,project_meta=None):
    folder=Path(folder).resolve();targets=files(folder)
    review_storage.load_review(review_path)
    before={p:p.read_bytes()for p in targets};record_before=Path(review_path).read_bytes()
    target_before=review_storage.identity(folder,targets,project_meta)
    result=review_storage.verify_saved(folder,targets,[decode(p.read_bytes(),codec)[0]for p in targets],plan,review_path,pending_preview,project_meta)
    if (files(folder)!=targets or review_storage.identity(folder,targets,project_meta)!=target_before
            or any(p.read_bytes()!=raw for p,raw in before.items()) or Path(review_path).read_bytes()!=record_before
            or review_storage.pending_path(Path(review_path).resolve()).exists()):
        raise ValueError('Project or external review changed during verification')
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--install-dir', required=True)
    sub = p.add_subparsers(dest='command', required=True)
    c = sub.add_parser('read'); c.add_argument('draft'); c.add_argument('output')
    for name in ['init','install']:
        c = sub.add_parser(name); c.add_argument('draft'); c.add_argument('--exact-name',required=True)
        c.add_argument('--closed',action='store_true'); c.add_argument('--receipt',required=True)
        if name == 'install': c.add_argument('candidate'); c.add_argument('--expected-sha',required=True); c.add_argument('--plan',required=True); c.add_argument('--pending-preview',action='store_true');c.add_argument('--review');c.add_argument('--project-meta')
    c=sub.add_parser('verify');c.add_argument('draft');c.add_argument('--plan',required=True);c.add_argument('--review',required=True);c.add_argument('--receipt',required=True);c.add_argument('--pending-preview',action='store_true');c.add_argument('--project-meta')
    c=sub.add_parser('recover');c.add_argument('draft');c.add_argument('--review',required=True);c.add_argument('--receipt',required=True);c.add_argument('--closed',action='store_true');c.add_argument('--exact-name',required=True);c.add_argument('--project-meta')
    a = p.parse_args(); codec = make_codec(a.install_dir)
    if a.command == 'read':
        Path(a.output).write_text(json.dumps(read(a.draft,codec),ensure_ascii=False), encoding='utf-8')
        print(digest(files(Path(a.draft))[0]))
    else:
        if a.command == 'init': result = initialize(a.draft,a.exact_name,codec,a.closed)
        elif a.command=='verify':result=verify(a.draft,json.loads(Path(a.plan).read_text(encoding='utf-8')),a.review,codec,a.pending_preview,a.project_meta)
        elif a.command=='recover':
            if not a.closed or Path(a.draft).name!=a.exact_name:raise ValueError('Close the exact draft before recovery')
            result=review_storage.recover(a.draft,files(Path(a.draft)),a.review,a.project_meta)
        else: result = install(a.draft,a.candidate,a.expected_sha,a.exact_name,a.closed,codec,json.loads(Path(a.plan).read_text(encoding='utf-8')),pending_preview=a.pending_preview,review_path=a.review,project_meta=a.project_meta)
        Path(a.receipt).write_text(json.dumps(result,ensure_ascii=False,indent=2), encoding='utf-8')
        print(json.dumps(result,ensure_ascii=False))
