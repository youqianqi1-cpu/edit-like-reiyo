from media_settings import plan_fps
"""Expose missing sound decisions; records are evidence, not aesthetic certification."""
import argparse
import hashlib
import json
import math
from pathlib import Path


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(plan):
    cues = plan.get('sounds', [])
    review = plan.get('sound_review', {})
    name_based = review.get('selection_basis') == 'name_inference'
    missing, pending = [], []

    def evidence(record, label):
        if not isinstance(record, dict):
            missing.append(label + ': missing evidence')
            return False
        path = Path(record.get('path') or '')
        if not path.is_file() or record.get('sha256') != digest(path):
            missing.append(label + ': missing or changed evidence file')
            return False
        return True

    if not cues:
        return {'status': 'no_sound_cues', 'missing': [], 'pending': [],
                'quality_certified': False}
    catalogs = review.get('catalogs', [])
    if not catalogs:
        missing.append('catalogs: no actual search coverage recorded')
    for i, catalog in enumerate(catalogs):
        evidence(catalog, f'catalog {i}')
        if not catalog.get('scope'):
            missing.append(f'catalog {i}: search scope missing')
    for i, cue in enumerate(cues):
        label = f'sound {i} at {cue.get("start")}s'
        decision = cue.get('selection') or {}
        for key in ('event', 'context', 'choice_reason', 'licence_scope'):
            if not decision.get(key):
                missing.append(f'{label}: {key} missing')
        candidates = decision.get('candidates', [])
        paths = {c.get('path') for c in candidates}
        if cue.get('path') not in paths:
            missing.append(label + ': selected sound absent from comparison')
        if len(paths) < 2 and not decision.get('reuse_or_single_reason'):
            missing.append(label + ': no alternative or justified reuse')
        for candidate in candidates:
            if not candidate.get('finding') or not Path(candidate.get('path') or '').is_file():
                missing.append(label + ': candidate not inspected or unavailable')
        anchor = decision.get('anchor') or {}
        if anchor.get('kind') not in ('spoken_word', 'reaction', 'visible_action', 'visual_landing'):
            missing.append(label + ': real event anchor missing (caption start is insufficient)')
        anchor_time = anchor.get('timeline_seconds')
        offset = anchor.get('sound_offset_seconds')
        values = (anchor_time, offset, cue.get('start'))
        if not all(type(v) in (int, float) and math.isfinite(v) for v in values):
            missing.append(label + ': anchor times missing or invalid')
        elif abs(cue['start'] + offset - anchor_time) > 1 / plan_fps(plan) + 0.001:
            missing.append(label + ': sound perceptual point does not match event anchor')
        evidence(anchor.get('evidence'), label + ' anchor')
        evidence(decision.get('comparison_evidence'), label + ' comparison')

    preview_record = review.get('preview')
    if (preview_record or not name_based) and evidence(preview_record, 'mixed preview'):
        try:
            preview = json.loads(Path(preview_record['path']).read_text(encoding='utf-8'))
            evidence(preview.get('audio'), 'mixed audio')
            expected = [{k: c.get(k) for k in ('path', 'start', 'source_start', 'duration', 'volume')}
                        for c in cues]
            if preview.get('cues') != expected:
                missing.append('mixed preview: cues changed after preview')
            for record in preview.get('inputs', []):
                evidence(record, 'preview input')
            if not preview.get('inputs') or not preview.get('measurements'):
                missing.append('mixed preview: inputs or measurements missing')
            if preview.get('measurements', {}).get('clipped_samples', 0):
                pending.append('mixed preview clips: change mix before acceptance')
        except (ValueError, KeyError, TypeError):
            missing.append('mixed preview: invalid report')
    listening = review.get('listening', {})
    if listening.get('status') == 'reviewed' and listening.get('reviewer') and listening.get('note'):
        evidence(listening.get('evidence'), 'listening record')
    else:
        pending.append('actual contextual listening not recorded; preview only')
    return {'status': 'incomplete' if missing else ('name_selected_unlistened' if name_based else 'listening_pending') if pending else 'review_recorded',
            'missing': missing, 'pending': pending, 'quality_certified': False,
            'selection_basis': 'name_inference' if name_based else 'contextual_preview',
            'note': 'Checks record completeness and file consistency, not taste or truth of a listening claim.'}


def require_review(report):
    if report['status'] not in ('review_recorded', 'no_sound_cues'):
        raise ValueError('Sound listening review incomplete: ' + '; '.join(report['missing'] + report['pending']))


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('plan', type=Path)
    ap.add_argument('output', type=Path)
    ap.add_argument('--require-reviewed', action='store_true')
    args = ap.parse_args()
    report = check(json.loads(args.plan.read_text(encoding='utf-8')))
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(report['status'], 'missing', len(report['missing']), 'pending', len(report['pending']))
    if args.require_reviewed:
        require_review(report)
