"""Mix an already-edited mono PCM16 voice with a plan's cues for listening.
Never edits cuts, normalizes voice, writes a draft, or claims to have listened.
"""
import argparse
import array
import json
import math
import sys
import wave
from pathlib import Path
from sound_review import digest


def read(path):
    with wave.open(str(path), 'rb') as w:
        if w.getsampwidth() != 2 or w.getnchannels() != 1 or w.getcomptype() != 'NONE':
            raise ValueError('Preview needs mono PCM16 WAV; convert a work copy first')
        rate = w.getframerate()
        values = array.array('h', w.readframes(w.getnframes()))
    if sys.byteorder != 'little':
        values.byteswap()
    return rate, values


def render(plan, voice_path, output, start, end):
    rate, voice = read(voice_path)
    if not 0 <= start < end <= len(voice) / rate:
        raise ValueError('Preview interval outside edited voice')
    a, b = round(start * rate), round(end * rate)
    original = voice[a:b]
    effects = [0.0] * len(original)
    inputs = [{'path': str(Path(voice_path).resolve()), 'sha256': digest(voice_path)}]
    measurements = []
    for cue in plan.get('sounds', []):
        sr, data = read(cue['path'])
        source_start = cue.get('source_start', 0)
        duration = cue.get('duration', len(data) / sr - source_start)
        gain = cue.get('volume', 1)
        if not all(math.isfinite(v) for v in (source_start, duration, gain, cue['start'])):
            raise ValueError('Invalid cue numbers')
        if source_start < 0 or duration <= 0 or source_start + duration > len(data) / sr + 0.001:
            raise ValueError('Cue exceeds sound source')
        lo = max(0, round((cue['start'] - start) * rate))
        hi = min(len(original), round((cue['start'] + duration - start) * rate))
        if hi <= lo:
            raise ValueError('Plan contains cue outside preview; use a scoped plan')
        samples = []
        for i in range(lo, hi):
            pos = (start + i / rate - cue['start'] + source_start) * sr
            j = max(0, min(len(data) - 1, int(pos)))
            frac = max(0, min(1, pos - j))
            value = (data[j] * (1 - frac) + data[min(j + 1, len(data) - 1)] * frac) * gain
            effects[i] += value
            samples.append(value)
        measurements.append({'path': cue['path'], 'start': cue['start'],
                             'voice': stats(original[lo:hi]), 'sound': stats(samples)})
        inputs.append({'path': str(Path(cue['path']).resolve()), 'sha256': digest(cue['path'])})
    mixed = [v + s for v, s in zip(original, effects)]
    clipped = sum(v > 32767 or v < -32768 for v in mixed)
    # Do not hide clipping by altering the user's approved voice level.
    result = array.array('h', (max(-32768, min(32767, round(v))) for v in mixed))
    if sys.byteorder != 'little':
        result.byteswap()
    with wave.open(str(output), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(result.tobytes())
    return {'audio': {'path': str(Path(output).resolve()), 'sha256': digest(output)},
            'inputs': inputs, 'interval': [start, end], 'voice_unchanged': True,
            'cues': [{k: c.get(k) for k in ('path', 'start', 'source_start', 'duration', 'volume')}
                     for c in plan.get('sounds', [])],
            'measurements': {'voice': stats(original), 'mix': stats(mixed),
                             'clipped_samples': clipped, 'per_cue': measurements},
            'listening_performed': False, 'note': 'RMS and peak are measurements, not perceived loudness or taste.'}


def stats(values):
    peak = max((abs(x) for x in values), default=0) / 32768
    rms = math.sqrt(sum(x * x for x in values) / max(1, len(values))) / 32768
    db = lambda v: round(20 * math.log10(v), 2) if v else None
    return {'peak_dbfs': db(peak), 'rms_dbfs': db(rms)}


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('plan', type=Path); ap.add_argument('voice', type=Path); ap.add_argument('output', type=Path)
    ap.add_argument('--start', type=float, required=True); ap.add_argument('--end', type=float, required=True)
    args = ap.parse_args()
    report = render(json.loads(args.plan.read_text(encoding='utf-8')), args.voice, args.output, args.start, args.end)
    Path(str(args.output) + '.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print('preview only; clipped samples:', report['measurements']['clipped_samples'])
