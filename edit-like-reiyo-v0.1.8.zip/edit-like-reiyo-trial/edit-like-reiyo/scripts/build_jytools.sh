#!/bin/zsh
set -euo pipefail

script_dir=$(cd -- "$(dirname -- "$0")" && pwd)
frameworks=/Applications/VideoFusion-macOS.app/Contents/Frameworks

clang++ -std=c++17 -O2 -Wall -Wextra -pedantic \
  "$script_dir/jycat.cc" \
  -L"$frameworks" -lvideoeditor -Wl,-rpath,"$frameworks" \
  -o "$script_dir/jycat"

clang++ -std=c++17 -O2 -Wall -Wextra -pedantic \
  "$script_dir/jywrite.cc" \
  -Wl,-rpath,"$frameworks" \
  -o "$script_dir/jywrite"

echo "built: $script_dir/jycat"
echo "built: $script_dir/jywrite"
