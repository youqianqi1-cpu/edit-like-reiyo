"""Build exact-cut analysis audio and rescan final source edges before optional ASR.
An ASR mismatch is a review lead, never an instruction to extend a source cut.
"""
import argparse,json,pathlib,wave,sys
from media_settings import plan_fps
from audit_breaths import audit
S=pathlib.Path(__file__).resolve().parent

def make_audio(plan,analysis_root,output):
 fps=plan_fps(plan);root=pathlib.Path(analysis_root);outdir=pathlib.Path(output)
 report=audit(plan,root);outdir.mkdir(parents=True,exist_ok=True);cache={};sample_cursor=0;frame_cursor=0
 with wave.open(str(outdir/'cut-check.wav'),'wb')as out:
  out.setparams((1,2,16000,0,'NONE','not compressed'))
  for r in plan['takes']:
   if r['source']not in cache:cache[r['source']]=(root/r['source']/'audio.pcm').read_bytes()
   af,bf=round(r['start']*fps),round(r['end']*fps)
   start=round(af/fps*16000);frame_cursor+=bf-af
   # Accumulated target samples prevent fractional-rate per-piece rounding drift.
   target=round(frame_cursor/fps*16000);count=target-sample_cursor;end=start+count
   raw=cache[r['source']]
   if start<0 or end*2>len(raw):raise ValueError('Final source range outside PCM')
   out.writeframes(raw[start*2:end*2]);sample_cursor=target
 (outdir/'final-breath-scan.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 return report

def main():
 p=argparse.ArgumentParser();p.add_argument('plan',type=pathlib.Path);p.add_argument('analysis_root',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);p.add_argument('--no-transcribe',action='store_true');a=p.parse_args()
 plan=json.loads(a.plan.read_text(encoding='utf-8'));make_audio(plan,a.analysis_root,a.output)
 if a.no_transcribe:return
 if sys.platform=='win32':
  from portable_media import transcribe
  transcribe(a.output/'cut-check.wav',a.output/'words.jsonl')
 else:
  from analyze_media import run, fallback, read_words
  target=a.output/'words.jsonl'
  try:
   target.write_text(run([S/'transcribe_words',a.output/'cut-check.wav'],300),encoding='utf-8');read_words(target)
  except (OSError,ValueError,RuntimeError):fallback('transcribe',a.output/'cut-check.wav',target)
 w=[json.loads(x)for x in(a.output/'words.jsonl').read_text(encoding='utf-8').splitlines()];(a.output/'transcript.txt').write_text(''.join(x['text']for x in w),encoding='utf-8');print(a.output/'transcript.txt')
if __name__=='__main__':main()
