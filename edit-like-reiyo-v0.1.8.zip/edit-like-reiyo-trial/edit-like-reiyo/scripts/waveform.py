"""Return RMS windows for visual edge inspection, never automatically cut."""
import array,math

def envelope(path,step=.01):
 a=array.array('h');a.frombytes(path.read_bytes());n=round(16000*step)
 return [math.sqrt(sum(v*v for v in a[i:i+n])/max(1,len(a[i:i+n])))/32768 for i in range(0,len(a),n)]
