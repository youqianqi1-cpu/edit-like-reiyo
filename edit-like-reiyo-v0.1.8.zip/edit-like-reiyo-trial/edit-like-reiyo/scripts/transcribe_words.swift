import AVFAudio
import CoreMedia
import Foundation
import Speech

func emit(_ value: [String: Any]) {
  let data = try! JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
  print(String(data: data, encoding: .utf8)!)
}

@main struct TranscribeWords {
  static func main() async throws {
    guard CommandLine.arguments.count == 2 else { return }
    let transcriber = SpeechTranscriber(
      locale: Locale(identifier: "zh-CN"),
      transcriptionOptions: [],
      reportingOptions: [],
      attributeOptions: [.audioTimeRange, .transcriptionConfidence]
    )
    if let request = try await AssetInventory.assetInstallationRequest(supporting: [transcriber]) {
      try await request.downloadAndInstall()
    }
    let file = try AVAudioFile(forReading: URL(fileURLWithPath: CommandLine.arguments[1]))
    let analyzer = SpeechAnalyzer(modules: [transcriber])
    async let transcript: Void = {
      for try await result in transcriber.results where result.isFinal {
        for run in result.text.runs {
          let text = String(result.text[run.range].characters)
          if let timeRange = run.audioTimeRange {
            emit([
              "start": CMTimeGetSeconds(timeRange.start),
              "duration": CMTimeGetSeconds(timeRange.duration),
              "text": text,
              "confidence": run.transcriptionConfidence ?? -1,
            ])
          }
        }
      }
    }()
    if let lastSample = try await analyzer.analyzeSequence(from: file) {
      try await analyzer.finalizeAndFinish(through: lastSample)
    } else {
      await analyzer.cancelAndFinishNow()
    }
    try await transcript
  }
}
