"""Copy bundled resources into a project so future Skill updates do not break drafts."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def prepare(project):
    source = Path(__file__).resolve().parents[1] / 'assets' / 'starter'
    catalog = json.loads((source / 'catalog.json').read_text(encoding='utf-8'))
    target = Path(project).resolve() / ('reiyo-starter-' + catalog['version'])
    # Validate everything before copying; never replace a user's changed resource.
    for group in ('fonts', 'sounds'):
        for item in catalog[group]:
            path = (source / item['path']).resolve()
            if not path.is_relative_to(source.resolve()):
                raise ValueError('Resource path leaves the bundle')
            if hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
                raise ValueError('Bundled resource changed: ' + item['path'])
    files = [p for p in source.rglob('*') if p.is_file()]
    for path in files:
        dest = target / path.relative_to(source)
        if dest.exists() and (not dest.is_file() or dest.read_bytes() != path.read_bytes()):
            raise ValueError('Keep existing modified resource; use a fresh project folder: ' + str(dest))
    for path in files:
        dest = target / path.relative_to(source)
        dest.parent.mkdir(parents=True, exist_ok=True)
        if not dest.exists():
            shutil.copy2(path, dest)
    for group in ('fonts', 'sounds'):
        for item in catalog[group]:
            item['path'] = str(target / item['path'])
    catalog['font'] = catalog['fonts'][0]['path']
    catalog['title_font'] = catalog['fonts'][1]['path']
    catalog['preview'] = str(target / 'preview.html')
    return catalog


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('project', help='Current project folder; existing resources are preserved')
    args = parser.parse_args()
    print(json.dumps(prepare(args.project), ensure_ascii=False, indent=2))
