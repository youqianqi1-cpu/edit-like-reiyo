"""Synthetic project metadata and external review files for isolated storage tests."""
import json
from pathlib import Path

def metadata(folder):
 folder=Path(folder).resolve();p=folder.parent/'root_meta_info.json'
 rows=json.loads(p.read_text())['all_draft_store'] if p.exists() else []
 rows=[r for r in rows if r['draft_fold_path']!=str(folder)]
 rows.append({'draft_id':'test-project-'+folder.name,'draft_fold_path':str(folder)})
 p.write_text(json.dumps({'all_draft_store':rows}));return p

def review(candidate):
 candidate=Path(candidate);d=json.loads(candidate.read_text())
 r=d.get('reiyo_breath_review',{'schema_version':2,'mode':'formal','review':{'fixture_only':True}})
 p=Path(str(candidate)+'.breath-review.json');p.write_text(json.dumps(r));return p
