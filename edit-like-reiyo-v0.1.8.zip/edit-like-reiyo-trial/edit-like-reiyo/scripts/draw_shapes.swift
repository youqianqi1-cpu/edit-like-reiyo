// Render simple authored diagram layers; coordinates are normalized, origin at bottom-left.
import AppKit
import Foundation
let a=CommandLine.arguments,j=try JSONSerialization.jsonObject(with:Data(contentsOf:URL(fileURLWithPath:a[1]))) as! [String:Any]
let w=j["width"] as! Int,h=j["height"] as! Int
let rep=NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:w,pixelsHigh:h,bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:w*4,bitsPerPixel:32)!
NSGraphicsContext.saveGraphicsState();NSGraphicsContext.current=NSGraphicsContext(bitmapImageRep:rep)
NSColor.clear.setFill();NSRect(x:0,y:0,width:w,height:h).fill(using:.copy)
for s in j["shapes"] as! [[String:Any]]{
let rgb=s["color"] as! [Double];NSColor(calibratedRed:rgb[0],green:rgb[1],blue:rgb[2],alpha:rgb.count>3 ? rgb[3]:1).set()
let x=s["x"] as? Double ?? 0,y=s["y"] as? Double ?? 0,sw=s["w"] as? Double ?? 1,sh=s["h"] as? Double ?? 1
let rect=NSRect(x:x*Double(w),y:y*Double(h),width:sw*Double(w),height:sh*Double(h))
switch s["type"] as! String {
case "ellipse":NSBezierPath(ovalIn:rect).fill()
case "line":let p=NSBezierPath();p.lineWidth=s["stroke"] as? Double ?? 4;p.move(to:NSPoint(x:x*Double(w),y:y*Double(h)));p.line(to:NSPoint(x:(s["x2"] as! Double)*Double(w),y:(s["y2"] as! Double)*Double(h)));p.stroke()
default:NSBezierPath(roundedRect:rect,xRadius:s["radius"] as? Double ?? 0,yRadius:s["radius"] as? Double ?? 0).fill()
}}
NSGraphicsContext.restoreGraphicsState();try rep.representation(using:.png,properties:[:])!.write(to:URL(fileURLWithPath:a[2]))
