"""Index sounds actually selected from the user's library. No bundled/private assets.
Input is a decoded scratch draft. Writes WAV copies + measurable timing, not a claim of listening.
"""
import argparse,array,json,math,pathlib,subprocess,wave,sys,re
ap=argparse.ArgumentParser();ap.add_argument('draft',type=pathlib.Path);ap.add_argument('output',type=pathlib.Path);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True);result=[]
for i,m in enumerate(json.loads(a.draft.read_text(encoding='utf-8'))['materials'].get('audios',[])):
 src=pathlib.Path(m['path']);name=m.get('name',src.stem);dst=a.output/(str(i+1).zfill(2)+'-'+re.sub(r'[<>:"/\\|?*\x00-\x1f]','-',name)+'.wav')
 if sys.platform=='win32':
  from portable_media import decode_pcm,make_wav
  pcm=dst.with_suffix('.pcm');decode_pcm(src,pcm);make_wav(pcm,dst)
 else:subprocess.run(['afconvert','-f','WAVE','-d','LEI16','-c','1',str(src),str(dst)],check=True,capture_output=True)
 with wave.open(str(dst))as w:rate=w.getframerate();v=array.array('h',w.readframes(w.getnframes()))
 n=max(1,round(rate*.005));env=[math.sqrt(sum(x*x for x in v[i:i+n])/len(v[i:i+n]))/32768 for i in range(0,len(v),n)]
 peak=max(env,default=0);on=next((i for i,x in enumerate(env)if x>max(.003,peak*.025)),0)*.005
 end=next((i+1 for i in range(len(env)-1,-1,-1)if env[i]>max(.003,peak*.025)),len(env))*.005
 result.append(dict(name=name,path=str(dst.resolve()),source_path=str(src),duration=len(v)/rate,onset_estimate=on,tail_estimate=end,peak=max((abs(x)/32768 for x in v),default=0),rms=round(math.sqrt(sum(x*x for x in v)/max(1,len(v)))/32768,4),listened=False))
(a.output/'inventory.json').write_text(json.dumps(result,ensure_ascii=False,indent=2), encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))
