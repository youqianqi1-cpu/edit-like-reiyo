"""Align human-reviewed caption groups to recognized word times.
Use | or newline between meaningful short phrases. Review differences; alignment is not speech proof.
"""
import argparse,json,pathlib,re,difflib,unicodedata,math
from caption_phrases import check as check_phrases
clean=lambda x:''.join(c for c in x if not c.isspace() and not unicodedata.category(c).startswith(('P','S')))
def align(words,lines):
 old='';clock=[]
 for w in words:
  if not all(math.isfinite(w[k]) for k in ('start','duration')) or w['start']<0 or w['duration']<0:raise ValueError('Invalid recognized timing')
  tx=clean(w['text']);old+=tx
  for n in range(len(tx)):clock.append((w['start']+w['duration']*n/len(tx),w['start']+w['duration']*(n+1)/len(tx)))
 groups=[clean(x)for x in re.split(r'[|\n]',lines)if clean(x)];new=''.join(groups);mapped=[None]*len(new);changes=[]
 if new and not clock:raise ValueError('No spoken word timings; punctuation cannot time captions')
 for op,a,b,c,d in difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes():
  if op=='equal':mapped[c:d]=clock[a:b]
  else:
   if a==b:
    x=clock[a-1][1] if a else clock[0][0]
    y=max(x,clock[a][0]) if a<len(clock) else x
   else:x,y=clock[a][0],clock[b-1][1]
   changes.append({'recognized':old[a:b],'caption':new[c:d],'at':x,'timing_review_required':True,'reason':'Inserted text has no recognized phoneme timing' if a==b else 'Changed words require source timing review'})
   if d>c:
    for n in range(d-c):mapped[c+n]=(x+(y-x)*n/(d-c),x+(y-x)*(n+1)/(d-c))
 out=[];pos=0
 for tx in groups:
  out.append({'text':tx,'start':mapped[pos][0],'end':mapped[pos+len(tx)-1][1]});pos+=len(tx)
 for i,c in enumerate(out[:-1]):c['end']=min(c['end']+.025,out[i+1]['start'])
 return out,changes
def timing_review(words,captions):
 # A recognizer token may cover several characters: interpolation is only an estimate.
 boundaries=[c['start']for c in captions]+[c['end']for c in captions]
 inside=[{'text':w['text'],'start':w['start'],'end':w['start']+w['duration']}
         for w in words if len(clean(w['text']))>1 and any(w['start']+1e-6<t<w['start']+w['duration']-1e-6 for t in boundaries)]
 return {'actual_listening':False,'interpolated_token_boundaries':inside,'untimed_captions':[c for c in captions if c['end']<=c['start']],
         'note':'Token-internal positions are estimates; confirm doubtful boundaries against source. Do not claim frame-accurate hearing.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('words',type=pathlib.Path);p.add_argument('lines',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);a=p.parse_args()
 words=[json.loads(x)for x in a.words.read_text(encoding='utf-8').splitlines()if x.strip()]
 captions,changes=align(words,a.lines.read_text(encoding='utf-8'))
 a.output.write_text(json.dumps(captions,ensure_ascii=False,indent=2), encoding='utf-8')
 a.output.with_suffix('.differences.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2), encoding='utf-8')
 report=check_phrases({'captions':captions});report['timing']=timing_review(words,captions)
 a.output.with_suffix('.phrases.json').write_text(json.dumps(report,ensure_ascii=False,indent=2), encoding='utf-8')
 print(len(captions),'captions;',len(changes),'text differences;',len(report['pending']),'phrase boundaries to review')
