import copy
import json
from pathlib import Path
import tempfile
import unittest
from decision_trace import trace, write_trace


class DecisionTraceTests(unittest.TestCase):
    def plan(self):
        return {'fps':24, 'takes':[{'source':'main','start':100,'end':330}],
                'punchline_review':{'reason':'本人表演足够', 'candidates':[]}}

    def test_repeated_sounds_are_exposed_not_rejected_or_approved(self):
        plan = self.plan()
        plan['sounds'] = [dict(path=f'{i%6}.wav', start=i*7,
                              selection={'candidates':[{'path':f'{i%6}.wav'}],
                                         'reuse_or_single_reason':'泛用复用理由',
                                         'comparison_evidence':{'path':'same.json'}})
                          for i in range(30)]
        before = copy.deepcopy(plan)
        report = trace(plan)
        self.assertEqual(report['sound_statistics']['unique_files'],6)
        self.assertEqual(report['sound_statistics']['gaps_6_to_8_seconds'],29)
        self.assertEqual(report['sounds'][1]['source_locations'],[{'source':'main','at':107}])
        self.assertIn('regular_sound_spacing', report['warnings'][0])
        self.assertFalse(report['quality_certified'])
        self.assertFalse(report['playback_verified'])
        self.assertEqual(before,plan)

    def test_declined_and_selected_candidates_keep_real_records(self):
        plan=self.plan()
        candidate=dict(id='c',source='main',start=110,end=112,selected=False,
                       quote='够了够了',reason='拟用重点字',evidence='frame.png')
        plan['punchline_review']['candidates']=[candidate]
        result=trace(plan)
        self.assertEqual(result['punchlines'][0]['timeline_locations'][0]['start'],10)
        self.assertEqual(result['punchlines'][0]['planned_events'],[])
        self.assertTrue(any('all_punchlines_declined' in w for w in result['warnings']))
        candidate['selected']=True
        plan['punchline_events']=[{'id':'c','start':10}]
        self.assertEqual(trace(plan)['punchlines'][0]['planned_events'], plan['punchline_events'])

    def test_visual_pause_maps_all_occurrences_and_does_not_certify_duration(self):
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'decisions.json'
            item={'id':'p','action':'keep','segments':[dict(source='main',start=101,end=102,
                   disposition='expressive_pause',reason='三张静帧',evidence={'kind':'visual'})]}
            p.write_text(json.dumps({'items':[item]}))
            plan=self.plan()
            plan['takes']=[{'source':'main','start':100,'end':103}]*2
            plan['breath_review']={'decisions':'decisions.json'}
            report=trace(plan,directory)
            pause=report['expressive_pauses'][0]
            self.assertEqual([r['start'] for r in pause['timeline_locations']],[1,4])
            self.assertEqual(pause['recorded'],item['segments'][0])
            self.assertEqual(pause['duration_evidence_verdict'],'requires_continuous_observation_or_listening')

    def test_join_sides_and_overlapping_item_remain_identifiable(self):
        with tempfile.TemporaryDirectory() as directory:
            segment=dict(source='main', start=101, end=102, disposition='expressive_pause',
                         reason='反应', evidence={'kind':'visual'})
            data={'items':[{'id':'take', 'segments':[segment]}],
                  'join_reviews':[{'id':'join-0-1', 'left':[segment],
                                   'right':[dict(segment, start=104, end=105)]}]}
            (Path(directory)/'decisions.json').write_text(json.dumps(data))
            plan=self.plan();plan['breath_review']={'decisions':'decisions.json'}
            rows=trace(plan,directory)['expressive_pauses']
            self.assertEqual(len(rows),3)
            self.assertEqual(rows[1]['origin'],{'kind':'join','id':'join-0-1','side':'left'})
            self.assertEqual(rows[2]['origin']['side'],'right')
            self.assertEqual(rows[1]['overlaps_record_indices'],[0])
            self.assertEqual(rows[2]['overlaps_record_indices'],[])

    def test_missing_record_is_visible_and_empty_punchlines_are_allowed(self):
        plan=self.plan()
        plan['breath_review']={'decisions':'/no/such/review.json'}
        r=trace(plan)
        self.assertTrue(r['breath_record_errors'])
        self.assertFalse(r['native_result_verified'])
        self.assertEqual(r['punchlines'],[])
        self.assertFalse(any('all_punchlines' in w for w in r['warnings']))

    def test_fractional_frame_mapping_matches_assembly_rounding(self):
        plan=self.plan(); plan['fps']=30000/1001
        plan['takes']=[{'source':'main','start':1.123,'end':1.987},
                       {'source':'main','start':8.457,'end':9.876}]
        fps=plan['fps'];us=lambda t:round(round(t*fps)*1e6/fps)
        expected=round((us(1.987)-us(1.123))/1e6,6)
        with tempfile.TemporaryDirectory() as directory:
            output=Path(directory)/'trace.json'
            report=write_trace(plan,output)
            self.assertEqual(report['mapping'][1]['at'],expected)
            self.assertEqual(json.loads(output.read_text()),report)

    def test_missing_fps_and_nonfinite_sound_time_fail(self):
        plan=self.plan();del plan['fps']
        with self.assertRaises(ValueError):trace(plan)
        plan=self.plan();plan['sounds']=[{'path':'a.wav','start':float('nan')}]
        with self.assertRaises(ValueError):trace(plan)


if __name__=='__main__':unittest.main()
