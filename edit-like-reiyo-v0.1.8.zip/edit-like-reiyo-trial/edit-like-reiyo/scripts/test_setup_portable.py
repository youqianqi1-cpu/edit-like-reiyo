from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch
import setup_portable as setup

class SetupTests(unittest.TestCase):
    def test_slow_public_download_uses_mirror_once_with_limits(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); script=root/'scripts/setup_portable.py';script.parent.mkdir()
            python=root/'.runtime/venv'/('Scripts/python.exe' if sys.platform=='win32' else 'bin/python3')
            python.parent.mkdir(parents=True);python.touch();calls=[]
            def run(args,**kwargs):
                calls.append((args,kwargs))
                if len(calls)==1:return SimpleNamespace(returncode=1)
                if len(calls)==2:raise subprocess.TimeoutExpired(args,90)
                return SimpleNamespace(returncode=0)
            with patch.object(setup,'__file__',str(script)),patch.object(setup.subprocess,'run',run):
                setup.prepare(False)
            self.assertEqual(len(calls),3)
            self.assertEqual(calls[1][1]['timeout'],90)
            self.assertEqual(calls[2][1]['timeout'],150)
            self.assertIn('https://pypi.tuna.tsinghua.edu.cn/simple',calls[2][0])
    def test_complete_model_and_dependencies_are_reused(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);script=root/'scripts/setup_portable.py';script.parent.mkdir()
            python=root/'.runtime/venv'/('Scripts/python.exe' if sys.platform=='win32' else 'bin/python3')
            python.parent.mkdir(parents=True);python.touch()
            model=root/'.runtime/models'/('whisper-small' if sys.platform=='win32' else 'whisper-base');model.mkdir(parents=True)
            for name in ['model.bin','config.json','tokenizer.json','vocabulary.txt']:(model/name).write_bytes(b'fixture')
            with patch.object(setup,'__file__',str(script)),patch.object(setup.subprocess,'run',return_value=SimpleNamespace(returncode=0)) as run:
                setup.prepare(True)
            self.assertEqual(run.call_count,1)

if __name__=='__main__':unittest.main()
