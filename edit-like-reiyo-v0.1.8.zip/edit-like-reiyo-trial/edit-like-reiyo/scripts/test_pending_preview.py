from test_external_fixtures import metadata,review
import copy,json,runpy,sys,unittest
from pathlib import Path
from unittest.mock import patch
from test_final_breaths import FinalSignalTests,fixture_decisions
from audit_breaths import audit
from breath_review import pending_decisions,require_review,check_output_record,cut_signature
from assemble import build
import draft_io,draft_windows

class Codec:
 def encode(self,value):return b'test:'+value.encode()
 def decode(self,value):return json.loads(value.removeprefix(b'test:').decode())

class PreviewTests(unittest.TestCase):
 setUp=FinalSignalTests.setUp
 bind=FinalSignalTests.bind
 def pending(self):
  r,_=self.bind();d=pending_decisions(r)
  Path(self.plan['breath_review']['decisions']).write_text(json.dumps(d))
  return r,d
 def candidate(self,pending=True):
  return build({'id':'unit'},self.plan,settings={'fps':24},pending_preview=pending)[0]
 def target(self,native):
  folder=self.root/'target';folder.mkdir();active=folder/'draft_info.json';active.write_text('{"id":"unit","tracks":[]}')
  candidate=self.root/'candidate.json';candidate.write_text(json.dumps(native));metadata(folder);review(candidate);return folder,active,candidate
 def install(self,folder,active,candidate,pending=True):
  return draft_io.install(folder,candidate,draft_io.sha(active),folder.name,True,self.plan,pending_preview=pending)
 def test_unresolved_preview_is_explicit_and_preserves_ranges(self):
  r,d=self.pending();before=copy.deepcopy(self.plan)
  with self.assertRaisesRegex(ValueError,'unresolved'):self.candidate(False)
  native=self.candidate();record=native['reiyo_breath_review']
  self.assertEqual(record['mode'],'pending_preview');self.assertFalse(record['formal_breath_accepted'])
  self.assertTrue(record['review']['pending']);self.assertTrue(record['review']['pending_locations'])
  self.assertEqual(record['review']['cut_signature'],cut_signature(before));self.assertEqual(self.plan,before)
  self.assertIn('待审',native['tracks'][0]['name'])
  folder,active,candidate=self.target(native);receipt=self.install(folder,active,candidate)
  self.assertEqual(receipt['mode'],'pending_preview');self.assertFalse(receipt['formal_breath_accepted'])
  self.assertEqual(draft_io.read(folder)['reiyo_breath_review'],record)
 def test_preview_does_not_relax_missing_stale_or_audio_binding(self):
  self.pending();self.candidate()
  for change in ['missing_table','missing_row','old_cut','wrong_fps','wrong_pcm']:
   p=copy.deepcopy(self.plan)
   if change=='missing_table':p.pop('breath_review')
   elif change=='missing_row':
    dp=Path(p['breath_review']['decisions']);d=json.loads(dp.read_text());d['items'].pop()
    other=self.root/'missing.json';other.write_text(json.dumps(d));p['breath_review']['decisions']=str(other)
   elif change=='old_cut':p['takes'][0]['end']+=1/24
   elif change=='wrong_fps':p['fps']=30
   else:self.pcm.write_bytes(bytes(self.pcm.stat().st_size))
   with self.assertRaises(ValueError):build({'id':'unit'},p,settings={'fps':24},pending_preview=True)
 def test_default_install_blocks_pending_and_fake_final_label(self):
  self.pending();native=self.candidate();folder,active,candidate=self.target(native);before=active.read_bytes()
  native['reiyo_breath_review']['mode']='formal';native['reiyo_breath_review']['formal_breath_accepted']=True
  native['reiyo_breath_review']['review']['pending']=[];candidate.write_text(json.dumps(native))
  with self.assertRaisesRegex(ValueError,'unresolved'):self.install(folder,active,candidate,False)
  with self.assertRaisesRegex(ValueError,'review record'):self.install(folder,active,candidate,True)
  self.assertEqual(active.read_bytes(),before)
 def test_missing_record_blocked_before_save_and_on_readback(self):
  self.pending();native=self.candidate();folder,active,candidate=self.target(native);before=active.read_bytes()
  external=Path(str(candidate)+'.breath-review.json');saved=external.read_bytes();external.unlink()
  with self.assertRaisesRegex(ValueError,'record missing'):self.install(folder,active,candidate)
  external.write_bytes(saved)
  # App dropping inline metadata is permitted; a changed external record is not.
  altered=copy.deepcopy(native);altered.pop('reiyo_breath_review');candidate.write_text(json.dumps(altered))
  receipt=self.install(folder,active,candidate);self.assertTrue(receipt['external_record_committed'])
  self.assertFalse(draft_io.verify(folder,self.plan,external,pending_preview=True)['formal_breath_accepted'])
 def test_changed_decision_file_requires_fresh_candidate(self):
  self.pending();native=self.candidate();folder,active,candidate=self.target(native)
  dp=Path(self.plan['breath_review']['decisions']);ds=json.loads(dp.read_text());ds['items'][0]['note']='changed observation';dp.write_text(json.dumps(ds))
  with self.assertRaisesRegex(ValueError,'review record'):self.install(folder,active,candidate)
 def test_formal_flow_requires_signal_and_listening_and_new_build(self):
  r,d=self.bind();native=self.candidate();folder,active,candidate=self.target(native)
  with self.assertRaisesRegex(ValueError,'listening'):self.candidate(False)
  with self.assertRaisesRegex(ValueError,'listening'):self.install(folder,active,candidate,False)
  # Synthetic record for control flow; no claim of real listening.
  d['listening']={'scope':'main_speech','scan_signature':r['scan_signature'],'cut_signature':r['cut_signature'],
                 'speed':1,'complete':True,'reviewer':'test fixture','note':'simulated listening record','result':'passed'}
  Path(self.plan['breath_review']['decisions']).write_text(json.dumps(d))
  with self.assertRaisesRegex(ValueError,'review record'):self.install(folder,active,candidate,False)
  final=self.candidate(False);candidate.write_text(json.dumps(final));review(candidate);receipt=self.install(folder,active,candidate,False)
  self.assertTrue(receipt['formal_breath_accepted']);self.assertEqual(receipt['mode'],'formal')
  self.assertTrue(draft_io.read(folder)['reiyo_breath_review']['formal_breath_accepted'])
 def test_native_cut_change_does_not_inherit_preview_record(self):
  self.pending();native=self.candidate();folder,active,candidate=self.target(native);before=active.read_bytes()
  native['tracks'][0]['segments'][0]['source_timerange']['start']+=41667
  candidate.write_text(json.dumps(native))
  with self.assertRaisesRegex(ValueError,'cuts'):self.install(folder,active,candidate)
  self.assertEqual(active.read_bytes(),before)
 def test_formal_cli_requires_committed_external_record(self):
  r,d=self.bind()
  d['listening']={'scope':'main_speech','scan_signature':r['scan_signature'],'cut_signature':r['cut_signature'],
                 'speed':1,'complete':True,'reviewer':'test fixture','note':'simulated listening record','result':'passed'}
  Path(self.plan['breath_review']['decisions']).write_text(json.dumps(d))
  folder,active,candidate=self.target(self.candidate(False));self.install(folder,active,candidate,False)
  plan=self.root/'formal-plan.json';plan.write_text(json.dumps(self.plan));external=Path(str(candidate)+'.breath-review.json');receipt=self.root/'verify.json'
  args=['draft_io.py','verify',str(folder),'--plan',str(plan),'--review',str(external),'--receipt',str(receipt)]
  with patch.object(sys,'argv',args):runpy.run_path(str(Path(__file__).parent/'draft_io.py'),run_name='__main__')
  self.assertTrue(json.loads(receipt.read_text())['formal_breath_accepted'])
  external.unlink()
  with patch.object(sys,'argv',args):
   with self.assertRaisesRegex(ValueError,'record missing'):runpy.run_path(str(Path(__file__).parent/'draft_io.py'),run_name='__main__')
 def test_invalid_preview_modes_cannot_suppress_final_checks(self):
  self.pending()
  for value in ['preview',1,None]:
   with self.assertRaises(ValueError):build({'id':'unit'},self.plan,settings={'fps':24},pending_preview=value)
  with self.assertRaises(ValueError):require_review(self.plan,final=True,pending_preview=True)
 def test_cli_build_and_save_preview_carry_status(self):
  self.pending();plan=self.root/'plan.json';plan.write_text(json.dumps(self.plan));blank=self.root/'blank.json';blank.write_text('{"id":"unit"}')
  candidate=self.root/'cli.json';scripts=Path(__file__).parent
  args=['assemble.py',str(blank),str(plan),str(candidate),'--pending-preview']
  with patch.object(sys,'argv',args),patch('media_settings.frame_settings',return_value={'fps':24}):
   runpy.run_path(str(scripts/'assemble.py'),run_name='__main__')
  report=json.loads(Path(str(candidate)+'.breath-review.json').read_text());self.assertEqual(report['mode'],'pending_preview');self.assertFalse(report['formal_breath_accepted'])
  decision=json.loads(Path(str(candidate)+'.decision-trace.json').read_text());self.assertEqual(decision['stage'],'planned');self.assertFalse(decision['quality_certified']);self.assertEqual(len(decision['mapping']),len(self.plan['takes']))
  folder=self.root/'cli-target';folder.mkdir();active=folder/'draft_info.json';active.write_text('{"id":"unit","tracks":[]}');metadata(folder);receipt=self.root/'saved.json'
  args=['draft_io.py','install',str(folder),str(candidate),'--plan',str(plan),'--expected-sha',draft_io.sha(active),'--exact-name',folder.name,'--closed','--receipt',str(receipt),'--pending-preview']
  with patch.object(sys,'argv',args):runpy.run_path(str(scripts/'draft_io.py'),run_name='__main__')
  self.assertEqual(json.loads(receipt.read_text())['mode'],'pending_preview')
 def test_pending_punchline_cli_and_saved_readback(self):
  import wave
  from compose_beats import compose
  from punchline_events import check_native
  sound=self.root/'reaction.wav'
  with wave.open(str(sound),'wb') as w:
   w.setparams((1,2,16000,0,'NONE','not compressed'));w.writeframes(b'\x00\x01'*6400)
  self.plan['punchline_review']={'reason':'synthetic fixture','candidates':[{'id':'p1','source':'main','start':0,'end':1.5,'quote':'synthetic','evidence':'synthetic only','selected':True,'reason':'test'}]}
  self.pending()
  self.plan=compose(self.plan,[{'type':'punchline','candidate_id':'p1','source':'main','reason':'synthetic',
   'start':0,'shrink_at':.5,'restore_at':1,'end':1.5,'scale':.75,'sound':{'path':str(sound),'at':.5,'duration':.4}}],self.root/'generated')
  plan=self.root/'plan.json';plan.write_text(json.dumps(self.plan));blank=self.root/'blank.json';blank.write_text('{"id":"unit"}')
  candidate=self.root/'pending-punchline.json'
  args=['assemble.py',str(blank),str(plan),str(candidate),'--pending-preview']
  with patch.object(sys,'argv',args),patch('media_settings.frame_settings',return_value={'fps':24}):
   runpy.run_path(str(Path(__file__).parent/'assemble.py'),run_name='__main__')
  native=json.loads(candidate.read_text());self.assertEqual(check_native(self.plan,native)['selected'],1)
  folder,active,candidate=self.target(native)
  self.install(folder,active,candidate)
  reopened=draft_io.read(folder)
  self.assertEqual(check_native(self.plan,reopened)['selected'],1)
  self.assertIn('待审',next(t for t in reopened['tracks'] if t['type']=='video')['name'])
  external=Path(str(candidate)+'.breath-review.json')
  self.assertFalse(draft_io.verify(folder,self.plan,external,pending_preview=True)['formal_breath_accepted'])
  with self.assertRaises(ValueError):draft_io.verify(folder,self.plan,external,pending_preview=False)
  bad=copy.deepcopy(reopened);main=next(t for t in bad['tracks'] if t['type']=='video')
  main['segments'][1]['clip']['scale']={'x':1,'y':1}
  with self.assertRaisesRegex(ValueError,'framing'):check_native(self.plan,bad)

 def test_windows_codec_double_preserves_pending_and_default_rejects(self):
  self.pending();native=self.candidate();folder,active,candidate=self.target(native);codec=Codec()
  ready=draft_windows.initialize(folder,folder.name,codec,True)
  with self.assertRaisesRegex(ValueError,'unresolved'):draft_windows.install(folder,candidate,ready['sha256'],folder.name,True,codec,self.plan)
  receipt=draft_windows.install(folder,candidate,ready['sha256'],folder.name,True,codec,self.plan,pending_preview=True)
  self.assertFalse(receipt['formal_breath_accepted']);self.assertEqual(draft_windows.read(folder,codec)['reiyo_breath_review'],native['reiyo_breath_review'])

del FinalSignalTests
if __name__=='__main__':unittest.main()
