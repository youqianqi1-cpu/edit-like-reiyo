"""Read-only local checks. Does not imply desktop-control permission or native QA."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys


def inspect():
    root=Path(__file__).resolve().parents[1]
    result={'system':platform.system(),'machine':platform.machine(), 'python':platform.python_version(),
            'desktop_control':'confirm from the current Codex tools', 'native_trial_verified':False,
            'missing':[], 'jianying_candidates':[], 'font_candidates':[]}
    if sys.platform=='win32':
        if not ((3,10)<=sys.version_info[:2]<=(3,12)) or sys.maxsize<=2**32:
            result['missing'].append('64-bit Python 3.10–3.12')
        for name in ['av','PIL','numpy','faster_whisper']:
            if importlib.util.find_spec(name) is None: result['missing'].append(name)
        bases=[]
        for key in ['LOCALAPPDATA','ProgramFiles','ProgramFiles(x86)']:
            if os.environ.get(key): bases.append(Path(os.environ[key])/'JianyingPro')
        for base in bases:
            for pattern in ['videoeditor.dll','*/videoeditor.dll','Apps/*/videoeditor.dll']:
                result['jianying_candidates'] += [str(p.parent) for p in base.glob(pattern)]
        fonts=Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts'
        result['font_candidates']=[str(fonts/n) for n in ['msyh.ttc','msyhbd.ttc','simhei.ttf'] if (fonts/n).is_file()]
        model=Path(os.environ.get('REIYO_WHISPER_MODEL',str(root/'.runtime/models/whisper-small')))
        if not (model/'model.bin').is_file(): result['missing'].append('local speech model')
        result['route']='windows-experimental'
    elif sys.platform=='darwin':
        result['macos']=platform.mac_ver()[0]
        if platform.machine()!='arm64': result['missing'].append('Apple Silicon required by included native binaries')
        if int((platform.mac_ver()[0] or '0').split('.')[0])<26:
            result['missing'].append('macOS 26 required by included speech recognizer')
        app=Path('/Applications/VideoFusion-macOS.app')
        if app.is_dir(): result['jianying_candidates']=[str(app)]
        else: result['missing'].append('Jianying Pro installation')
        font=app/'Contents/Resources/Font/SystemFont/zh-hans.ttf'
        if font.is_file(): result['font_candidates']=[str(font)]
        for name in ['transcribe_words','decode_audio','extract_frames','media_probe','audio_levels','jycat','jywrite']:
            if not os.access(root/'scripts'/name,os.X_OK): result['missing'].append(name+' executable permission or file')
        result['route']='mac-tested-locally'
    else:
        result['route']='unsupported'; result['missing'].append('Mac or Windows with Jianying Pro')
    starter=root/'assets'/'starter'
    result['bundled_assets']={'catalog':str(starter/'catalog.json'),'available':(starter/'catalog.json').is_file(),'prepare':'scripts/prepare_assets.py <project-folder>'}
    result['font_candidates'] += [str(p) for p in sorted((starter/'fonts').glob('*')) if p.suffix in ('.otf','.ttf')]
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--source',type=Path); p.add_argument('--output',type=Path); p.add_argument('--draft',type=Path)
    a=p.parse_args(); result=inspect()
    if a.source and not a.output: p.error('--source requires --output for resumable analysis')
    try:
        if a.source:
            from analyze_media import analyze
            if sys.platform=='win32':
                from portable_media import analyze
            result['media_test']=analyze(a.source,a.output)
        if a.draft:
            if sys.platform!='darwin': raise ValueError('Use the Windows init command to test that draft codec')
            from draft_io import check
            result['draft_test']=check(a.draft)
    except (OSError,ValueError,RuntimeError) as error:
        result['actual_check_error']=str(error)
        print(json.dumps(result,ensure_ascii=False,indent=2)); p.exit(2)
    print(json.dumps(result,ensure_ascii=False,indent=2))
