"""Scan FINAL frame-snapped takes/joins using PCM, with lexical hints only.
Low energy is not silence. Punctuation timing never protects a phoneme.
"""
import argparse, hashlib, json, math, pathlib, unicodedata
from waveform import envelope
from media_settings import plan_fps
from breath_review import cut_signature, evaluate, pending_decisions


def speech_text(text):
 return ''.join(c for c in text if not c.isspace() and not unicodedata.category(c).startswith(('P','S')))


def context(e, source, a, b, threshold):
 # Keep every low run, even below the candidate threshold or after a brief peak.
 regions=[]
 for k in range(max(0,int(math.floor(a*100))),min(len(e),int(math.ceil(b*100)))):
  x,y=max(a,k/100),min(b,(k+1)/100)
  if y<=x:continue
  kind='low_energy' if e[k]<threshold else 'active'
  if regions and regions[-1]['kind']==kind:regions[-1]['end']=y
  else:regions.append({'start':x,'end':y,'kind':kind})
 return {'source':source,'start':a,'end':b,'regions':regions}


def audit(plan,analysis_root,threshold=.02):
 if not math.isfinite(threshold) or threshold<=0:raise ValueError('Positive candidate threshold required')
 root=pathlib.Path(analysis_root).resolve();cache={};records=[];joins=[];cursor=0;fps=plan_fps(plan);inputs={};tokens={};scanned=[]
 for i,t in enumerate(plan['takes']):
  source=t['source'];af=round(t['start']*fps);bf=round(t['end']*fps);a=af/fps;b=bf/fps
  if af<0 or bf<=af:raise ValueError('Invalid frame-snapped take: '+str(i))
  if source not in cache:
   folder=(root/source).resolve()
   if root not in folder.parents:raise ValueError('Analysis source escapes root')
   pcm=folder/'audio.pcm';raw=pcm.read_bytes()
   if not raw or len(raw)%2:raise ValueError('Expected mono 16kHz s16le PCM')
   cache[source]=envelope(pcm,.01)
   words=folder/'words.jsonl';word_raw=words.read_bytes() if words.exists() else b''
   parsed=[json.loads(x)for x in word_raw.decode('utf-8').splitlines()if x.strip()]
   tokens[source]=[w for w in parsed if speech_text(w.get('text',''))]
   inputs[source]={'pcm_sha256':hashlib.sha256(raw).hexdigest(),'pcm_bytes':len(raw),'words_sha256':hashlib.sha256(word_raw).hexdigest()}
   receipt_path=folder/'receipt.json';bound=False
   if receipt_path.exists() and source in plan.get('sources',{}):
    receipt=json.loads(receipt_path.read_text(encoding='utf-8'));original=pathlib.Path(plan['sources'][source]['path']).resolve()
    if pathlib.Path(receipt['source']).resolve()!=original:raise ValueError('Analysis belongs to a different original source')
    st=original.stat()
    if receipt['source_size']!=st.st_size or receipt['source_mtime_ns']!=st.st_mtime_ns:raise ValueError('Original changed since audio analysis; refresh the source analysis')
    inputs[source]['source_receipt_sha256']=hashlib.sha256(receipt_path.read_bytes()).hexdigest();bound=True
   inputs[source]['source_binding_verified']=bound
  e=cache[source];lo=round(a*100);hi=round(b*100)
  if not 0<=lo<hi<=len(e) or b>inputs[source]['pcm_bytes']/32000+1/16000:raise ValueError('Take lies outside decoded audio: '+str(i))
  def hints(x,y):
   return [{'text':w['text'],'start':w['start'],'end':w['start']+w['duration'],'timing_is_phoneme_proof':False}for w in tokens[source]if w['start']<y and w['start']+w['duration']>x]
  spans=[];begin=None
  for k in range(lo,hi+1):
   quiet=k<hi and e[k]<threshold
   if quiet and begin is None:begin=k
   if not quiet and begin is not None:
    if k-begin>=12:spans.append(dict(id=f'take-{i}-quiet-{begin}-{k}',source=source,start=max(a,begin/100),end=min(b,k/100),duration=min(b,k/100)-max(a,begin/100),decision='review_required',word_hints=hints(begin/100,k/100)))
    begin=None
  head=lo
  while head<hi and e[head]<threshold:head+=1
  tail=hi
  while tail>lo and e[tail-1]<threshold:tail-=1
  record=dict(take=i,source=source,start=a,end=b,timeline_start=cursor/fps,quiet_candidates=spans,reviewed=False,
              leading_quiet=dict(start=lo/100,end=head/100,duration=(head-lo)/100),
              trailing_quiet=dict(start=tail/100,end=hi/100,duration=(hi-tail)/100),
              head_windows={'start':lo/100,'rms':e[lo:min(hi,lo+65)]},tail_windows={'start':max(lo,hi-65)/100,'rms':e[max(lo,hi-65):hi]},
              edge_word_hints={'head':hints(a,min(b,a+.65)),'tail':hints(max(a,b-.65),b)})
  if records:
   prev=records[-1];left=prev['trailing_quiet'];right=record['leading_quiet'];total=round(left['duration']+right['duration'],2)
   joins.append(dict(id=f'join-{i-1}-{i}',after_take=i-1,before_take=i,timeline_join=cursor/fps,
                     left_source=prev['source'],left_range=left,right_source=source,right_range=right,
                     left_context=context(cache[prev['source']],prev['source'],max(prev['start'],prev['end']-.65),prev['end'],threshold),
                     right_context=context(e,source,a,min(b,a+.65),threshold),
                     combined_quiet_seconds=total,decision='review_required'if total>=.12 else'not_flagged'))
  records.append(record);cursor+=bf-af;scanned.append({'source':source,'start':a,'end':b})
 signature=cut_signature(plan)
 data={'schema_version':3,'cut_signature':signature,'inputs':inputs,'threshold':threshold,'scanned_takes':scanned}
 return dict(schema_version=3,fps=fps,cut_signature=signature,scan_signature=hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest(),
             analysis_root=str(root),inputs=inputs,scanned_takes=scanned,threshold_is_candidate_only=threshold,window_seconds=.01,
             takes=records,joins=joins,duration=cursor/fps,actual_listening=False,
             note='All final takes and joins scanned. Low-energy spans may contain weak speech. Word hints exclude punctuation and are not phoneme boundaries. Frame edges are exact; RMS windows are 10ms estimates.')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('plan',type=pathlib.Path);p.add_argument('analysis_root',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);p.add_argument('--threshold',type=float,default=.02);p.add_argument('--decisions',type=pathlib.Path);p.add_argument('--pending',type=pathlib.Path);a=p.parse_args()
 if a.pending and a.pending.exists():raise ValueError('Use a new pending decisions path; preserve existing review')
 result=audit(json.loads(a.plan.read_text(encoding='utf-8')),a.analysis_root,a.threshold)
 a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 if a.pending:a.pending.write_text(json.dumps(pending_decisions(result),ensure_ascii=False,indent=2),encoding='utf-8')
 print('takes covered',len(result['takes']),'all joins',len(result['joins']),'quiet candidates',sum(len(t['quiet_candidates'])for t in result['takes']))
 if a.decisions:print(json.dumps(evaluate(result,json.loads(a.decisions.read_text(encoding='utf-8'))),ensure_ascii=False))
