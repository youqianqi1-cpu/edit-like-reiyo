import copy
import json
import math
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import wave

from media_settings import frame_settings, level_summary


class FrameSettings(unittest.TestCase):
    def setUp(self):
        self.plan = {'fps': 30, 'sources': {'a': {'path': 'a'}, 'b': {'path': 'b'}},
                     'takes': [{'source': 'a', 'start': 0, 'end': 20}, {'source': 'b', 'start': 0, 'end': 2}],
                     'overlays': [{'source': 'b', 'start': 0, 'end': 90}]}

    def test_source_rate_overrides_old_default_and_overlay(self):
        before = copy.deepcopy(self.plan)
        with patch('media_settings.probe_source', side_effect=[{'fps': 24}, {'fps': 60}]):
            result = frame_settings(self.plan)
        self.assertEqual(result['fps'], 24)
        self.assertTrue(result['mixed_main_rates'])
        self.assertEqual(self.plan, before)

    def test_fractional_rate_not_rounded_to_30(self):
        with patch('media_settings.probe_source', return_value={'fps': 29.9700298309}):
            self.assertEqual(frame_settings(self.plan)['fps'], 30000/1001)

    def test_explicit_output_requirement(self):
        self.plan['fps_reason'] = 'User requested a 30 fps deliverable'
        with patch('media_settings.probe_source', return_value={'fps': 24}):
            self.assertEqual(frame_settings(self.plan)['fps'], 30)

    def test_missing_rate_stops_instead_of_guessing(self):
        for rate in [None, 0, float('nan'), True]:
            with patch('media_settings.probe_source', return_value={'fps': rate}):
                with self.assertRaises(ValueError): frame_settings(self.plan)


class NativeLevels(unittest.TestCase):
    def test_original_channels_not_mono_cancellation(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td)/'opposite-channels.wav'
            # Equal, opposite channels would cancel completely after mono mixdown.
            values = [round(16384*math.sin(i*2*math.pi*1000/48000)) for i in range(48000)]
            with wave.open(str(source), 'wb') as f:
                f.setparams((2, 2, 48000, 0, 'NONE', 'not compressed'))
                f.writeframes(b''.join(struct.pack('<hh', x, -x) for x in values))
            result = subprocess.run([str(Path(__file__).with_name('audio_levels')), str(source)],
                                    check=True, capture_output=True, text=True, timeout=20)
            levels = json.loads(result.stdout)
            self.assertEqual(len(levels['channels']), 2)
            for channel in levels['channels']:
                self.assertAlmostEqual(channel['peak_dbfs'], -6.0206, places=3)
                self.assertAlmostEqual(channel['rms_dbfs'], -9.0309, places=3)
                self.assertEqual(channel['samples'], 48000)
            self.assertEqual(levels['gain_applied_db'], 0)
            self.assertFalse(levels['listened'])

    def test_silence_and_imbalance_do_not_prescribe_gain(self):
        silent = {'peak_dbfs': None, 'rms_dbfs': None, 'near_full_scale_samples': 0}
        report = level_summary({'channels': [silent, silent]})
        self.assertTrue(any('silence' in s for s in report['flags']))
        self.assertEqual(report['automatic_gain_db'], 0)
        report = level_summary({'channels': [silent, dict(silent, peak_dbfs=-1., rms_dbfs=-15.)]})
        self.assertTrue(any('imbalance' in s for s in report['flags']))


if __name__ == '__main__': unittest.main()
