import array
import copy
import json
import tempfile
import unittest
import wave
from pathlib import Path
from sound_preview import render, read
from sound_review import check, digest, require_review
from compose_beats import compose


class SoundEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.voice = self.wav('voice.wav', 16000, [1000] * 32000)
        self.sound = self.wav('sound.wav', 48000, [2000] * 2400)
        self.proof = self.root / 'evidence.json'
        self.proof.write_text('{}')
        self.ref = {'path': str(self.proof), 'sha256': digest(self.proof)}
        self.cue = {'path': str(self.sound), 'start': .5, 'source_start': 0, 'volume': 1,
                    'selection': {'event': 'answer', 'context': 'question then answer',
                                  'choice_reason': 'short answer accent', 'licence_scope': 'fixture',
                                  'candidates': [{'path': str(self.sound), 'finding': 'short'}],
                                  'reuse_or_single_reason': 'approved fixture',
                                  'anchor': {'kind': 'spoken_word', 'timeline_seconds': .5,
                                             'sound_offset_seconds': 0, 'evidence': self.ref},
                                  'comparison_evidence': self.ref}}
        self.plan = {'fps': 24, 'sounds': [self.cue],
                     'sound_review': {'catalogs': [dict(self.ref, scope='fixture only')],
                                      'listening': {'status': 'pending'}}}
        self.preview(self.plan)

    def wav(self, name, rate, values):
        p = self.root / name
        with wave.open(str(p), 'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
            w.writeframes(array.array('h', values).tobytes())
        return p

    def preview(self, plan):
        p = self.root / 'mixed.wav'
        report = render(plan, self.voice, p, 0, 2)
        evidence = self.root / 'mix.json'
        evidence.write_text(json.dumps(report))
        plan['sound_review']['preview'] = {'path': str(evidence), 'sha256': digest(evidence)}
        return report

    def test_missing_old_plan_is_exposed_and_final_is_blocked(self):
        report = check({'sounds': [{'path': str(self.sound), 'start': 0}]})
        self.assertEqual(report['status'], 'incomplete')
        with self.assertRaises(ValueError): require_review(report)

    def test_measured_preview_does_not_pass_listening_gate(self):
        report = check(self.plan)
        self.assertEqual(report['missing'], [])
        self.assertEqual(report['status'], 'listening_pending')
        with self.assertRaises(ValueError): require_review(report)

    def test_name_selection_without_preview_is_allowed_but_not_listened(self):
        self.plan['sound_review']['selection_basis'] = 'name_inference'
        del self.plan['sound_review']['preview']
        report = check(self.plan)
        self.assertEqual(report['missing'], [])
        self.assertEqual(report['status'], 'name_selected_unlistened')
        self.assertFalse(report['quality_certified'])
        with self.assertRaises(ValueError): require_review(report)

    def test_caption_anchor_and_stale_mix_detected(self):
        self.cue['selection']['anchor']['kind'] = 'caption_start'
        self.cue['volume'] = .3
        report = check(self.plan)
        self.assertTrue(any('anchor' in x for x in report['missing']))
        self.assertTrue(any('cues changed' in x for x in report['missing']))

    def test_changed_source_detected(self):
        self.wav('sound.wav', 48000, [2500] * 2400)
        self.assertTrue(any('changed evidence' in x for x in check(self.plan)['missing']))

    def test_render_preserves_voice_and_samples_outside_effect(self):
        original = digest(self.voice)
        report = self.preview(self.plan)
        rate, samples = read(self.root / 'mixed.wav')
        self.assertEqual(original, digest(self.voice))
        self.assertEqual(len(samples), 32000)
        self.assertEqual(set(samples[:8000]), {1000})
        self.assertEqual(set(samples[8000:8800]), {3000})
        self.assertEqual(set(samples[8800:]), {1000})
        self.assertEqual(report['measurements']['clipped_samples'], 0)

    def test_clipping_is_reported_not_hidden(self):
        self.cue['volume'] = 20
        report = self.preview(self.plan)
        self.assertGreater(report['measurements']['clipped_samples'], 0)
        self.assertTrue(any('clips' in x for x in check(self.plan)['pending']))

    def test_compose_keeps_selection_and_original_cuts(self):
        plan = {'fps': 24, 'takes': [{'source': 'main', 'start': 10, 'end': 12}], 'captions': []}
        plan['punchline_review']={'reason':'Synthetic sound fixture; no humour candidates','candidates':[]}
        saved = copy.deepcopy(plan)
        beat = dict(type='sound', source='main', at=10.5, reason='answer',
                    path=str(self.sound), selection=self.cue['selection'])
        result = compose(plan, [beat], self.tmp.name)
        self.assertEqual(plan, saved)
        self.assertEqual(result['sounds'][0]['start'], .5)
        self.assertEqual(result['sounds'][0]['selection'], self.cue['selection'])


if __name__ == '__main__':
    unittest.main()
