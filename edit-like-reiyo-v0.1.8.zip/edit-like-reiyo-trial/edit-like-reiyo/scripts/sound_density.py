from media_settings import plan_fps
"""Check SFX event spacing over the WHOLE edit; never inserts or selects a sound.

Seven seconds is a planning target; ten seconds is the maximum uncovered span.
Events are onsets, not the duration of a long sound or background music.
Native checks prove track structure, not actual hearing or perceptual suitability.
"""
import argparse
import json
import math
from pathlib import Path

TARGET = 7.0
MAX_GAP = 10.0


def number(value, label):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError(label + ' must be finite')
    return value


def review(duration, events):
    duration = number(duration, 'duration')
    if duration <= 0:
        raise ValueError('Duration must be positive')
    events = sorted(events, key=lambda e: e['at'])
    for event in events:
        at = number(event['at'], 'sound event')
        if not 0 <= at < duration:
            raise ValueError('Sound event outside edit: ' + str(at))
    times = sorted(set(e['at'] for e in events))
    bounds = [0., *times, duration]
    gaps = [{'start': a, 'end': b, 'seconds': b-a,
             'location': 'opening' if i == 0 else 'ending' if i == len(bounds)-2 else 'middle'}
            for i, (a, b) in enumerate(zip(bounds, bounds[1:])) if b > a]
    violations = [g for g in gaps if g['seconds'] > MAX_GAP + .000002]
    # A ten-second empty edit must not pass merely because its one gap equals ten.
    if not times and duration >= MAX_GAP and not violations:
        violations = gaps[:]
    suggestions = []
    for g in gaps:
        if g['seconds'] > TARGET:
            count = max(1, math.ceil(g['seconds'] / TARGET) - 1)
            suggestions.extend({'search_near': g['start'] + g['seconds'] * (i+1)/(count+1),
                                'within': [g['start'], g['end']],
                                'action': 'Find a real stress, reaction, action or transition nearby; not an automatic cue'}
                               for i in range(count))
    thirds = []
    for i, label in enumerate(('opening_third', 'middle_third', 'ending_third')):
        a, b = duration*i/3, duration*(i+1)/3
        spans = [dict(start=max(a,g['start']), end=min(b,g['end']),
                      seconds=min(b,g['end'])-max(a,g['start']))
                 for g in gaps if g['end'] > a and g['start'] < b]
        thirds.append({'section': label, 'start': a, 'end': b,
                       'event_count': sum(a <= t < b for t in times),
                       'largest_uncovered_seconds': max([s['seconds'] for s in spans], default=0),
                       'violations_touching_section': [g for g in violations if g['end'] > a and g['start'] < b]})
    repeated = []
    run = []
    for e in events + [{'key': None, 'at': duration}]:
        if run and e.get('key') != run[-1].get('key'):
            if len(run) >= 3:
                repeated.append({'key': run[0].get('key'), 'count': len(run),
                                 'start': run[0]['at'], 'end': run[-1]['at'],
                                 'review': 'Check intended parallel/repeated action versus mechanical reuse'})
            run = []
        run.append(e)
    return {'status': 'needs_more_events' if violations else 'spacing_passed',
            'duration': duration, 'target_seconds': TARGET, 'maximum_gap_seconds': MAX_GAP,
            'events': events, 'distinct_event_count': len(times),
            'largest_gap_seconds': max(g['seconds'] for g in gaps),
            'gaps': gaps, 'violations': violations, 'thirds': thirds,
            'planning_search_points': suggestions, 'repeated_runs_to_review': repeated,
            'actual_listening': False, 'semantic_or_aesthetic_approval': False}


def from_plan(plan, fps=None):
    fps = plan_fps(plan) if fps is None else plan_fps(plan, fps)
    if fps <= 0:
        raise ValueError('Positive verified fps required')
    snap = lambda x: round(round(number(x, 'time')*fps)*1e6/fps)
    duration_us = sum(snap(t['end'])-snap(t['start']) for t in plan['takes'])
    duration = snap(duration_us/1e6)/1e6
    events = []
    for i, cue in enumerate(plan.get('sounds', [])):
        if cue.get('kind', 'sound') != 'sound' or cue.get('muted') or number(cue.get('volume', 1), 'volume') <= 0:
            continue
        anchor = (cue.get('selection') or {}).get('anchor') or {}
        offset = number(anchor.get('sound_offset_seconds', 0), 'sound offset')
        if offset < 0 or ('duration' in cue and offset >= number(cue['duration'], 'sound duration')):
            raise ValueError('Sound anchor lies outside selected sound')
        at = snap(cue['start'])/1e6 + offset
        events.append({'at': at, 'key': cue.get('path'), 'cue_index': i,
                       'timing_basis': 'recorded_event_offset' if anchor else 'clip_start_only'})
    result = review(duration, events)
    result['source'] = 'plan'
    return result


def from_native(draft):
    materials = {m['id']: m for m in draft.get('materials', {}).get('audios', [])}
    events, ignored = [], []
    for tr in draft.get('tracks', []):
        if tr.get('type') != 'audio':
            continue
        for seg in tr.get('segments', []):
            mat = materials.get(seg.get('material_id'), {})
            if mat.get('type') != 'sound':
                ignored.append({'segment_id': seg.get('id'), 'reason': 'not explicitly a sound-effect material'})
                continue
            if tr.get('muted') or tr.get('is_muted') or seg.get('muted') or seg.get('is_muted') or number(seg.get('volume', 1), 'volume') <= 0:
                continue
            r = seg['target_timerange']
            if r['duration'] <= 0:
                continue
            events.append({'at': r.get('start', 0)/1e6, 'key': mat.get('path') or mat.get('name'),
                           'segment_id': seg.get('id'), 'timing_basis': 'saved_clip_start_only'})
    result = review(draft['duration']/1e6, events)
    result.update(source='saved_native_structure', ignored_audio=ignored,
                  unknown_platform_mute_flags_verified=False,
                  note='Compare these saved segments with plan anchors; unknown platform flags and actual audio need playback.')
    return result


def require_spacing(report):
    if report['violations']:
        spans = ', '.join(f"{x['start']:.2f}–{x['end']:.2f}s" for x in report['violations'])
        raise ValueError('SFX spacing incomplete (target ~7s, max 10s): ' + spans)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('input', type=Path); p.add_argument('output', type=Path)
    p.add_argument('--native', action='store_true'); p.add_argument('--require-pass', action='store_true')
    a = p.parse_args(); data = json.loads(a.input.read_text(encoding='utf-8'))
    report = from_native(data) if a.native else from_plan(data)
    a.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(report['status'], 'largest gap', round(report['largest_gap_seconds'], 3))
    if a.require_pass: require_spacing(report)
