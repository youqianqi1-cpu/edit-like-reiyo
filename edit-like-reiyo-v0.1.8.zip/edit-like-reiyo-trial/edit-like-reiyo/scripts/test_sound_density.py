import copy
import tempfile
import unittest
import wave
from pathlib import Path
from unittest.mock import patch

from assemble import build
from sound_density import review, from_plan, from_native, require_spacing


class DensityTests(unittest.TestCase):
    def plan(self, duration=30, starts=(7, 14, 21, 28)):
        return {'fps': 24, 'takes': [{'source': 'v', 'start': 0, 'end': duration}],
                'sounds': [{'start': t, 'path': 'example.wav'} for t in starts]}

    def test_target_spacing_and_all_thirds(self):
        r = from_plan(self.plan())
        require_spacing(r)
        self.assertEqual(r['largest_gap_seconds'], 7)
        self.assertTrue(all(s['event_count'] for s in r['thirds']))
        self.assertFalse(r['actual_listening'])

    def test_full_duration_not_average_and_tail(self):
        r = from_plan(self.plan(60, tuple(range(0, 21))))
        self.assertEqual(r['violations'][-1]['location'], 'ending')
        self.assertEqual(r['largest_gap_seconds'], 40)
        with self.assertRaises(ValueError): require_spacing(r)
        self.assertTrue(r['thirds'][-1]['violations_touching_section'])

    def test_middle_and_opening_gaps(self):
        r = from_plan(self.plan(60, (12, 19, 45, 52, 59)))
        self.assertEqual([g['location'] for g in r['violations']], ['opening', 'middle'])
        self.assertEqual([(g['start'],g['end']) for g in r['violations']], [(0,12),(19,45)])

    def test_duplicate_and_long_file_not_extra_events(self):
        p = self.plan(40, (1, 1, 1))
        for c in p['sounds']: c['duration'] = 39
        r = from_plan(p)
        self.assertEqual(r['distinct_event_count'], 1)
        self.assertEqual(r['largest_gap_seconds'], 39)

    def test_ten_second_boundary_and_no_sound(self):
        require_spacing(from_plan(self.plan(30,(5,15,25))))
        require_spacing(from_plan(self.plan(3,())))
        with self.assertRaises(ValueError): require_spacing(from_plan(self.plan(10,())))

    def test_muted_music_and_nonfinite_not_counted(self):
        p = self.plan(30,(7,14,21))
        p['sounds'][0]['muted'] = True
        p['sounds'][1]['volume'] = 0
        p['sounds'][2]['kind'] = 'music'
        self.assertEqual(from_plan(p)['distinct_event_count'],0)
        p['sounds'] = [{'start':float('nan')}]
        with self.assertRaises(ValueError): from_plan(p)

    def test_event_offset_not_only_file_start(self):
        p = self.plan(20,(1,11))
        for c in p['sounds']:
            c['duration']=8
            c['selection']={'anchor':{'sound_offset_seconds':4}}
        self.assertEqual([e['at'] for e in from_plan(p)['events']],[5,15])

    def test_native_music_ignored_and_no_file_access(self):
        d = {'duration':30000000,'materials':{'audios':[{'id':'s','type':'sound','path':'s.wav'}, {'id':'m','type':'music','path':'m.wav'}]},
             'tracks':[{'type':'audio','segments':[
                 {'material_id':'s','target_timerange':{'start':7000000,'duration':500000}},
                 {'material_id':'m','target_timerange':{'start':14000000,'duration':1000000}},
                 {'material_id':'s','volume':0,'target_timerange':{'start':21000000,'duration':500000}}]}]}
        r = from_native(d)
        self.assertEqual(r['distinct_event_count'],1)
        self.assertEqual(r['largest_gap_seconds'],23)
        self.assertFalse(r['unknown_platform_mute_flags_verified'])

    def test_assembly_gate_runs_before_any_source_read(self):
        p = self.plan(60, (5,))
        with patch('assemble.pathlib.Path.is_file',side_effect=AssertionError('must stop first')):
            with self.assertRaisesRegex(ValueError,'SFX spacing incomplete'):
                build({'id':'fixture'},p,settings={'fps':24})

    def test_valid_plan_generates_matching_tracks_without_changing_input(self):
        with tempfile.TemporaryDirectory() as td:
            source=Path(td)/'source.mp4'; source.touch()
            audio=Path(td)/'sound.wav'
            with wave.open(str(audio),'wb') as w:
                w.setparams((1,2,24000,0,'NONE','not compressed'))
                w.writeframes(b'\x10\x00'*12000)
            p=self.plan()
            p.update(canvas={'width':1080,'height':1920},font=str(source),
                     sources={'v':{'path':str(source),'duration':30,'width':1080,'height':1920}},
                     caption_style={'color':'#24345A','background':'#FFFFFF','y':-.3},
                     captions=[{'text':'这个视频里的','start':1,'end':2},
                               {'text':'这个瑜伽老师了','start':2,'end':3}])
            for c in p['sounds']: c['path']=str(audio)
            p['punchline_review']={'reason':'Synthetic density fixture; no humour candidates','candidates':[]}
            before=copy.deepcopy(p)
            draft,_=build({'id':'fixture'},p,settings={'fps':24})
            self.assertEqual(p,before)
            r=from_native(draft);require_spacing(r)
            self.assertEqual(r['distinct_event_count'],4)
            text_tracks=[t for t in draft['tracks']if t['type']=='text']
            self.assertEqual(len(text_tracks),1)
            self.assertEqual(len(text_tracks[0]['segments']),2)
            a,b=text_tracks[0]['segments']
            self.assertLessEqual(a['target_timerange']['start']+a['target_timerange']['duration'],b['target_timerange']['start'])




# These fixtures have dummy video files; real final-signal gate tests live in test_final_breaths.
def setUpModule():
    from unittest.mock import patch
    global _signal_patch
    _signal_patch = patch('assemble.require_breath_review', return_value={'fixture_only': True})
    _signal_patch.start()
def tearDownModule():
    _signal_patch.stop()

if __name__ == '__main__': unittest.main()
