import Foundation
import AVFoundation

@main struct Probe {
  static func main() async {
    for path in CommandLine.arguments.dropFirst() {
      do {
        let asset = AVURLAsset(url: URL(fileURLWithPath: path))
        let duration = try await asset.load(.duration).seconds
        let tracks = try await asset.loadTracks(withMediaType: .video)
        var item: [String: Any] = ["path": path, "duration": duration, "probe_schema": 2]
        if let track = tracks.first {
          let size = try await track.load(.naturalSize)
          let transform = try await track.load(.preferredTransform)
          let bounds = CGRect(origin: .zero, size: size).applying(transform)
          item["width"] = abs(bounds.width); item["height"] = abs(bounds.height)
          item["fps"] = Double(try await track.load(.nominalFrameRate))
          item["fps_kind"] = "nominal; variable frame rate not determined"
        }
        let data = try JSONSerialization.data(withJSONObject: item, options: [.sortedKeys])
        print(String(data: data, encoding: .utf8)!)
      } catch { fputs("ERROR \(path): \(error)\n", stderr); exit(2) }
    }
  }
}
