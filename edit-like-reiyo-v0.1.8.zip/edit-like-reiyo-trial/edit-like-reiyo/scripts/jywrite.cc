#include <dlfcn.h>

#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>

namespace fs = std::filesystem;

template <class T>
T symbol(void* library, const char* name) {
  dlerror();
  auto output = reinterpret_cast<T>(dlsym(library, name));
  if (const char* error = dlerror())
    throw std::runtime_error(error);
  return output;
}

// The library returns opaque, non-trivial result objects. Matching that shape
// keeps the same hidden-result ABI; process teardown owns their inner storage.
struct SaveResult {
  void* begin = nullptr;
  void* end = nullptr;
  void* capacity = nullptr;
  ~SaveResult() {}
};

struct RawResult {
  unsigned char storage[64]{};
  ~RawResult() {}
};

int main(int argc, char** argv) try {
  if (argc != 3) {
    std::cerr << "usage: jywrite INPUT_JSON /tmp/jy-writer.*/draft\n";
    return 64;
  }

  const fs::path input = fs::weakly_canonical(argv[1]);
  const fs::path folder = fs::weakly_canonical(argv[2]);
  const std::string path = folder.string();
  const bool sandbox = path.rfind("/tmp/jy-writer.", 0) == 0 ||
                       path.rfind("/private/tmp/jy-writer.", 0) == 0;
  if (!sandbox || folder.filename() != "draft")
    throw std::runtime_error("refusing non-sandbox draft path");
  if (!fs::is_regular_file(folder / "draft_info.json"))
    throw std::runtime_error("sandbox draft_info.json is missing");

  std::ifstream stream(input, std::ios::binary);
  std::ostringstream bytes;
  bytes << stream.rdbuf();
  std::string json = bytes.str();
  if (!stream || json.size() < 2 || json.front() != '{' ||
      json.back() != '}')
    throw std::runtime_error("input is not a complete JSON object");

  constexpr const char* dylib =
      "/Applications/VideoFusion-macOS.app/Contents/Frameworks/libvideoeditor.dylib";
  void* library = dlopen(dylib, RTLD_NOW | RTLD_GLOBAL);
  if (!library)
    throw std::runtime_error(dlerror());

  using VoidMethod = void (*)(void*);
  using StringMethod = void (*)(void*, const std::string&);
  using SaveMethod = SaveResult (*)(void*, const std::string&);
  using ReadRawMethod =
      RawResult (*)(void*, const std::string&, std::string&, int*);
  using SetCipherMethod = void (*)(void*, int);

  auto factory_ctor = symbol<VoidMethod>(
      library, "_ZN11draft_store18DraftIOFactoryBaseC1Ev");
  auto factory_dtor = symbol<VoidMethod>(
      library, "_ZN11draft_store18DraftIOFactoryBaseD1Ev");
  auto as_global = symbol<VoidMethod>(
      library, "_ZN11draft_store18DraftIOFactoryBase8asGlobalEv");
  auto store_ctor =
      symbol<VoidMethod>(library, "_ZN11draft_store10DraftStoreC1Ev");
  auto store_dtor =
      symbol<VoidMethod>(library, "_ZN11draft_store10DraftStoreD1Ev");
  auto set_folder = symbol<StringMethod>(
      library,
      "_ZN11draft_store10DraftStore16setDraftFoldPathERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE");
  auto set_open_folder = symbol<StringMethod>(
      library,
      "_ZN11draft_store10DraftStore20setOpenDraftFoldPathERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE");
  auto read_raw = symbol<ReadRawMethod>(
      library,
      "_ZN11draft_store10DraftStore16readRawDraftFileERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERS7_PNS_15DraftCipherTypeE");
  auto set_cipher = symbol<SetCipherMethod>(
      library,
      "_ZN11draft_store10DraftStore18setDraftCipherTypeENS_15DraftCipherTypeE");
  auto save = symbol<SaveMethod>(
      library,
      "_ZN11draft_store10DraftStore17saveDraftJsonSyncERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE");

  void* factory = nullptr;
  if (posix_memalign(&factory, 64, 0x1018))
    throw std::bad_alloc();
  std::memset(factory, 0, 0x1018);
  factory_ctor(factory);
  std::shared_ptr<void> owner(factory, [factory_dtor](void* pointer) {
    factory_dtor(pointer);
    std::free(pointer);
  });
  *reinterpret_cast<std::weak_ptr<void>*>(
      static_cast<char*>(factory) + 8) = owner;
  as_global(factory);

  void* store = nullptr;
  if (posix_memalign(&store, 64, 0x800000))
    throw std::bad_alloc();
  std::memset(store, 0, 0x800000);
  store_ctor(store);

  const std::string folder_string = folder.string();
  set_folder(store, folder_string);
  set_open_folder(store, folder_string);

  const std::string draft_file = (folder / "draft_info.json").string();
  std::string old_json;
  int cipher_type = -1;
  RawResult read_result =
      read_raw(store, draft_file, old_json, &cipher_type);
  (void)read_result;
  if (old_json.empty() || cipher_type < 0)
    throw std::runtime_error(
        "could not read cipher type from sandbox draft");
  set_cipher(store, cipher_type);

  SaveResult result = save(store, json);
  store_dtor(store);
  std::free(store);

  const auto count =
      result.begin && result.end
          ? (static_cast<char*>(result.end) -
             static_cast<char*>(result.begin)) /
                0x58
          : 0;
  std::cout << "cipher_type=" << cipher_type << "\n"
            << "save_result_count=" << count << "\n";
  return count == 0 ? 2 : 0;
} catch (const std::exception& error) {
  std::cerr << "STOP: " << error.what() << "\n";
  return 1;
}
