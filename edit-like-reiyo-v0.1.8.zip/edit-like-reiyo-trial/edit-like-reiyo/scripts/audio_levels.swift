import Foundation
import AVFoundation
import AudioToolbox

// Measure decoded original channels at their native sample rate, without gain,
// resampling or mono downmix. Sample peaks are not true peaks or LUFS.
func db(_ value: Double) -> Any { value > 0 ? 20 * log10(value) : NSNull() }
struct Level {
  var peak = 0.0, squares = 0.0
  var count = 0, nearFullScale = 0
  mutating func add(_ value: Double) {
    peak = max(peak, abs(value)); squares += value * value; count += 1
    if abs(value) >= 0.999 { nearFullScale += 1 }
  }
  var json: [String: Any] {
    ["peak_dbfs": db(peak), "rms_dbfs": db(count > 0 ? sqrt(squares / Double(count)) : 0),
     "samples": count, "near_full_scale_samples": nearFullScale]
  }
}
@main struct AudioLevels {
  static func main() async {
    do {
      guard CommandLine.arguments.count == 2 else { throw NSError(domain: "Usage: audio_levels SOURCE", code: 2) }
      let asset = AVURLAsset(url: URL(fileURLWithPath: CommandLine.arguments[1]))
      guard let track = try await asset.loadTracks(withMediaType: .audio).first else {
        throw NSError(domain: "No audio track", code: 2)
      }
      let reader = try AVAssetReader(asset: asset)
      let output = AVAssetReaderTrackOutput(track: track, outputSettings: [
        AVFormatIDKey: kAudioFormatLinearPCM, AVLinearPCMBitDepthKey: 32,
        AVLinearPCMIsFloatKey: true, AVLinearPCMIsBigEndianKey: false,
        AVLinearPCMIsNonInterleaved: false])
      reader.add(output)
      guard reader.startReading() else { throw reader.error ?? NSError(domain: "Audio reader failed", code: 2) }
      var channels: [Level] = [], windows: [Int: Level] = [:]
      while let sample = output.copyNextSampleBuffer() {
        guard let description = CMSampleBufferGetFormatDescription(sample),
              let format = CMAudioFormatDescriptionGetStreamBasicDescription(description),
              let block = CMSampleBufferGetDataBuffer(sample) else {
          throw NSError(domain: "Missing decoded audio buffer", code: 2)
        }
        let n = Int(format.pointee.mChannelsPerFrame), rate = format.pointee.mSampleRate
        guard n > 0, rate > 0 else { throw NSError(domain: "Invalid audio format", code: 2) }
        if channels.isEmpty { channels = Array(repeating: Level(), count: n) }
        guard channels.count == n else { throw NSError(domain: "Audio channel layout changed", code: 2) }
        let length = CMBlockBufferGetDataLength(block)
        var values = [Float](repeating: 0, count: length / 4)
        let status = values.withUnsafeMutableBytes { CMBlockBufferCopyDataBytes(block, atOffset: 0, dataLength: length, destination: $0.baseAddress!) }
        guard status == noErr else { throw NSError(domain: "Cannot read audio samples", code: Int(status)) }
        let start = CMSampleBufferGetPresentationTimeStamp(sample).seconds
        guard start.isFinite else { throw NSError(domain: "Missing audio timestamp", code: 2) }
        for i in values.indices {
          let value = Double(values[i])
          guard value.isFinite else { throw NSError(domain: "Nonfinite audio sample", code: 2) }
          channels[i % n].add(value)
          let second = Int(floor(start + Double(i / n) / rate))
          windows[second, default: Level()].add(value)
        }
      }
      guard reader.status == .completed, !channels.isEmpty else {
        throw reader.error ?? NSError(domain: "Audio analysis incomplete", code: 2)
      }
      let result: [String: Any] = ["measurement": "original-channel sample peak and RMS; not LUFS or true peak",
        "channels": channels.map { $0.json },
        "windows": windows.keys.sorted().map { s -> [String: Any] in var v = windows[s]!.json; v["start"] = s; return v },
        "gain_applied_db": 0, "listened": false]
      let data = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
      print(String(data: data, encoding: .utf8)!)
    } catch { fputs("ERROR: \(error)\n", stderr); exit(2) }
  }
}
