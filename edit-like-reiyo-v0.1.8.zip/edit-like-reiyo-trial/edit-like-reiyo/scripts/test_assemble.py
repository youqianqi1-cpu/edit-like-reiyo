import copy
import pathlib
import tempfile
import unittest
from unittest.mock import patch

from assemble import build


class VisualNumberTests(unittest.TestCase):
    def setUp(self):
        probe = patch('media_settings.probe_source', return_value={'fps': 25})
        probe.start(); self.addCleanup(probe.stop)
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        source = pathlib.Path(self.temp.name) / 'source.mp4'
        source.touch()
        self.plan = {'fps':25,
            'punchline_review': {'reason':'Synthetic geometry fixture; no humour candidates','candidates':[]},
            'canvas': {'width': 1080, 'height': 1920, 'ratio': '9:16'},
            'font': str(source),
            'sources': {'main': {'path': str(source), 'duration': 3, 'width': 1080, 'height': 1920}},
            'takes': [{'source': 'main', 'start': 0, 'end': 3}],
        }

    def test_rejects_text_and_nonfinite_position_before_writing(self):
        for value in ['move closer', '0.2', None, True, float('nan'), float('inf')]:
            with self.subTest(value=value):
                plan = copy.deepcopy(self.plan)
                plan['takes'][0]['x'] = value
                with self.assertRaisesRegex(ValueError, 'x.*finite number'):
                    build({'id':'fixture'}, plan)

    def test_overlay_and_caption_share_position_guard(self):
        for kind in ['overlays', 'captions']:
            with self.subTest(kind=kind):
                plan = copy.deepcopy(self.plan)
                plan[kind] = [{'source': 'main', 'text': 'hello', 'start': 0, 'end': 1, 'x': 'editorial reason'}]
                with self.assertRaisesRegex(ValueError, 'x.*finite number'):
                    build({'id':'fixture'}, plan)

    def test_rejects_non_numeric_keyframe(self):
        self.plan['takes'][0]['keys'] = {'KFTypeScaleX': [(0, 1), (1, 'closer')]}
        with self.assertRaisesRegex(ValueError, 'KFTypeScaleX.*finite number'):
            build({'id':'fixture'}, self.plan)

    def test_valid_geometry_is_preserved(self):
        self.plan['takes'][0].update(x=-0.2, y=0.1, scale=1.15, keys={'KFTypeScaleX': [(0, 1), (1, 1.15)]})
        draft, _ = build({'id':'fixture'}, self.plan)
        self.assertEqual(draft['fps'], 25)
        segment = draft['tracks'][0]['segments'][0]
        self.assertEqual(segment['clip']['transform'], {'x': -0.2, 'y': 0.1})
        self.assertEqual(segment['clip']['scale'], {'x': 1.15, 'y': 1.15})
        self.assertEqual(segment['common_keyframes'][0]['keyframe_list'][1]['values'], [1.15])




# These fixtures have dummy video files; real final-signal gate tests live in test_final_breaths.
def setUpModule():
    from unittest.mock import patch
    global _signal_patch
    _signal_patch = patch('assemble.require_breath_review', return_value={'fixture_only': True})
    _signal_patch.start()
def tearDownModule():
    _signal_patch.stop()

if __name__ == '__main__': unittest.main()
