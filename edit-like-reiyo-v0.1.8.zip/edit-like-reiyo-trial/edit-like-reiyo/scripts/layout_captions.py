"""Lay out explicitly chosen semantic caption groups without changing speech timing."""
import argparse,copy,json,pathlib,unicodedata

def layout(plan,groups):
 p=copy.deepcopy(plan);caps=p.get('captions',[]);used=set();style=p.get('caption_style',{})
 for g in groups:
  ids=g['indices'];assert len(ids)>=2 and len(set(ids))==len(ids)
  assert all(isinstance(i,int) and 0<=i<len(caps) and i not in used for i in ids)
  assert ids==sorted(ids) and ids==list(range(ids[0],ids[-1]+1)), 'Groups must be contiguous'
  used.update(ids);items=[caps[i] for i in ids]
  assert all(a['end']<=b['start']+.001 for a,b in zip(items,items[1:])), 'Input must be ungrouped'
  rows=g.get('rows',[i//2 for i in range(len(ids))]);assert len(rows)==len(ids) and max(rows)<=1 and min(rows)>=0
  end=items[-1]['end'];size=g.get('size',p.get('caption_style',{}).get('size',7));gap=g.get('gap',.035)
  # Approximate glyph width only; the editor preview is the final layout check.
  widths=[sum(1 if unicodedata.east_asian_width(c)in 'WF' else .55 for c in it['text'])*size*.0115+.04 for it in items]
  for row in sorted(set(rows)):
   members=[j for j,v in enumerate(rows)if v==row];width=sum(widths[j]for j in members)+gap*(len(members)-1)
   assert width<=1.65, 'Split or simplify the semantic group; do not shrink to fit'
   left=g.get('x',style.get('x',-.24))-width/2
   assert left>=-.94 and left+width<=.86, 'Caption group outside safe horizontal region'
   for j in members:
    it=items[j];it.update(end=end,lane=j,size=size,x=left+widths[j]/2,y=g.get('y',style.get('y',-.20))-row*g.get('row_gap',.105),group=ids[0])
    # Grouping changes timing/layout, not a user's chosen appearance.
    palette=g.get('palette',style.get('palette'))
    if palette is not None:
     assert isinstance(palette,list) and palette and all(isinstance(v,dict) and set(v)<= {'color','background'} for v in palette), 'Palette accepts color/background only'
     it.update(palette[j%len(palette)])
    left+=widths[j]+gap
 return p

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('plan',type=pathlib.Path);a.add_argument('groups',type=pathlib.Path);a.add_argument('output',type=pathlib.Path);v=a.parse_args();v.output.write_text(json.dumps(layout(json.loads(v.plan.read_text(encoding='utf-8')),json.loads(v.groups.read_text(encoding='utf-8'))),ensure_ascii=False,indent=2), encoding='utf-8')
