// Decode into the original asset timeline; quiet gaps must not shift later cuts.
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>
#import <AudioToolbox/AudioToolbox.h>
#include <math.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

static int fail(NSString *message) {
    fprintf(stderr, "decode_audio: %s\n", message.UTF8String);
    return 2;
}

int main(int argc, const char *argv[]) {
    @autoreleasepool {
      @try {
        if (argc != 3) return fail(@"Usage: decode_audio INPUT OUTPUT.pcm");
        NSString *source = @(argv[1]), *destination = @(argv[2]);
        if (![[NSFileManager defaultManager] fileExistsAtPath:source]) return fail(@"Input does not exist");
        if ([[NSFileManager defaultManager] fileExistsAtPath:destination]) return fail(@"Output already exists; it was not overwritten");
        AVURLAsset *asset = [AVURLAsset URLAssetWithURL:[NSURL fileURLWithPath:source] options:nil];
        double duration = CMTimeGetSeconds(asset.duration);
        if (!isfinite(duration) || duration <= 0 || duration > 86400) return fail(@"Invalid or unsupported asset duration (maximum 24 hours)");
        NSArray<AVAssetTrack *> *tracks = [asset tracksWithMediaType:AVMediaTypeAudio];
        if (tracks.count == 0) return fail(@"No audio track in this source");
        NSError *error = nil;
        AVAssetReader *reader = [[AVAssetReader alloc] initWithAsset:asset error:&error];
        if (!reader) return fail([NSString stringWithFormat:@"Cannot open audio: %@", error]);
        NSDictionary *settings = @{ AVFormatIDKey:@(kAudioFormatLinearPCM), AVLinearPCMBitDepthKey:@16,
            AVLinearPCMIsFloatKey:@NO, AVLinearPCMIsBigEndianKey:@NO, AVLinearPCMIsNonInterleaved:@NO,
            AVSampleRateKey:@16000, AVNumberOfChannelsKey:@1 };
        // AudioMixOutput performs sample-rate/channel conversion, unlike TrackOutput on some codecs.
        AVAssetReaderAudioMixOutput *output = [[AVAssetReaderAudioMixOutput alloc] initWithAudioTracks:@[tracks.firstObject] audioSettings:settings];
        if (![reader canAddOutput:output]) return fail(@"Audio conversion output is not supported for this source");
        [reader addOutput:output];
        if (![reader startReading]) return fail([NSString stringWithFormat:@"Cannot start audio conversion: %@", reader.error]);
        NSUInteger bytes = (NSUInteger)ceil(duration * 16000) * 2;
        NSMutableData *pcm = [NSMutableData dataWithLength:bytes];
        NSUInteger buffers = 0, placed = 0;
        double first = NAN, last = NAN;
        CMSampleBufferRef buffer;
        while ((buffer = [output copyNextSampleBuffer])) {
            double pts = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(buffer));
            CMItemCount count = CMSampleBufferGetNumSamples(buffer);
            CMAudioFormatDescriptionRef format = CMSampleBufferGetFormatDescription(buffer);
            const AudioStreamBasicDescription *asbd = format ? CMAudioFormatDescriptionGetStreamBasicDescription(format) : NULL;
            CMBlockBufferRef block = CMSampleBufferGetDataBuffer(buffer);
            if (!isfinite(pts) || fabs(pts) > 172800 || count < 0 || !block || !asbd ||
                asbd->mFormatID != kAudioFormatLinearPCM || asbd->mSampleRate != 16000 ||
                asbd->mChannelsPerFrame != 1 || asbd->mBitsPerChannel != 16 || asbd->mBytesPerFrame != 2 ||
                !(asbd->mFormatFlags & kAudioFormatFlagIsSignedInteger) ||
                (asbd->mFormatFlags & (kAudioFormatFlagIsFloat | kAudioFormatFlagIsBigEndian | kAudioFormatFlagIsNonInterleaved)) ||
                CMBlockBufferGetDataLength(block) < (size_t)count * 2) {
                CFRelease(buffer); [reader cancelReading]; return fail(@"Invalid decoded audio format, timestamp or sample buffer");
            }
            int64_t start = llround(pts * 16000), left = MAX((int64_t)0, start);
            int64_t right = MIN((int64_t)(bytes / 2), start + count);
            if (right > left) {
                OSStatus status = CMBlockBufferCopyDataBytes(block, (size_t)(left-start)*2, (size_t)(right-left)*2, (char *)pcm.mutableBytes + left*2);
                if (status != kCMBlockBufferNoErr) {
                    CFRelease(buffer); [reader cancelReading]; return fail(@"Cannot copy decoded audio samples");
                }
                placed += right-left;
            }
            if (!buffers) first = pts;
            last = pts + count/16000.0;
            buffers++;
            CFRelease(buffer);
        }
        if (reader.status != AVAssetReaderStatusCompleted) return fail([NSString stringWithFormat:@"Audio conversion incomplete: %@", reader.error]);
        if (!buffers || !placed) return fail(@"No audio samples inside the source timeline");
        // Exclusive creation protects an existing result even if another process created it meanwhile.
        int fd = open(destination.fileSystemRepresentation, O_WRONLY | O_CREAT | O_EXCL, 0600);
        if (fd < 0) return fail([NSString stringWithFormat:@"Cannot create output: %s", strerror(errno)]);
        NSUInteger done = 0;
        while (done < bytes) {
            ssize_t n = write(fd, (char *)pcm.bytes + done, bytes-done);
            if (n < 0 && errno == EINTR) continue;
            if (n <= 0) { close(fd); unlink(destination.fileSystemRepresentation); return fail(@"Cannot finish writing audio output"); }
            done += n;
        }
        if (close(fd) != 0) { unlink(destination.fileSystemRepresentation); return fail(@"Cannot close audio output"); }
        printf("firstPTS=%.9f lastEnd=%.9f duration=%.9f samples=%lu\n",first,last,duration,(unsigned long)(bytes/2));
        return 0;
      } @catch (NSException *exception) {
        return fail([NSString stringWithFormat:@"Audio conversion failed: %@", exception.reason]);
      }
    }
}
