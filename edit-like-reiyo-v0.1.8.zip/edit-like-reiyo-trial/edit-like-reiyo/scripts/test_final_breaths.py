import array,copy,json,math,tempfile,unittest,wave
from pathlib import Path
from unittest.mock import patch
from audit_breaths import audit
from breath_review import candidates,evaluate,require_review,cut_signature
from check_cut_audio import make_audio
from media_settings import plan_fps
from align_captions import align,timing_review
from apply_cuts import apply
from assemble import build
from compose_beats import compose
import draft_io
from test_external_fixtures import metadata,review

def fixture_decisions(report):
 # Synthetic observations only; never use this helper to approve actual footage.
 from breath_review import pending_decisions
 def part(source,a,b,kind='weak_speech'):
  return {'source':source,'start':a,'end':b,'disposition':kind,'reason':'Synthetic fixture retained',
          'evidence':{'source':source,'start':a,'end':b,'kind':'signal','scan_signature':report['scan_signature'],
                      'pcm_sha256':report['inputs'][source]['pcm_sha256'],'observation':'Synthetic amplitude fixture'}}
 ds=pending_decisions(report)
 for item,c in zip(ds['items'],candidates(report)):
  item['action']='keep'
  if 'source' in c:item['segments']=[part(c['source'],c['start'],c['end'])]
 for row,j in zip(ds['join_reviews'],report['joins']):
  for side in ('left','right'):
   ctx=j[side+'_context']
   row[side]=[part(ctx['source'],r['start'],r['end'],'weak_speech' if r['kind']=='low_energy' else 'voiced_context')for r in ctx['regions']]
 return ds

class FinalSignalTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
  self.folder=self.root/'main';self.folder.mkdir();self.raw=self.root/'source.mp4';self.raw.touch()
  st=self.raw.stat();(self.folder/'receipt.json').write_text(json.dumps({'source':str(self.raw),'source_size':st.st_size,'source_mtime_ns':st.st_mtime_ns}))
  self.pcm=self.folder/'audio.pcm';self.pcm.write_bytes(array.array('h',[3000]*16000+[100]*16000+[3000]*16000).tobytes())
  self.plan={'fps':24,'sources':{'main':{'path':str(self.raw),'duration':3,'width':1080,'height':1920}},'takes':[{'source':'main','start':0,'end':1.5},{'source':'main','start':2,'end':3}],
             'canvas':{'width':1080,'height':1920},'font':str(self.raw),'punchline_review':{'reason':'Synthetic fixture','candidates':[]}}
 def bind(self,plan=None):
  p=plan or self.plan;r=audit(p,self.root);rp=self.root/'scan.json';dp=self.root/'decisions.json'
  rp.write_text(json.dumps(r));ds=fixture_decisions(r);dp.write_text(json.dumps(ds))
  p['breath_review']={'report':str(rp),'decisions':str(dp)};return r,ds
 def test_final_extension_invalidates_even_if_asr_claims_protection(self):
  self.bind();self.assertEqual(require_review(self.plan)['status'],'signal_review_complete')
  self.plan['takes'][0]['end']+=4/24
  with self.assertRaisesRegex(ValueError,'changed after breath scan'):require_review(self.plan)
 def test_changed_pcm_and_source_path_invalidate(self):
  self.bind();p=copy.deepcopy(self.plan);p['sources']['main']['path']='different.mp4'
  with self.assertRaises(ValueError):require_review(p)
  self.pcm.write_bytes(bytes(self.pcm.stat().st_size))
  with self.assertRaisesRegex(ValueError,'PCM changed'):require_review(self.plan)
 def test_unresolved_missing_duplicate_and_removed_do_not_pass(self):
  r,ds=self.bind()
  for mode in ['unresolved','missing','duplicate','removed']:
   d=copy.deepcopy(ds)
   if mode=='unresolved':d['items'][0]['action']='unresolved';self.assertEqual(evaluate(r,d)['status'],'unresolved');continue
   if mode=='missing':d['items'].pop()
   elif mode=='duplicate':d['items'].append(d['items'][0])
   else:d['items'][0]['action']='removed'
   with self.assertRaises(ValueError):evaluate(r,d)
  ds['items'][0]['action']='unresolved';Path(self.plan['breath_review']['decisions']).write_text(json.dumps(ds))
  with self.assertRaisesRegex(ValueError,'unresolved'):require_review(self.plan)
 def test_no_build_or_install_without_final_review(self):
  with self.assertRaisesRegex(ValueError,'breath signal review missing'):build({'id':'fixture'},self.plan,settings={'fps':24},pending_preview=True)
  self.bind();d,_=build({'id':'unit'},self.plan,settings={'fps':24},pending_preview=True);folder=self.root/'closed';folder.mkdir();active=folder/'draft_info.json';active.write_text('{"id":"unit","tracks":[]}');candidate=self.root/'candidate.json';candidate.write_text(json.dumps(d));metadata(folder);review(candidate)
  before=active.read_bytes();self.plan['takes'][0]['end']+=1/24
  with self.assertRaises(ValueError):draft_io.install(folder,candidate,draft_io.sha(active),'closed',True,self.plan,pending_preview=True)
  self.assertEqual(active.read_bytes(),before)
  self.plan['takes'][0]['end']-=1/24
  receipt=draft_io.install(folder,candidate,draft_io.sha(active),'closed',True,self.plan,pending_preview=True)
  self.assertTrue(receipt['saved']);self.assertEqual(draft_io.read(folder),d)
 def test_packaging_splits_keep_review_but_native_cut_change_fails(self):
  self.bind();p=copy.deepcopy(self.plan);p['takes']=[{'source':'main','start':0,'end':.5},{'source':'main','start':.5,'end':1.5},p['takes'][1]]
  self.assertEqual(cut_signature(p),cut_signature(self.plan));require_review(p)
  d,_=build({'id':'unit'},p,settings={'fps':24},pending_preview=True)
  from breath_review import check_native
  check_native(p,d);d['tracks'][0]['segments'][0]['source_timerange']['start']+=41667
  with self.assertRaises(ValueError):check_native(p,d)
 def test_65_final_takes_and_64_joins_not_old_56(self):
  self.pcm.write_bytes(array.array('h',[3000]*16000*130).tobytes());p=copy.deepcopy(self.plan);p['takes']=[{'source':'main','start':i*2,'end':i*2+1}for i in range(65)]
  r=audit(p,self.root);self.assertEqual((len(r['takes']),len(r['joins'])),(65,64))
  p2=copy.deepcopy(p);p2['takes']=[]
  for i,t in enumerate(p['takes']):
   p2['takes']+= [dict(t,end=t['start']+.5),dict(t,start=t['start']+.5)] if i<21 else [t]
  self.assertEqual(len(p2['takes']),86);self.assertEqual(cut_signature(p),cut_signature(p2))
 def test_weak_word_and_punctuation_are_distinguished_without_auto_cut(self):
  words=[{'text':'案','start':1.05,'duration':.15},{'text':'。','start':1.2,'duration':.8}]
  (self.folder/'words.jsonl').write_text('\n'.join(json.dumps(w)for w in words))
  before=copy.deepcopy(self.plan);r=audit(self.plan,self.root);c=r['takes'][0]['quiet_candidates'][0]
  self.assertEqual([w['text']for w in c['word_hints']],['案']);self.assertEqual(c['decision'],'review_required');self.assertEqual(self.plan,before)
 def test_explicit_fps_missing_invalid_and_mismatch(self):
  for v in [None,True,0,float('nan'),float('inf'),'24']:
   p=dict(self.plan,fps=v)
   with self.assertRaises(ValueError):audit(p,self.root)
   with self.assertRaises(ValueError):apply(p,[])
   with self.assertRaises(ValueError):compose(p,[],self.root)
   with self.assertRaises(ValueError):make_audio(p,self.root,self.root/'out')
  with self.assertRaises(ValueError):build({'id':'fixture'},self.plan,settings={'fps':30})
  p=dict(self.plan);p.pop('fps')
  with self.assertRaises(ValueError):audit(p,self.root)
 def test_fractional_rate_audio_uses_final_target_sample_count(self):
  p=dict(self.plan,fps=30000/1001);p['takes']=[{'source':'main','start':0,'end':1/p['fps']}for _ in range(100)]
  report=make_audio(p,self.root,self.root/'out')
  with wave.open(str(self.root/'out/cut-check.wav'))as w:self.assertEqual(w.getnframes(),round(100/p['fps']*16000))
 def test_cut_through_moving_overlay_and_sound_preserves_retained_source_samples(self):
  p=copy.deepcopy(self.plan);p['overlays']=[{'source':'main','start':.5,'end':2,'source_start':.2}];p['sounds']=[{'path':'unused','start':.5,'duration':1.5,'source_start':.3}]
  q,_=apply(p,[{'source':'main','start':1.25,'end':1.5}])
  self.assertEqual([(x['start'],x['end'])for x in q['overlays']],[(.5,1.25),(1.25,1.75)])
  self.assertAlmostEqual(q['overlays'][1]['source_start'],1.2)
  self.assertEqual([x['duration']for x in q['sounds']],[.75,.5]);self.assertAlmostEqual(q['sounds'][1]['source_start'],1.3)
  self.assertTrue(all(x.get('retiming_review_required')for x in q['sounds']))
 def test_retime_shifts_caption_overlay_sound_anchor_and_invalidates_review(self):
  p=copy.deepcopy(self.plan);p.update(captions=[{'text':'字','start':1.5,'end':2}],overlays=[{'source':'main','start':1.5,'end':2,'source_start':.3}],sounds=[{'path':'unused','start':1.75,'duration':.2,'selection':{'anchor':{'timeline_seconds':1.8,'sound_offset_seconds':.05}}}])
  self.bind(p);q,_=apply(p,[{'source':'main','start':1.25,'end':1.5}])
  self.assertEqual(q['captions'][0]['start'],1.25);self.assertEqual(q['overlays'][0]['source_start'],.3);self.assertEqual(q['sounds'][0]['start'],1.5)
  self.assertAlmostEqual(q['sounds'][0]['selection']['anchor']['timeline_seconds'],round(1.8*24)/24-.25)
  with self.assertRaises(ValueError):require_review(q)

class CaptionInsertionTests(unittest.TestCase):
 def test_empty_or_only_punctuation_cannot_invent_word_times(self):
  for words in [[],[{'text':'。','start':0,'duration':1}]]:
   with self.assertRaisesRegex(ValueError,'No spoken word timings'):align(words,'测试')
  self.assertEqual(align([],''),([],[]))
 def test_trailing_insertion_is_untimed_not_punctuation_duration(self):
  w=[{'text':'文','start':1,'duration':.2},{'text':'。','start':1.2,'duration':1}]
  cs,changes=align(w,'文|案');self.assertEqual(cs[-1]['start'],1.2);self.assertEqual(cs[-1]['end'],1.2)
  self.assertTrue(changes[-1]['timing_review_required']);self.assertEqual(len(timing_review(w,cs)['untimed_captions']),1)
  from caption_phrases import check,require_resolved
  with self.assertRaisesRegex(ValueError,'timing unresolved'):require_resolved(check({'captions':cs}))
 def test_internal_insertion_uses_gap_without_overlapping_equal_words(self):
  cs,changes=align([{'text':'我','start':0,'duration':.2},{'text':'你','start':.4,'duration':.2}],'我|爱|你')
  self.assertLessEqual(cs[1]['end'],cs[2]['start']);self.assertEqual(cs[2]['start'],.4)

if __name__=='__main__':unittest.main()
