"""Linked shrink/sound/restore checks; semantic evidence is recorded, not inferred."""
import argparse
import copy
import json
import math
import wave
from pathlib import Path


def number(value, name):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError('Punchline '+name+' must be finite')
    return value


def review(plan):
    r = plan.get('punchline_review')
    if not isinstance(r, dict) or not str(r.get('reason', '')).strip():
        raise ValueError('Record punchline_review.reason and candidates; no suitable beat is a valid decision')
    candidates = r.get('candidates')
    if not isinstance(candidates, list):
        raise ValueError('punchline_review.candidates must be a list')
    seen = set()
    for c in candidates:
        for key in ('id', 'source', 'quote', 'evidence', 'reason'):
            if not isinstance(c.get(key), str) or not c[key].strip():
                raise ValueError('Punchline candidate needs '+key)
        if c['id'] in seen or type(c.get('selected')) is not bool:
            raise ValueError('Duplicate candidate id or missing selected decision')
        seen.add(c['id'])
        if not 0 <= number(c.get('start'), 'start') < number(c.get('end'), 'end'):
            raise ValueError('Invalid candidate source range')
    return candidates


def geometry(t):
    return {k: t.get(k, default) for k, default in (('scale', 1.), ('x', 0.), ('y', 0.))}


def rows(plan, fps):
    result = []; cursor = 0
    for t in plan['takes']:
        length = round(t['end']*fps)-round(t['start']*fps)
        result.append((cursor, cursor+length, t))
        cursor += length
    return result


def protected_takes(plan, fps):
    result=[]
    for t in plan['takes']:
        row={'source':t['source'],'start':round(t['start']*fps),'end':round(t['end']*fps),'volume':t.get('volume',1.)}
        if result and result[-1]['source']==row['source'] and result[-1]['end']==row['start'] and result[-1]['volume']==row['volume']:
            result[-1]['end']=row['end']
        else:result.append(row)
    return result


def covered(items, start, end):
    pieces = [(max(a,start),min(b,end),v) for a,b,v in items if a < end and b > start]
    pieces.sort(key=lambda x:x[0]); cursor=start
    for a,b,_ in pieces:
        if a != cursor or b <= a:
            raise ValueError('Punchline phase has a gap or overlap')
        cursor=b
    if cursor != end:
        raise ValueError('Punchline phase is missing')
    return pieces


def prepare_event(base, beat, at, fps):
    # Read the original geometry, never treat a preceding push-in as normal framing.
    cs = {c['id']:c for c in review(base)}
    c = cs.get(beat.get('candidate_id'))
    if not c or not c['selected'] or c['source'] != beat.get('source'):
        raise ValueError('Punchline must link a selected, evidenced candidate')
    if 'fps' not in base:
        raise ValueError('Resolve actual fps explicitly before a punchline beat; do not assume 30')
    times = [number(beat.get(k), k) for k in ('start','shrink_at','restore_at','end')]
    if not c['start'] <= times[0] < times[1] < times[2] < times[3] <= c['end']:
        raise ValueError('Punchline needs ordered normal/shrink/restore spans inside its candidate')
    mapped = [at(c['source'], t) for t in times]
    frames = [round(t*fps) for t in mapped]
    if any(a>=b for a,b in zip(frames,frames[1:])):
        raise ValueError('Punchline phases collapse on the frame grid')
    before = covered(rows(base,fps), frames[0],frames[3])
    baseline = geometry(before[0][2])
    for _,_,t in before:
        if geometry(t)!=baseline or t.get('keys'):
            raise ValueError('Punchline would overwrite existing framing/motion; choose another span or obtain a specific change')
    for k,v in baseline.items():number(v,k)
    scale = number(beat.get('scale'),'scale')
    # 20% is a structural minimum for this chosen recipe, not a universal humour rule.
    if not 0 < scale <= baseline['scale']*.8:
        raise ValueError('Punchline must visibly shrink below NORMAL framing (at least 20%), not merely undo a push-in')
    sound = copy.deepcopy(beat.get('sound',{}))
    if not sound.get('path') or not Path(sound['path']).is_file():
        raise ValueError('Punchline needs an available sound file')
    sound['start']=at(c['source'],number(sound.pop('at',None),'sound.at'))
    sound.setdefault('source_start',0.);sound.setdefault('volume',1.)
    if sound.get('muted') or number(sound['volume'],'sound.volume')<=0:
        raise ValueError('Punchline sound must be audible in the plan')
    offset=number(beat.get('sound_offset_seconds',0.),'sound_offset_seconds')
    if offset<0 or abs(sound['start']+offset-mapped[1])>1/fps+1e-6:
        raise ValueError('Punchline sound landing does not match shrink landing')
    with wave.open(str(sound['path'])) as wav:
        available=wav.getnframes()/wav.getframerate()
    sound.setdefault('duration',available-sound['source_start'])
    if not 0<=sound['source_start']<available or not 0<sound['duration']<=available-sound['source_start']+1e-6 or offset>=sound['duration']:
        raise ValueError('Punchline sound selection is outside the file or omits its landing')
    if sound['start']+sound['duration']>mapped[3]+1/fps:
        raise ValueError('Punchline sound extends past the reviewed event; inspect its tail')
    sound['punchline_id']=c['id'];sound['reason']=beat['reason']
    return {'id':c['id'],'source':c['source'],'fps':fps,
            'start':mapped[0],'shrink_at':mapped[1],'restore_at':mapped[2],'end':mapped[3],
            'baseline':baseline,'shrink':dict(baseline,scale=scale),
            'sound':sound,'sound_offset_seconds':offset}


def check_plan(plan, fps):
    cs=review(plan); selected={c['id'] for c in cs if c['selected']}
    events=plan.get('punchline_events',[])
    ids=[e['id'] for e in events]
    if set(ids)!=selected or len(ids)!=len(set(ids)):
        raise ValueError('Selected punchline is missing, duplicated, or has no decision')
    if any(abs(e['fps']-fps)>1e-6 for e in events):
        raise ValueError('Punchline fps differs from final draft')
    if events and plan.get('punchline_protected_takes')!=protected_takes(plan,fps):
        raise ValueError('Punchline source cuts/order/voice protection missing or changed')
    spans=[];items=rows(plan,fps)
    for e in events:
        if abs(e['fps']-fps)>1e-6:raise ValueError('Punchline fps differs from final draft')
        fs=[round(number(e[k],k)*fps) for k in ('start','shrink_at','restore_at','end')]
        if any(a>=b for a,b in zip(fs,fs[1:])):raise ValueError('Invalid punchline phases')
        if any(fs[0]<z and fs[3]>a for a,z in spans):raise ValueError('Punchline events overlap')
        spans.append((fs[0],fs[3]))
        if not 0<e['shrink']['scale']<=e['baseline']['scale']*.8:
            raise ValueError('Returning to baseline does not count as a shrink')
        for a,b,g in [(fs[0],fs[1],e['baseline']),(fs[1],fs[2],e['shrink']),(fs[2],fs[3],e['baseline'])]:
            for _,_,t in covered(items,a,b):
                if geometry(t)!=g or t.get('keys'):
                    raise ValueError('Punchline '+e['id']+' framing was missing or overwritten')
        if abs(e['sound']['start']+e['sound_offset_seconds']-e['shrink_at'])>1/fps+1e-6:
            raise ValueError('Punchline sound landing has drifted')
        sounds=[s for s in plan.get('sounds',[]) if s.get('punchline_id')==e['id']]
        if len(sounds)!=1 or sounds[0]!=e['sound']:
            raise ValueError('Punchline '+e['id']+' sound was missing or changed; re-plan the linked event')
    return {'status':'passed','selected':len(events),'declined':len(cs)-len(events),
            'semantic_evidence_verified':False,'playback_verified':False}


def check_native(plan, draft):
    fps=draft['fps'];report=check_plan(plan,fps)
    if not plan.get('punchline_events'):return report
    tracks=[t for t in draft['tracks'] if t.get('name') in ('原素材 · 独立选段', '待审预览 · 气口未验收') and t['type']=='video']
    if len(tracks)!=1:raise ValueError('Cannot identify the punchline main track')
    main=tracks[0]['segments']
    native_rows=[(round(s['target_timerange'].get('start',0)/1e6*fps),
                  round((s['target_timerange'].get('start',0)+s['target_timerange']['duration'])/1e6*fps),s) for s in main]
    videos={m['id']:m for m in draft['materials']['videos']}
    # Source order, cuts and original voice must still equal the approved plan.
    expected=rows(plan,fps)
    for a,b,s in native_rows:
        for lo,hi,t in covered(expected,a,b):
            exp=next(x for x in expected if x[2] is t)
            src=s.get('source_timerange',{})
            actual_src=round(src.get('start',0)/1e6*fps)+(lo-a)
            wanted_src=round(t['start']*fps)+(lo-exp[0])
            if (Path(videos[s['material_id']]['path']).resolve()!=Path(plan['sources'][t['source']]['path']).resolve()
                or actual_src!=wanted_src or round(src.get('duration',-1)/1e6*fps)!=round(s['target_timerange']['duration']/1e6*fps) or s.get('speed',1)!=1 or s.get('volume',1)!=t.get('volume',1)):
                raise ValueError('Punchline native source/voice differs from protected plan')
    covered(native_rows,0,expected[-1][1])
    texts={m['id']:m for m in draft['materials']['texts']}
    actual_captions=[]
    for tr in draft['tracks']:
        if tr['type']!='text' or not (tr.get('name')=='短句字幕' or tr.get('name','').startswith('短句累积 ')):continue
        for seg in tr['segments']:
            tm=seg['target_timerange'];pos=seg['clip']['transform']
            actual_captions.append((json.loads(texts[seg['material_id']]['content'])['text'],round(tm.get('start',0)/1e6*fps),round((tm.get('start',0)+tm['duration'])/1e6*fps),pos['x'],pos['y']))
    style=plan.get('caption_style',{});expected_captions=[]
    for c in plan.get('captions',[]):
        a=round(max(0,c['start'])*fps);b=round(min(draft['duration']/1e6,c['end'])*fps)
        if b>a:expected_captions.append((c['text'],a,b,c.get('x',style.get('x',0)),c.get('y',style.get('y',-.31))))
    if sorted(actual_captions)!=sorted(expected_captions):
        raise ValueError('Punchline native captions changed from the approved plan')
    audios={m['id']:m for m in draft['materials']['audios']}
    for e in plan['punchline_events']:
        fs=[round(e[k]*fps) for k in ('start','shrink_at','restore_at','end')]
        for a,b,g in [(fs[0],fs[1],e['baseline']),(fs[1],fs[2],e['shrink']),(fs[2],fs[3],e['baseline'])]:
            for _,_,s in covered(native_rows,a,b):
                clip=s.get('clip',{});sc=clip.get('scale',{});pos=clip.get('transform',{})
                vals=[sc.get('x'),sc.get('y'),pos.get('x'),pos.get('y')]
                wants=[g['scale'],g['scale'],g['x'],g['y']]
                if any(type(v)not in(int,float) or not math.isfinite(v) or abs(v-w)>1e-6 for v,w in zip(vals,wants)) or clip.get('alpha',1)<=0 or s.get('common_keyframes'):
                    raise ValueError('Punchline '+e['id']+' native framing missing/overridden')
        cue=e['sound'];matches=[]
        for tr in draft['tracks']:
            if tr['type']!='audio':continue
            for s in tr['segments']:
                m=audios.get(s['material_id'],{})
                if (Path(m.get('path','')).resolve()==Path(cue['path']).resolve()
                    and round(s['target_timerange'].get('start',0)/1e6*fps)==round(cue['start']*fps)):
                    matches.append(s)
        if len(matches)!=1:raise ValueError('Punchline native sound missing or duplicated')
        s=matches[0];sr=s.get('source_timerange',{});dur=s['target_timerange']['duration']/1e6
        if (s.get('volume',1)!=cue['volume'] or s.get('speed',1)!=1 or s.get('common_keyframes')
            or round(sr.get('start',0)/1e6*fps)!=round(cue['source_start']*fps)
            or dur<=e['sound_offset_seconds']
            or ('duration' in cue and abs(dur-cue['duration'])>1/fps+1e-6)):
            raise ValueError('Punchline native sound muted/trimmed/overridden')
    return dict(report,stage='native_structure',playback_verified=False)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('plan',type=Path);ap.add_argument('output',type=Path);ap.add_argument('--native',type=Path)
    args=ap.parse_args();p=json.loads(args.plan.read_text(encoding='utf-8'))
    if args.native:r=check_native(p,json.loads(args.native.read_text(encoding='utf-8')))
    else:r=check_plan(p,p['fps'])
    args.output.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(r,ensure_ascii=False))
