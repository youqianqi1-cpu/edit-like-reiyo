"""Install an isolated fallback; never rebuild system tools or upload footage."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import venv


def prepare(download_model=False):
    if not ((3,10) <= sys.version_info[:2] <= (3,12)) or sys.maxsize <= 2**32:
        raise RuntimeError('Use the 64-bit Python 3.10–3.12 available to Codex for this setup.')
    root = Path(__file__).resolve().parents[1]
    runtime = root/'.runtime'; env = runtime/'venv'
    python = env/('Scripts/python.exe' if sys.platform == 'win32' else 'bin/python3')
    if not python.exists(): venv.EnvBuilder(with_pip=True).create(env)
    check = subprocess.run([str(python), '-c', 'import av,numpy,faster_whisper'], capture_output=True, timeout=30)
    if check.returncode:
        print('Preparing local fallback dependencies; footage stays on this computer.', flush=True)
        command=[str(python), '-m', 'pip', 'install', '--disable-pip-version-check', '--retries','0',
                 '--timeout','20','-r',str(root/'scripts/requirements-windows.txt')]
        # Two known package indexes; bounded fallback for slow international downloads.
        try:
            subprocess.run(command+['--index-url','https://pypi.org/simple'],check=True,timeout=90)
        except (subprocess.CalledProcessError,subprocess.TimeoutExpired):
            print('Public index download failed or timed out; trying Tsinghua PyPI mirror once.',flush=True)
            subprocess.run(command+['--index-url','https://pypi.tuna.tsinghua.edu.cn/simple'],check=True,timeout=150)
    model = runtime/'models'/('whisper-small' if sys.platform == 'win32' else 'whisper-base')
    if download_model and not all((model/name).is_file() for name in ['model.bin','config.json','tokenizer.json','vocabulary.txt']):
        print('Downloading a local multilingual speech model once; no footage is sent.', flush=True)
        model.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run([str(python), '-c',
            'from faster_whisper.utils import download_model; import sys; download_model(sys.argv[1],output_dir=sys.argv[2])',
            'small' if sys.platform == 'win32' else 'base', str(model)], check=True, timeout=300,
            env={**os.environ, 'HF_HUB_DOWNLOAD_TIMEOUT':'30', 'HF_HUB_ETAG_TIMEOUT':'15', 'HF_HUB_DISABLE_XET':'1'})
    return python, model

if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('--download-model',action='store_true'); a=p.parse_args()
    try:
        python,model=prepare(a.download_model); print('Python:',python); print('Model:',model)
    except (OSError, RuntimeError, subprocess.SubprocessError) as e: p.exit(2,str(e)+'\n')
