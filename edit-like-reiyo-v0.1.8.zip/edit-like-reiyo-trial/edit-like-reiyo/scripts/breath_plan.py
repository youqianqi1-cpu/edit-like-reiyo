"""Organize this video's chosen phrases and reviewed edges, without choosing cuts.

The model supplies choices from the current transcript, then inspects the waveform.
Internal removals continue through apply_cuts.py and its final-scan workflow.
"""
import argparse
import copy
import json
import math
from pathlib import Path

from media_settings import plan_fps
from select_takes import select


def select_phrases(source, words, choices, source_key="main"):
    rows = []
    for choice in choices:
        if not choice["text"].strip() or not choice["reason"].strip():
            raise ValueError("Each phrase needs current transcript text and a selection reason")
        row = select(words, choice["text"], choice.get("after", 0))
        row.update(source=source_key, reason=choice["reason"])
        rows.append(row)
    if not rows:
        raise ValueError("Choose at least one phrase")
    return {
        "editing_scope": "breath_only",
        "canvas": {"ratio": "original", "width": source["width"], "height": source["height"]},
        "sources": {source_key: source},
        "takes": [{k: row[k] for k in ("source", "start", "end", "reason")} for row in rows],
        "captions": [], "titles": [], "sounds": [], "overlays": [],
        "punchline_review": {"reason": "Requested selection and breath cuts only", "candidates": []},
        "selected_phrases": rows,
    }


def set_edges(plan, edges):
    if plan.get("editing_scope") != "breath_only" or any(
        plan.get(k) for k in ("captions", "titles", "sounds", "overlays", "punchline_events")
    ):
        raise ValueError("Set phrase edges before packaging; use the existing retiming workflow for packaged edits")
    fps = plan_fps(plan)
    if len(edges) != len(plan["takes"]):
        raise ValueError("Supply one reviewed boundary per selected phrase, in order")
    result = copy.deepcopy(plan)
    for take, edge in zip(result["takes"], edges):
        if edge["source"] != take["source"] or not edge["reason"].strip():
            raise ValueError("Every boundary must match its source and record the observation")
        a, b = edge["start"], edge["end"]
        limit = result["sources"][take["source"]]["duration"]
        if not all(isinstance(x, (int, float)) and math.isfinite(x) for x in (a, b)):
            raise ValueError("Boundary times must be finite numbers")
        if not 0 <= a < b <= limit:
            raise ValueError("Reviewed boundary is outside the source")
        # Include the frames containing the observed onset and ending.
        # This is frame alignment, not a fixed silence allowance.
        start_frame = math.floor(a * fps + 1e-7)
        end_frame = min(math.ceil(b * fps - 1e-7), math.floor(limit * fps + 1e-7))
        if start_frame >= end_frame:
            raise ValueError("Reviewed phrase has no complete output frame")
        take.update(start=start_frame/fps, end=end_frame/fps, reason=edge["reason"])
        take.pop("at", None)
        take.pop("duration", None)
    # Boundary changes invalidate earlier checks, including a previous approval.
    result.pop("breath_review", None)
    result["breath_review_state"] = {
        "status": "rescan_required", "formal_accepted": False, "actual_listening": False,
    }
    return result


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    choose = commands.add_parser("select")
    choose.add_argument("source")
    choose.add_argument("words")
    choose.add_argument("choices")
    choose.add_argument("output")
    choose.add_argument("--source-key", default="main")
    edges = commands.add_parser("edges")
    edges.add_argument("plan")
    edges.add_argument("boundaries")
    edges.add_argument("output")
    args = parser.parse_args()
    output = Path(args.output)
    if output.exists():
        raise ValueError("Use a new output filename; preserve previous plans")
    if args.command == "select":
        words = [json.loads(line) for line in Path(args.words).read_text(encoding="utf-8").splitlines() if line.strip()]
        result = select_phrases(read(args.source), words, read(args.choices), args.source_key)
    else:
        result = set_edges(read(args.plan), read(args.boundaries))
    with output.open("x", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(f"{len(result['takes'])} phrases saved to {output}; inspect and scan before delivery")


if __name__ == "__main__":
    main()
