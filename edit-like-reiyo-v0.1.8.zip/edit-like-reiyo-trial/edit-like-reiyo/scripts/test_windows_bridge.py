from test_external_fixtures import metadata,review
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import draft_windows as bridge


class CodecDouble:
    """Checks write safeguards, not Jianying Windows binary compatibility."""
    def encode(self, value): return b'test:'+value.encode('utf-8')
    def decode(self, value): return json.loads(value.removeprefix(b'test:').decode('utf-8'))


class WindowsDraftGuards(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.folder=Path(self.tmp.name).resolve()/'剪出帧我试剪'; self.folder.mkdir()
        self.codec=CodecDouble(); self.blank={'id':'new-project','tracks':[],'name':'中文标题'}
        self.main=self.folder/'draft_info.json'
        self.main.write_bytes(self.codec.encode(json.dumps(self.blank,ensure_ascii=False)))
        timeline=self.folder/'Timelines/only'; timeline.mkdir(parents=True)
        self.timeline=timeline/'draft_info.json'; self.timeline.write_bytes(self.main.read_bytes())
        self.original=Path(self.tmp.name)/'original.json'; self.original.write_bytes(b'leave original untouched')

    def init(self):
        metadata(self.folder)
        return bridge.initialize(self.folder,self.folder.name,self.codec,True)

    def candidate(self, **kwargs):
        value=copy.deepcopy(self.blank); value.update(kwargs)
        path=Path(self.tmp.name)/'candidate.json'; path.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8')
        review(path)
        return path

    def test_nonempty_draft_cannot_be_registered(self):
        value=dict(self.blank,tracks=[{'segments':[{'x':1}]}]); self.main.write_text(json.dumps(value),encoding='utf-8')
        before=self.main.read_bytes()
        with self.assertRaisesRegex(ValueError,'empty'): self.init()
        self.assertEqual(self.main.read_bytes(),before); self.assertFalse((self.folder/bridge.MARKER).exists())

    def test_identity_and_concurrent_change_block_write(self):
        ready=self.init(); before=self.main.read_bytes()
        with self.assertRaisesRegex(ValueError,'another project'):
            bridge.install(self.folder,self.candidate(id='other'),ready['sha256'],self.folder.name,True,self.codec,plan={})
        self.assertEqual(self.main.read_bytes(),before)
        self.main.write_bytes(before+b' ')
        with self.assertRaisesRegex(ValueError,'changed'):
            bridge.install(self.folder,self.candidate(),ready['sha256'],self.folder.name,True,self.codec,plan={})

    def test_saved_roundtrip_and_original_unchanged(self):
        ready=self.init(); candidate=self.candidate(duration=1000000,tracks=[{'segments':[{'text':'完整原话'}]}])
        receipt=bridge.install(self.folder,candidate,ready['sha256'],self.folder.name,True,self.codec,plan={})
        self.assertFalse(receipt['ui_reopen_verified'])
        self.assertEqual(bridge.read(self.folder,self.codec)['duration'],1000000)
        self.assertEqual(self.main.read_bytes(),self.timeline.read_bytes())
        self.assertEqual(self.original.read_bytes(),b'leave original untouched')

    def test_codec_mismatch_never_writes(self):
        ready=self.init(); before={p:p.read_bytes() for p in [self.main,self.timeline]}
        with patch.object(self.codec,'encode',return_value=b'test:{}'):
            with self.assertRaisesRegex(ValueError,'differs'):
                bridge.install(self.folder,self.candidate(duration=1),ready['sha256'],self.folder.name,True,self.codec,plan={})
        self.assertTrue(all(p.read_bytes()==raw for p,raw in before.items()))

    def test_partial_write_rolls_back_both_files(self):
        ready=self.init(); before={p:p.read_bytes() for p in [self.main,self.timeline]}
        replace=bridge.os.replace
        def fail_second(src,dst):
            if dst==self.timeline: raise OSError('simulated locked timeline')
            return replace(src,dst)
        with patch.object(bridge.os,'replace',side_effect=fail_second):
            with self.assertRaises(OSError):
                bridge.install(self.folder,self.candidate(duration=1),ready['sha256'],self.folder.name,True,self.codec,plan={})
        self.assertTrue(all(p.read_bytes()==raw for p,raw in before.items()))

    def test_closed_and_registered_required(self):
        with self.assertRaises(ValueError): bridge.initialize(self.folder,self.folder.name,self.codec,False)
        with self.assertRaises(FileNotFoundError):
            bridge.install(self.folder,self.candidate(),bridge.digest(self.main),self.folder.name,True,self.codec,plan={})


if __name__=='__main__': unittest.main()

# Storage fixtures do not carry audio. Validate the real gate separately.
def setUpModule():
    from unittest.mock import patch
    global _signal_patches
    _signal_patches = [patch('draft_windows'+'.'+name,return_value={'fixture_only':True}) for name in ['require_breath_review','check_native_breaths','check_native_punchlines','check_output_record']]
    for p in _signal_patches:p.start()
def tearDownModule():
    for p in reversed(_signal_patches):p.stop()
