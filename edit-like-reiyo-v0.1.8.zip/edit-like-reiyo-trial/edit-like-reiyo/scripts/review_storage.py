"""External review identity and crash-visible, rollback-safe persistence.
Native JSON bytes protect concurrent writes only; frame-normalized speech binds later app saves.
"""
import hashlib,json,os,tempfile,uuid
from pathlib import Path
from breath_review import require_review,check_native,check_output_record


def digest(raw):return hashlib.sha256(raw).hexdigest()
def encode(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2).encode('utf-8')
def pending_path(record):return Path(str(record)+'.pending.json')


def identity(folder,targets,project_meta=None):
    folder=Path(folder).resolve()
    meta=Path(project_meta) if project_meta else folder.parent/'root_meta_info.json'
    if not meta.is_file():raise ValueError('Project metadata missing; supply the current root_meta_info.json with --project-meta')
    value=json.loads(meta.read_text(encoding='utf-8'))
    rows=value if isinstance(value,list) else value.get('all_draft_store',[value])
    matches=[x for x in rows if x.get('draft_fold_path') and Path(x['draft_fold_path']).resolve()==folder]
    if len(matches)!=1 or not matches[0].get('draft_id'):raise ValueError('Project metadata identity missing or ambiguous')
    relative=[]
    for path in targets:
        rel=Path(path).resolve().relative_to(folder)
        if rel.name not in ('draft_info.json','draft_content.json'):raise ValueError('Unexpected native target')
        relative.append(str(rel))
    return {'folder':str(folder),'project_id':matches[0]['draft_id'],'files':sorted(relative)}


def load_review(path):
    path=Path(path).resolve()
    if pending_path(path).exists():raise ValueError('Review save is incomplete; recover before verification or another write')
    if not path.is_file():raise ValueError('External review record missing')
    record=json.loads(path.read_text(encoding='utf-8'))
    if record.get('schema_version')!=2:raise ValueError('External review schema lacks project/content binding; regenerate with current package')
    return record


def verify_saved(folder,targets,decoded,plan,review_path,pending_preview=False,project_meta=None):
    record=load_review(review_path);target=identity(folder,targets,project_meta)
    installation=record.get('installation') or {}
    base={k:v for k,v in record.items()if k!='installation'}
    if (installation.get('status')!='committed' or installation.get('target')!=target
            or installation.get('record_sha256')!=digest(encode(base))):
        raise ValueError('External review is uncommitted or belongs to another project/timeline')
    result=require_review(plan,final=not pending_preview,pending_preview=pending_preview)
    if len(decoded)!=len(targets):raise ValueError('Every native copy must be read back')
    for draft in decoded:
        check_native(plan,draft);check_output_record(draft,result,pending_preview,external=record)
    return {'mode':record['mode'],'review_path':str(Path(review_path).resolve()),'project':target,
            'native_persistence_verified':True,'formal_breath_accepted':not pending_preview and result['formal_accepted'],
            'breath_review':result,'ui_reopen_verified':False}


def sync_directory(path):
    # POSIX needs the directory entry persisted as well as the file contents.
    if os.name=='nt':return
    fd=os.open(str(path),os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)


def atomic_write(path,raw):
    path=Path(path);fd,name=tempfile.mkstemp(prefix='.'+path.name+'.',dir=path.parent)
    temp=Path(name)
    try:
        with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
        os.replace(temp,path)
        sync_directory(path.parent)
    finally:temp.unlink(missing_ok=True)


def _restore(journal,record_path,targets):
    """Refuse to overwrite concurrent changes, including a changed external record."""
    info=json.loads(journal.read_text(encoding='utf-8'));folder=Path(info['target']['folder'])
    expected={str(Path(p).resolve().relative_to(folder))for p in targets}
    if expected!=set(info['target']['files']):raise ValueError('Recovery native targets differ')
    relatives=[entry['relative']for entry in info['native']]
    if len(relatives)!=len(expected) or set(relatives)!=expected:raise ValueError('Recovery native entries incomplete or duplicated')
    backup=Path(info['backup'])
    if backup.parent.resolve()!=record_path.parent.resolve() or not backup.name.startswith('reiyo-review-backup-'):
        raise ValueError('Invalid review backup location')
    restores=[]
    for i,entry in enumerate(info['native']):
        relative=entry['relative'];dest=(folder/relative).resolve()
        if relative not in expected or folder.resolve() not in dest.parents:raise ValueError('Invalid recovery path')
        raw=(backup/str(i)).read_bytes()
        if digest(raw)!=entry['before_sha256']:raise ValueError('Native backup changed')
        if not dest.is_file() or digest(dest.read_bytes())not in (entry['before_sha256'],entry['prepared_sha256']):
            raise ValueError('Concurrent native change; retain journal and backup for explicit recovery')
        restores.append((dest,raw))
    old=(backup/'external').read_bytes()
    if digest(old)!=info['record_before_sha256']:raise ValueError('External backup changed')
    if not record_path.is_file() or digest(record_path.read_bytes())not in (info['record_before_sha256'],info['record_after_sha256']):
        raise ValueError('Concurrent external record change; retain journal')
    for dest,raw in restores:
        if dest.read_bytes()!=raw:atomic_write(dest,raw)
    if record_path.read_bytes()!=old:atomic_write(record_path,old)
    journal.unlink()
    sync_directory(journal.parent)
    return {'recovered':True,'backup':str(backup),'formal_breath_accepted':False}


def recover(folder,targets,review_path,project_meta=None):
    record_path=Path(review_path).resolve();journal=pending_path(record_path)
    info=json.loads(journal.read_text(encoding='utf-8'))
    if info['target']!=identity(folder,targets,project_meta):raise ValueError('Recovery project differs')
    return _restore(journal,record_path,targets)


def save(before,prepared,review_path,record,target,validate):
    record_path=Path(review_path).resolve();journal=pending_path(record_path);folder=Path(target['folder']).resolve()
    if record_path==folder or folder in record_path.parents:raise ValueError('Keep the external review outside the app-managed draft folder')
    if journal.exists():raise ValueError('Review save is incomplete; recover first')
    expected={str(path.resolve().relative_to(folder))for path in before}
    if not before or set(prepared)!=set(before) or expected!=set(target['files']):
        raise ValueError('Every native target must be backed up and prepared')
    raw_record=record_path.read_bytes()
    if json.loads(raw_record)!=record:raise ValueError('External review changed before save')
    prior=record.get('installation')
    if prior and prior.get('target')!=target:raise ValueError('External review belongs to another project')
    if any(path.read_bytes()!=raw for path,raw in before.items()):raise ValueError('Native file changed before save')
    base={k:v for k,v in record.items()if k!='installation'}
    committed=dict(base,installation={'status':'committed','target':target,'revision':str(uuid.uuid4()),'record_sha256':digest(encode(base))})
    committed_raw=encode(committed)
    backup=Path(tempfile.mkdtemp(prefix='reiyo-review-backup-',dir=record_path.parent))
    entries=[]
    for i,(path,raw)in enumerate(before.items()):
        atomic_write(backup/str(i),raw)
        entries.append({'relative':str(path.resolve().relative_to(folder)),'before_sha256':digest(raw),'prepared_sha256':digest(prepared[path])})
    atomic_write(backup/'external',raw_record)
    sync_directory(backup.parent)
    info={'target':target,'backup':str(backup),'native':entries,'record_before_sha256':digest(raw_record),'record_after_sha256':digest(committed_raw)}
    # Exclusive creation is also the per-record writer lock. A crash leaves formal verification blocked.
    with journal.open('xb')as f:f.write(encode(info));f.flush();os.fsync(f.fileno())
    sync_directory(journal.parent)
    try:
        for path,raw in prepared.items():
            if path.read_bytes()!=before[path]:raise ValueError('Concurrent native change during save')
            atomic_write(path,raw)
        validate(record)
        if record_path.read_bytes()!=raw_record:raise ValueError('Concurrent external review change during save')
        atomic_write(record_path,committed_raw)
        if record_path.read_bytes()!=committed_raw:raise ValueError('External record readback differs')
        validate(committed)
        journal.unlink()
        sync_directory(journal.parent)
    except BaseException:
        _restore(journal,record_path,list(before))
        raise
    return {'backup':str(backup),'record':committed,'review_path':str(record_path)}
