"""Apply source-anchored editorial choices, not keyword-triggered effects.
Usage: compose_beats.py base-plan.json beats.json output.json
The model authors beats after reading/viewing THIS source. Recipes are reusable.
"""
import argparse,copy,json,pathlib,subprocess,unicodedata
from punchline_events import prepare_event, check_plan, protected_takes
from media_settings import plan_fps
HERE=pathlib.Path(__file__).resolve().parent

def compose(plan,beats,outdir):
 p=copy.deepcopy(plan);fps=plan_fps(p);outdir=pathlib.Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
 p.setdefault('titles',[]);p.setdefault('overlays',[]);p.setdefault('sounds',[])
 p.setdefault('caption_style',{'y':-.31,'size':7})
 original_captions=p.get('captions',[])
 promoted=set();promotion_log=[]
 def words(text):
  return ''.join(c for c in text if not c.isspace() and not unicodedata.category(c).startswith('P'))
 mapping=[];cursor=0
 for t in p['takes']:
  a=round(t['start']*fps)/fps;b=round(t['end']*fps)/fps
  mapping.append((t['source'],a,b,cursor));cursor+=b-a
 def at(source,time):
  hits=[(a,b,c)for s,a,b,c in mapping if s==source and a-.5/fps<=time<=b+.5/fps]
  if len(hits)>1 and abs(hits[0][1]-hits[1][0])>1/fps:raise ValueError('Ambiguous repeated source; select an occurrence explicitly')
  if hits:
   a,b,c=hits[0];return round((c+max(0,min(b-a,time-a)))*fps)/fps
  raise ValueError(f'Anchor {source}:{time} is outside retained speech; inspect instead of snapping silently')
 def span(b):return at(b['source'],b['start']),at(b['source'],b['end'])
 def title(text,start,end,**kw):
  if end<=start:raise ValueError('Title must have positive duration')
  lane=0
  while any(c.get('lane',0)==lane and c['start']<end and c['end']>start for c in p['titles']):lane+=1
  p['titles'].append(dict(text=text,start=start,end=end,lane=lane,**kw))
 def promote(indices,expected,style,window=None):
  # Indices always refer to the input plan; defer removal until all beats finish.
  if not indices or any(type(i)is not int or i<0 or i>=len(original_captions)for i in indices):
   raise ValueError('Promotion needs valid input caption_indices')
  if len(set(indices))!=len(indices) or promoted.intersection(indices):
   raise ValueError('A caption cannot be promoted twice')
  cs=[original_captions[i]for i in indices]
  if indices!=sorted(indices) or any(c['end']<=c['start']for c in cs):
   raise ValueError('Promotion captions must have ordered positive spans')
  if words(''.join(c['text']for c in cs))!=words(expected):
   raise ValueError('Promotion text differs from selected captions; preserve speech or use an additional title')
  a,z=cs[0]['start'],cs[-1]['end']
  if any(c['start']<a or c['end']>z for c in cs):
   raise ValueError('Promote before cumulative caption layout')
  if any(right['start']-left['end']>1/fps+.000001 for left,right in zip(cs,cs[1:])):
   raise ValueError('Promotion crosses a speech gap; use separate beats')
  if any(i not in indices and c['start']<z and c['end']>a for i,c in enumerate(original_captions)):
   raise ValueError('Promotion overlaps other captions; use aligned ungrouped captions')
  if window and (abs(a-window[0])>1/fps+.000001 or z>window[1]+1/fps+.000001):
   raise ValueError('Parallel scene and promoted phrase are not aligned; inspect word timing')
  allowed={'size','x','y','color','background','shadow','pop','keys'}
  if set(style)-allowed:raise ValueError('Unknown promotion style fields: '+str(set(style)-allowed))
  props={k:v for k,v in p['caption_style'].items()if k in allowed}
  props.update({k:v for k,v in cs[0].items()if k in allowed});props.update(style)
  # Emphasis uses the approved text palette/position unless explicitly changed.
  title(expected,a,z,**props)
  promoted.update(indices)
  promotion_log.append(dict(caption_indices=indices,text=expected,start=a,end=z))
 def scene(source,start,end,scale=1.,x=0.,y=0.):
  result=[]
  for t in p['takes']:
   if t['source']!=source or t['end']<=start or t['start']>=end:result.append(t);continue
   # A scene boundary can fall in a retained phrase; preserve every original frame.
   edges=sorted(set([t['start'],t['end'],max(t['start'],start),min(t['end'],end)]))
   if t.get('keys'):raise ValueError('Apply beat scenes before adding other motion keys')
   for a,b in zip(edges,edges[1:]):
    if round(b*fps)<=round(a*fps):continue
    n=copy.deepcopy(t);n.update(start=a,end=b)
    if start<=a<end:n.update(scale=scale,x=x,y=y)
    result.append(n)
  p['takes']=result
 def shape(name,w,h,shapes,start,end,scale=1,x=0,y=0,layer=10,keys=None):
  src='diagram-'+str(len(p['overlays']))+'-'+name;spec=outdir/(src+'.json');img=outdir/(src+'.png')
  spec.write_text(json.dumps(dict(width=w,height=h,shapes=shapes)), encoding='utf-8')
  subprocess.run(['swift',str(HERE/'draw_shapes.swift'),str(spec),str(img)],check=True,capture_output=True)
  p['sources'][src]=dict(path=str(img.resolve()),type='photo',width=w,height=h,duration=end-start+2)
  p['overlays'].append(dict(source=src,start=start,end=end,source_start=0,scale=scale,x=x,y=y,layer=layer,lane=src,keys=keys or {}))
 for b in beats:
  assert b.get('reason'),'Every treatment needs a purpose'
  kind=b['type'];source=b.get('source')
  if kind=='scene':scene(source,b['start'],b['end'],b.get('scale',1),b.get('x',0),b.get('y',0))
  elif kind=='punchline':
   event=prepare_event(plan,b,at,fps)
   p.setdefault('punchline_protected_takes',protected_takes(plan,fps))
   g=event['shrink']
   scene(source,b['shrink_at'],b['restore_at'],g['scale'],g['x'],g['y'])
   p.setdefault('punchline_events',[]).append(event)
   p['sounds'].append(copy.deepcopy(event['sound']))
  elif kind=='parallel':
   items=b['items'];end=b['end']
   for i,item in enumerate(items):
    stop=items[i+1]['at']if i+1<len(items)else end
    scene(source,item['at'],stop,item.get('scale',1+i*.12),item.get('x',0),item.get('y',0))
    a,z=at(source,item['at']),at(source,stop)
    if 'caption_indices'in item:
     style=dict(b.get('style',{}));style.update(item.get('style',{}))
     promote(item['caption_indices'],item['text'],style,(a,z))
    else:
     title(item['text'],a,z,size=b.get('size',20),y=b.get('y',.62),x=item.get('text_x',0),color=item.get('color','#FFE15D'))
  elif kind=='promote':
   promote(b['caption_indices'],b['text'],b.get('style',{}))
  elif kind=='title':
   a,z=span(b);props={k:v for k,v in b.items()if k not in ['type','source','start','end','reason']};tx=props.pop('text');title(tx,a,z,**props)
  elif kind=='sound':
   a=at(source,b['at']);p['sounds'].append(dict(path=b['path'],start=a,volume=b.get('volume',1),source_start=b.get('source_start',0),**({'duration':b['duration']}if'duration'in b else{}),reason=b['reason']))
   if 'selection' in b:p['sounds'][-1]['selection']=copy.deepcopy(b['selection'])
  elif kind=='matrix':
   a,z=span(b);cols=b['columns'];rows=b['rows'];navy=[.14,.20,.35,1];cream=[.985,.985,.98,1];yellow=[1,.87,.35,1]
   W,H=p['canvas']['width'],p['canvas']['height']
   shape('paper',W,H,[dict(type='rect',x=.04,y=.23,w=.92,h=.64,color=cream,radius=36)],a,z,layer=10,keys={'KFTypeAlpha':[[0,0],[.15,1]]})
   title(b.get('title','看见这层关系'),a,z,size=15,y=.65,color='#24345A',shadow=False)
   left,right,bottom,top=.23,.88,.39,.72
   # Lines actually draw on over time; photo transform moves their anchor to keep one end fixed.
   def line_anim(name,x1,y1,x2,y2,tm):
    horizontal=abs(y1-y2)<.001
    points=[dict(type='line',x=x1,y=y1,x2=x2,y2=y2,color=navy,stroke=4)]
    k={'KFTypeScaleX' if horizontal else 'KFTypeScaleY':[[0,.001],[.28,1]]}
    # Full-canvas transparent PNG scales about canvas center; translate to fix its line origin.
    prop='KFTypePositionX'if horizontal else'KFTypePositionY';origin=x1 if horizontal else y1
    k[prop]=[[0,(origin-.5)*2],[.28,0]]
    shape(name,W,H,points,tm,z,layer=14,keys=k)
   line_anim('horizontal',left,bottom,right,bottom,a+.15)
   row_begin=at(source,b.get('rows_at',rows[0]['at']))
   line_anim('vertical',left,bottom,left,top,row_begin)
   for i,c in enumerate(cols):
    tm=at(source,c['at']);x=left+(right-left)*(i+.5)/len(cols)
    title(c['text'],tm,z,size=10,x=x*2-1,y=bottom*2-1-.06,color='#24345A',shadow=False)
    if i:
     shape('col',W,H,[dict(type='line',x=left+(right-left)*i/len(cols),y=bottom,x2=left+(right-left)*i/len(cols),y2=top,color=[.14,.20,.35,.18],stroke=2)],row_begin,z,layer=14)
   for i,r in enumerate(rows):
    tm=at(source,r['at']);y=top-(top-bottom)*(i+.5)/len(rows);nexttime=at(source,rows[i+1]['at'])if i+1<len(rows)else z
    title(r['text'],tm,z,size=10,x=-.72,y=y*2-1,color='#24345A',shadow=False)
    shape('row-highlight',W,H,[dict(type='rect',x=left+.01,y=y-(top-bottom)/len(rows)*.4,w=right-left-.01,h=(top-bottom)/len(rows)*.8,color=yellow,radius=10)],tm,nexttime,layer=12,keys={'KFTypeAlpha':[[0,0],[.12,1]]})
   for c in p.get('captions',[]):
    if c['start']<z and c['end']>a:c['y']=-.43;c['size']=6.5
  else:raise ValueError('Unknown beat type '+kind)
 p['captions']=[c for i,c in enumerate(original_captions)if i not in promoted]
 p['caption_promotions']=promotion_log
 p['editorial_beats']=beats
 check_plan(p,fps)
 return p
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('plan',type=pathlib.Path);ap.add_argument('beats',type=pathlib.Path);ap.add_argument('output',type=pathlib.Path);args=ap.parse_args()
 p=compose(json.loads(args.plan.read_text(encoding='utf-8')),json.loads(args.beats.read_text(encoding='utf-8')),args.output.parent/'diagram-assets');args.output.write_text(json.dumps(p,ensure_ascii=False,indent=2), encoding='utf-8');print('beats',len(p['editorial_beats']),'takes',len(p['takes']))
