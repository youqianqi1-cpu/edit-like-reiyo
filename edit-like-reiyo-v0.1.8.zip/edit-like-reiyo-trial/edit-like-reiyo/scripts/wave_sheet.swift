import AppKit
import Foundation
let args=CommandLine.arguments
let rows=try JSONSerialization.jsonObject(with:Data(contentsOf:URL(fileURLWithPath:args[1]))) as! [[String:Any]]
let w=1200,h=140
let image=NSImage(size:NSSize(width:w,height:rows.count*h));image.lockFocus();NSColor.white.setFill();NSRect(x:0,y:0,width:w,height:rows.count*h).fill()
for (i,row) in rows.enumerated(){
 let bottom=(rows.count-1-i)*h
 (row["label"] as! NSString).draw(at:NSPoint(x:10,y:bottom+115),withAttributes:[.font:NSFont.systemFont(ofSize:16),.foregroundColor:NSColor.black])
 for (j,side) in ["head","tail"].enumerated(){
  let r=row[side] as! [String:Any],v=r["values"] as! [Double],a=r["a"] as! Double,b=r["b"] as! Double,cut=r["cut"] as! Double
  let x0=Double(j*600+15),y=Double(bottom+53),sx=570.0/Double(v.count),mx=max(v.max() ?? 0.1,0.003)
  let p=NSBezierPath();p.lineWidth=1;NSColor(calibratedRed:0.12,green:0.25,blue:0.5,alpha:1).setStroke()
  for (k,n) in v.enumerated(){let x=x0+Double(k)*sx,amp=n/mx*46;p.move(to:NSPoint(x:x,y:y-amp));p.line(to:NSPoint(x:x,y:y+amp))};p.stroke()
  NSColor.red.setStroke();let c=NSBezierPath();let cx=x0+(cut-a)/(b-a)*570;c.move(to:NSPoint(x:cx,y:y-50));c.line(to:NSPoint(x:cx,y:y+50));c.lineWidth=2;c.stroke()
  (String(format:"%@ %.3f → %.3f | proposed %.3f",side,a,b,cut) as NSString).draw(at:NSPoint(x:x0,y:Double(bottom+2)),withAttributes:[.font:NSFont.systemFont(ofSize:12),.foregroundColor:NSColor.black])
 }
}
image.unlockFocus();let rep=NSBitmapImageRep(data:image.tiffRepresentation!)!;try rep.representation(using:.png,properties:[:])!.write(to:URL(fileURLWithPath:args[2]))
