import array, copy, json, unittest
from pathlib import Path
from test_final_breaths import FinalSignalTests, fixture_decisions
from audit_breaths import audit
from breath_review import evaluate, require_review, check_native, pending_decisions
from apply_cuts import apply
from assemble import build

class ClosureTests(unittest.TestCase):
 setUp=FinalSignalTests.setUp
 bind=FinalSignalTests.bind
 # Reuse source/PCM setup, not inherited test methods (removed below).
 def test_partial_weak_word_cannot_close_rest_of_wait(self):
  r,d=self.bind();part=d['items'][0]['segments'][0];part['end']-=.1
  self.assertTrue(evaluate(r,d)['pending'])
 def test_unrelated_evidence_and_removed_source_range_rejected(self):
  r,d=self.bind()
  for field,value in [('source','other'),('pcm_sha256','wrong'),('scan_signature','old'),('start',2.5)]:
   bad=copy.deepcopy(d);bad['items'][0]['segments'][0]['evidence'][field]=value
   self.assertFalse(evaluate(r,bad)['formal_accepted']);self.assertTrue(evaluate(r,bad)['pending'])
  bad=copy.deepcopy(d);bad['items'][0]['segments'][0].pop('start');self.assertTrue(evaluate(r,bad)['pending'])
 def test_each_join_side_required_even_unflagged(self):
  self.pcm.write_bytes(array.array('h',[3000]*48000).tobytes());r,d=self.bind()
  self.assertEqual(r['joins'][0]['decision'],'not_flagged')
  for side in ['left','right']:
   bad=copy.deepcopy(d);bad['join_reviews'][0][side]=[]
   self.assertIn('join-0-1:'+side,evaluate(r,bad)['pending'])
  bad=copy.deepcopy(d);bad['join_reviews']=[]
  with self.assertRaisesRegex(ValueError,'Every join'):evaluate(r,bad)
 def test_short_peak_does_not_hide_new_head_residual(self):
  samples=[3000]*48000
  # New head: 130ms low / 10ms peak / 240ms low. Both must be reviewed.
  samples[32000:34080]=[100]*2080;samples[34240:38080]=[100]*3840
  self.pcm.write_bytes(array.array('h',samples).tobytes());r,d=self.bind()
  ctx=r['joins'][0]['right_context'];low=[x for x in ctx['regions'] if x['kind']=='low_energy']
  self.assertEqual(len(low),2);self.assertAlmostEqual(low[1]['end']-low[1]['start'],.24)
  d['join_reviews'][0]['right']=[x for x in d['join_reviews'][0]['right'] if x['start']!=low[1]['start']]
  self.assertIn('join-0-1:right',evaluate(r,d)['pending'])
 def test_keep_weak_phoneme_and_expressive_pause_with_bound_evidence(self):
  r,d=self.bind()
  for kind in ['weak_speech','expressive_pause']:
   d['items'][0]['segments'][0]['disposition']=kind
   self.assertEqual(evaluate(r,d)['pending'],[])
  for kind in ['uncertain','tighten_wait','voiced_context']:
   d['items'][0]['segments'][0]['disposition']=kind
   self.assertTrue(evaluate(r,d)['pending'])
 def test_pending_listening_allows_work_draft_not_formal_acceptance(self):
  r,d=self.bind();result=require_review(self.plan)
  self.assertEqual(result['listening_status'],'pending');self.assertFalse(result['formal_accepted'])
  build({'id':'unit'},self.plan,settings={'fps':24},pending_preview=True)
  with self.assertRaisesRegex(ValueError,'Formal breath acceptance pending'):require_review(self.plan,final=True)
  d['actual_listening']=True;self.assertFalse(evaluate(r,d)['formal_accepted'])
  d['listening']={'scope':'main_speech','scan_signature':r['scan_signature'],'cut_signature':r['cut_signature'],
                  'speed':1,'complete':True,'reviewer':'synthetic test','note':'Only a fixture, not actual listening','result':'passed'}
  Path(self.plan['breath_review']['decisions']).write_text(json.dumps(d))
  self.assertTrue(require_review(self.plan,final=True)['formal_accepted'])
  d['listening']['speed']=1.5;self.assertFalse(evaluate(r,d)['formal_accepted'])
  d['listening']['speed']=1;d['listening']['scan_signature']='old';self.assertFalse(evaluate(r,d)['formal_accepted'])
 def test_actual_edit_invalidates_and_rescans_into_unresolved_queue(self):
  r,d=self.bind();old=copy.deepcopy(self.plan)
  q,m=apply(self.plan,[{'source':'main','start':1.25,'end':1.5}],self.root/'new-review')
  self.assertEqual(old,self.plan);self.assertTrue(q['breath_review_state']['old_review_invalidated'])
  self.assertNotEqual(q['breath_review'],self.plan['breath_review'])
  self.assertEqual(q['breath_review_state']['status'],'review_pending')
  fresh=m['post_edit_scan'];ds=m['post_edit_decisions']
  self.assertFalse(evaluate(fresh,ds)['formal_accepted'])
  self.assertTrue(all(x['action']=='unresolved' for x in ds['items']))
  self.assertEqual(fresh['joins'][0]['left_context']['end'],1.25)
  with self.assertRaises(ValueError):evaluate(fresh,d)
  with self.assertRaisesRegex(ValueError,'unresolved'):require_review(q)
 def test_rescan_failure_keeps_edited_plan_never_restores_pass(self):
  self.bind();self.pcm.unlink()
  q,m=apply(self.plan,[{'source':'main','start':1.25,'end':1.5}],self.root/'new-review')
  self.assertEqual(q['takes'][0]['end'],1.25);self.assertNotIn('breath_review',q)
  self.assertEqual(q['breath_review_state']['status'],'rescan_failed')
  self.assertFalse(q['breath_review_state']['formal_accepted'])
 def test_four_synthetic_case_patterns_remain_decisions_not_auto_cuts(self):
  scenarios=[
   ([(.66,1.0)],[],[{'text':'天','start':.6,'duration':.1}],1),
   ([(.2,.67),(.68,1.5)],[],[{'text':'还','start':.2,'duration':1.3}],2),
   ([(.41,1.0)],[],[{'text':'。','start':.41,'duration':.59}],1),
   ([(.86,1.0)],[(2,2.13),(2.14,2.38)],[],3),
  ]
  for left,right,words,count in scenarios:
   samples=[3000]*48000
   for a,b in left+right:samples[round(a*16000):round(b*16000)]=[100]*round((b-a)*16000)
   self.pcm.write_bytes(array.array('h',samples).tobytes())
   (self.folder/'words.jsonl').write_text('\n'.join(json.dumps(w)for w in words))
   p=copy.deepcopy(self.plan);p['takes'][0]['end']=1.5 if count==2 else 1
   original=copy.deepcopy(p);r=audit(p,self.root)
   self.assertEqual(sum(len(t['quiet_candidates'])for t in r['takes']),count)
   self.assertEqual(original,p);self.assertFalse(evaluate(r,pending_decisions(r))['formal_accepted'])
   self.assertTrue(all(h['text']!='。' for t in r['takes'] for c in t['quiet_candidates'] for h in c['word_hints']))
 def test_one_broad_reason_cannot_cover_peak_and_residual(self):
  samples=[3000]*48000;samples[32000:34080]=[100]*2080;samples[34240:38080]=[100]*3840
  self.pcm.write_bytes(array.array('h',samples).tobytes());r,d=self.bind()
  parts=d['join_reviews'][0]['right'];part=copy.deepcopy(parts[0])
  part['end']=parts[-1]['end'];part['evidence']['end']=part['end']
  d['join_reviews'][0]['right']=[part]
  self.assertIn('join-0-1:right',evaluate(r,d)['pending'])
 def test_noop_preserves_review(self):
  self.bind();q,m=apply(self.plan,[])
  self.assertEqual(q['breath_review'],self.plan['breath_review']);self.assertNotIn('post_edit_scan',m)
 def test_native_omitted_zero_start_is_valid_but_missing_duration_is_not(self):
  self.bind();d,_=build({'id':'unit'},self.plan,settings={'fps':24},pending_preview=True)
  first=d['tracks'][0]['segments'][0]
  del first['target_timerange']['start'];del first['source_timerange']['start']
  self.assertTrue(check_native(self.plan,d)['source_cuts_match'])
  del first['source_timerange']['duration']
  with self.assertRaises((KeyError,ValueError)):check_native(self.plan,d)

del FinalSignalTests
if __name__=='__main__':unittest.main()
