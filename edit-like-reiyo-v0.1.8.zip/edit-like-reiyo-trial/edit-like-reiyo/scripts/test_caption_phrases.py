import copy
import unittest
from align_captions import align, timing_review
from caption_phrases import boundaries, check, key, require_resolved
from assemble import build


class PhraseTests(unittest.TestCase):
    def test_user_example_and_other_semantic_patterns(self):
        samples = [('这个视频里的这个瑜伽老师了','这个视频里的','这个瑜伽老师了'),
                   ('我收藏中的那位摄影师','我收藏中的','那位摄影师'),
                   ('在这个网站里你可以找素材','在这个网站里','你可以找素材'),
                   ('我已经准备好了但是他还没有来','我已经准备好了','但是他还没有来')]
        for text,left,right in samples:
            self.assertTrue(any(b['left']==left and b['right']==right for b in boundaries(text)),text)

    def test_whole_noun_phrase_and_short_particles_not_mechanically_split(self):
        for text in ('非常喜欢运动的瑜伽老师','这个视频里的','这个瑜伽老师了','我就能','中华人民共和国国家图书馆'):
            self.assertEqual(boundaries(text),[],text)

    def test_splits_use_unequal_word_times_and_replace(self):
        words=[{'text':'这个','start':0,'duration':.2}, {'text':'视频里的','start':.2,'duration':.8},
               {'text':'这个','start':1.1,'duration':.2}, {'text':'瑜伽老师了','start':1.3,'duration':1.3}]
        before=copy.deepcopy(words)
        cs,changes=align(words,'这个视频里的|这个瑜伽老师了')
        self.assertEqual(words,before);self.assertEqual(changes,[])
        self.assertEqual([c['text']for c in cs],['这个视频里的','这个瑜伽老师了'])
        self.assertEqual([c['start']for c in cs],[0,1.1])
        self.assertLessEqual(cs[0]['end'],cs[1]['start'])
        self.assertEqual(cs[1]['end'],2.6)
        self.assertFalse(timing_review(words,cs)['actual_listening'])

    def test_interpolation_is_exposed_not_claimed_as_hearing(self):
        words=[{'text':'这个视频里的这个瑜伽老师了','start':2,'duration':3}]
        cs,_=align(words,'这个视频里的|这个瑜伽老师了')
        self.assertTrue(timing_review(words,cs)['interpolated_token_boundaries'])

    def test_full_list_including_late_phrases_and_promoted_text(self):
        p={'captions':[{'text':'先开始吧','start':0,'end':1},
                       {'text':'这个视频里的这个瑜伽老师了','start':80,'end':83}],
           'caption_promotions':[{'text':'我已经准备好了但是他还没有来','start':120,'end':124}]}
        r=check(p)
        self.assertEqual(r['scanned_caption_count'],2)
        self.assertEqual(len(r['pending']),2)
        with self.assertRaises(ValueError): require_resolved(r)

    def test_keep_decision_is_tied_to_text_and_time(self):
        cap={'text':'我说的这个地方','start':1,'end':3}
        p={'captions':[cap],'caption_review':{'keep_whole':{key(cap):'本句整体是对已指定地点的指称，保留用户手改短语'}}}
        before=copy.deepcopy(p)
        require_resolved(check(p));self.assertEqual(p,before)
        cap['text']='我提到的那个地方'
        with self.assertRaises(ValueError): require_resolved(check(p))

    def test_assembly_rejects_missed_phrase_before_source_read(self):
        p={'fps':24,'takes':[{'source':'v','start':0,'end':3}],
           'captions':[{'text':'这个视频里的这个瑜伽老师了','start':0,'end':3}]}
        with self.assertRaisesRegex(ValueError,'short-phrase boundaries'):
            build({'id':'fixture'},p,settings={'fps':24})




# These fixtures have dummy video files; real final-signal gate tests live in test_final_breaths.
def setUpModule():
    from unittest.mock import patch
    global _signal_patch
    _signal_patch = patch('assemble.require_breath_review', return_value={'fixture_only': True})
    _signal_patch.start()
def tearDownModule():
    _signal_patch.stop()

if __name__ == '__main__': unittest.main()
