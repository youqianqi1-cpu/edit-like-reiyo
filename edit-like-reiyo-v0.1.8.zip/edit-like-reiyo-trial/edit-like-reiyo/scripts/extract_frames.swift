import Foundation
import AVFoundation
import AppKit

guard CommandLine.arguments.count >= 4 else {
    fputs("usage: swift extract-frames.swift video output-directory seconds...\n", stderr)
    exit(2)
}
let movieURL = URL(fileURLWithPath: CommandLine.arguments[1])
let outputURL = URL(fileURLWithPath: CommandLine.arguments[2], isDirectory: true)
let asset = AVURLAsset(url: movieURL)
let generator = AVAssetImageGenerator(asset: asset)
generator.appliesPreferredTrackTransform = true
generator.requestedTimeToleranceBefore = .zero
generator.requestedTimeToleranceAfter = .zero
try FileManager.default.createDirectory(at: outputURL, withIntermediateDirectories: true)
for (index, item) in CommandLine.arguments.dropFirst(3).enumerated() {
    guard let seconds = Double(item) else { continue }
    let time = CMTime(seconds: seconds, preferredTimescale: 600)
    let image = try generator.copyCGImage(at: time, actualTime: nil)
    let bitmap = NSBitmapImageRep(cgImage: image)
    guard let data = bitmap.representation(using: .jpeg, properties: [.compressionFactor: 0.78]) else { continue }
    let name = String(format: "frame_%02d_%.1f.jpg", index, seconds)
    try data.write(to: outputURL.appendingPathComponent(name))
    print(name)
}
