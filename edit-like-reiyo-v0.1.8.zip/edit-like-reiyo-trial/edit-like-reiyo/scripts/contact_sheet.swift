import AppKit
import Foundation
let args=CommandLine.arguments
precondition(args.count>2)
let paths=Array(args.dropFirst(2)),cols=5,w=250,h=330,rows=(paths.count+4)/5
let image=NSImage(size:NSSize(width:cols*w,height:rows*h));image.lockFocus()
NSColor.white.setFill();NSRect(x:0,y:0,width:cols*w,height:rows*h).fill()
for (i,p) in paths.enumerated(){
 guard let frame=NSImage(contentsOfFile:p) else{continue}
 let rect=NSRect(x:(i%cols)*w,y:(rows-1-i/cols)*h+24,width:w,height:h-24)
 let q=min(rect.width/frame.size.width,rect.height/frame.size.height)
 frame.draw(in:NSRect(x:rect.midX-frame.size.width*q/2,y:rect.midY-frame.size.height*q/2,width:frame.size.width*q,height:frame.size.height*q))
 (URL(fileURLWithPath:p).lastPathComponent as NSString).draw(at:NSPoint(x:rect.minX+4,y:rect.minY-20),withAttributes:[.font:NSFont.systemFont(ofSize:11),.foregroundColor:NSColor.black])
}
image.unlockFocus();let rep=NSBitmapImageRep(data:image.tiffRepresentation!)!;try rep.representation(using:.png,properties:[:])!.write(to:URL(fileURLWithPath:args[1]))
