#include <dlfcn.h>

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <memory>
#include <string>

struct FakeFactory : std::enable_shared_from_this<FakeFactory> {
  virtual ~FakeFactory() {}
  unsigned char pad[4096];
};

struct RawResult {
  unsigned char bytes[40];
};

template <class T>
T symbol(const char* name) {
  void* value = dlsym(RTLD_DEFAULT, name);
  if (!value) {
    std::cerr << dlerror() << "\n";
    std::exit(2);
  }
  return reinterpret_cast<T>(value);
}

int main(int argc, char** argv) {
  if (argc != 3) {
    std::cerr << "usage: jycat DRAFT_INFO_JSON DRAFT_FOLDER\n";
    return 64;
  }

  using VoidMethod = void (*)(void*);
  using StringMethod = void (*)(void*, const std::string&);
  using ReadRawMethod =
      RawResult (*)(void*, const std::string&, std::string&, int*);

  auto factory_ctor =
      symbol<VoidMethod>("_ZN11draft_store18DraftIOFactoryBaseC1Ev");
  auto factory_dtor =
      symbol<VoidMethod>("_ZN11draft_store18DraftIOFactoryBaseD1Ev");
  auto as_global =
      symbol<VoidMethod>("_ZN11draft_store18DraftIOFactoryBase8asGlobalEv");

  void* factory_memory = nullptr;
  if (posix_memalign(&factory_memory, 64, sizeof(FakeFactory)))
    return 1;
  std::memset(factory_memory, 0, sizeof(FakeFactory));
  factory_ctor(factory_memory);
  auto* factory = reinterpret_cast<FakeFactory*>(factory_memory);
  std::shared_ptr<FakeFactory> owner(
      factory, [factory_dtor](FakeFactory* pointer) {
        factory_dtor(pointer);
        std::free(pointer);
      });
  as_global(factory_memory);

  auto store_ctor = symbol<VoidMethod>("_ZN11draft_store10DraftStoreC1Ev");
  auto store_dtor = symbol<VoidMethod>("_ZN11draft_store10DraftStoreD1Ev");
  auto set_folder = symbol<StringMethod>(
      "_ZN11draft_store10DraftStore16setDraftFoldPathERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE");
  auto set_open_folder = symbol<StringMethod>(
      "_ZN11draft_store10DraftStore20setOpenDraftFoldPathERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE");
  auto read_raw = symbol<ReadRawMethod>(
      "_ZN11draft_store10DraftStore16readRawDraftFileERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERS7_PNS_15DraftCipherTypeE");

  void* store = nullptr;
  if (posix_memalign(&store, 64, 0x800000))
    return 1;
  std::memset(store, 0, 0x800000);
  store_ctor(store);

  const std::string folder = argv[2];
  set_folder(store, folder);
  set_open_folder(store, folder);

  const std::string path = argv[1];
  std::string output;
  int cipher_type = -1;
  RawResult result = read_raw(store, path, output, &cipher_type);
  (void)result;
  std::cout.write(output.data(), output.size());
  std::cout.flush();

  store_dtor(store);
  std::free(store);
  return output.empty() ? 1 : 0;
}
