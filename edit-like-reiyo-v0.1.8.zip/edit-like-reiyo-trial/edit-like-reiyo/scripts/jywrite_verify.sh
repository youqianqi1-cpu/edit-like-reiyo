#!/bin/zsh
set -euo pipefail

[[ $# == 2 ]] || {
  echo "usage: $0 INPUT_JSON SOURCE_DRAFT" >&2
  exit 64
}

input=$1
source_draft=$2
script_dir=$(cd -- "$(dirname -- "$0")" && pwd)
frameworks=/Applications/VideoFusion-macOS.app/Contents/Frameworks
lab=$(mktemp -d /tmp/jy-writer.XXXXXX)

[[ -f "$input" && -f "$source_draft/draft_info.json" ]] || {
  echo "STOP: input is missing" >&2
  exit 1
}

source_before=$(shasum -a 256 "$source_draft/draft_info.json" | awk '{print $1}')
cp -a "$source_draft" "$lab/draft"
source_after_copy=$(shasum -a 256 "$source_draft/draft_info.json" | awk '{print $1}')
copy_before=$(shasum -a 256 "$lab/draft/draft_info.json" | awk '{print $1}')
[[ "$source_before" == "$source_after_copy" &&
   "$source_before" == "$copy_before" ]] || {
  echo "STOP: source changed or copy hash differs" >&2
  exit 2
}

input_hash=$(shasum -a 256 "$input" | awk '{print $1}')
"$script_dir/jywrite" "$input" "$lab/draft"
encrypted_hash=$(shasum -a 256 "$lab/draft/draft_info.json" | awk '{print $1}')
[[ "$encrypted_hash" != "$input_hash" ]] || {
  echo "STOP: output is plaintext" >&2
  exit 3
}

DYLD_FRAMEWORK_PATH="$frameworks" "$script_dir/jycat" \
  "$lab/draft/draft_info.json" "$lab/draft" |
  sed -n '/^{/,$p' > "$lab/readback.json"
python3 -m json.tool "$lab/readback.json" >/dev/null
readback_hash=$(shasum -a 256 "$lab/readback.json" | awk '{print $1}')
[[ "$input_hash" == "$readback_hash" ]] || {
  echo "STOP: readback hash differs" >&2
  exit 4
}
cmp -s "$input" "$lab/readback.json" || {
  echo "STOP: readback bytes differ" >&2
  exit 5
}

source_final=$(shasum -a 256 "$source_draft/draft_info.json" | awk '{print $1}')
[[ "$source_before" == "$source_final" ]] || {
  echo "STOP: source hash changed" >&2
  exit 6
}

printf 'LAB=%s\nINPUT_SHA256=%s\nENCRYPTED_SHA256=%s\nREADBACK_SHA256=%s\nSOURCE_SHA256=%s\nROUNDTRIP_OK=true\n' \
  "$lab" "$input_hash" "$encrypted_hash" "$readback_hash" "$source_final"
