"""Locate exact transcript excerpts. Result is a proposal; inspect waveform edges."""
import json,re

def clean(t):return re.sub(r'[\s，。？！、,.!?：；“”「」]','',t)
def select(words,text,after=0):
 stream='';positions=[]
 for i,w in enumerate(words):
  if w['start']<after:continue
  c=clean(w['text']);stream+=c;positions.extend([i]*len(c))
 needle=clean(text);at=stream.find(needle)
 if at<0:raise ValueError(f'Cannot find after {after}: {text}')
 lo,hi=positions[at],positions[at+len(needle)-1];return {'start':words[lo]['start'],'end':words[hi]['start']+words[hi]['duration'],'text':text,'first_word':lo,'last_word':hi}
