import copy
import unittest
from breath_plan import select_phrases, set_edges


class BreathPlanTests(unittest.TestCase):
    def plan(self):
        source = {"path": "input.mov", "duration": 10, "width": 1080, "height": 1920}
        words = [{"text": "你好", "start": t, "duration": .5} for t in (1, 5)]
        p = select_phrases(source, words, [{"text": "你好", "after": 4, "reason": "完整重说"}])
        p["fps"] = 25
        return p

    def test_selection_and_reviewed_edges_preserve_inputs(self):
        p = self.plan()
        self.assertEqual(p["takes"][0]["start"], 5)
        p["breath_review"] = {"report": "old-review"}
        original = copy.deepcopy(p)
        out = set_edges(p, [{"source": "main", "start": 5.01, "end": 5.53, "reason": "波形字音"}])
        self.assertEqual(p, original)
        self.assertEqual((out["takes"][0]["start"], out["takes"][0]["end"]), (5, 5.56))
        self.assertNotIn("breath_review", out)
        self.assertEqual(out["breath_review_state"]["status"], "rescan_required")

    def test_invalid_ranges_or_sources_do_not_change_plan(self):
        p = self.plan()
        for edge in [
            {"source": "other", "start": 5, "end": 6, "reason": "观察"},
            {"source": "main", "start": -1, "end": 6, "reason": "观察"},
            {"source": "main", "start": 5, "end": 11, "reason": "观察"},
            {"source": "main", "start": float("nan"), "end": 6, "reason": "观察"},
        ]:
            with self.assertRaises(ValueError):
                set_edges(p, [edge])
        with self.assertRaises(ValueError):
            set_edges(p, [])

    def test_existing_packaging_requires_retiming(self):
        p = self.plan()
        p["captions"] = [{"text": "保留修改", "start": 0, "end": .5}]
        with self.assertRaises(ValueError):
            set_edges(p, [{"source": "main", "start": 5, "end": 6, "reason": "观察"}])


if __name__ == "__main__":
    unittest.main()
