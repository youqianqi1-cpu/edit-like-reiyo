"""Find missed semantic phrase boundaries, without inventing cuts or word timings.

These patterns nominate review points, not an automatic Chinese sentence parser.
The editor still reviews every phrase. No character-count or per-character splitting.
"""
import argparse
import hashlib
import math
import json
from pathlib import Path
import re

PATTERNS = (
    ('context_then_object', re.compile(r'(?:里的|中的|上的|里面的|当中的|的)(?=(?:这个|那个|这位|那位|这些|那些))')),
    ('setting_then_action', re.compile(r'(?:里面|当中|这里|那里|之后|以前|以后|的时候|网站里|视频里)(?=(?:你|我|他|她|我们|大家|可以|就能))')),
    ('turn_or_result', re.compile(r'(?=但是|不过|然而|所以|因此|结果|然后)')),
    ('condition_then_result', re.compile(r'(?=那就|就可以|才能|就能)')),
)


def key(caption):
    raw = json.dumps({k: caption[k] for k in ('text', 'start', 'end')}, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(raw.encode()).hexdigest()[:20]


def boundaries(text):
    found = {}
    for reason, pattern in PATTERNS:
        for match in pattern.finditer(text):
            pos = match.end()
            left, right = text[:pos], text[pos:]
            if not left.strip() or not right.strip():
                continue
            # Do not leave a lone function word. A phrase may end in 的 or 了.
            if left in ('我', '你', '他', '她', '的', '了', '是', '就', '才'):
                continue
            found.setdefault(pos, {'offset': pos, 'left': left, 'right': right, 'reason': reason})
    return sorted(found.values(), key=lambda x: x['offset'])


def check(plan):
    keep = plan.get('caption_review', {}).get('keep_whole', {})
    rows = []; invalid_timing = []
    for group in ('captions', 'caption_promotions'):
        for i, cap in enumerate(plan.get(group, [])):
            if not all(type(cap.get(k)) in (int,float) and math.isfinite(cap[k]) for k in ('start','end')) or cap['start']<0 or cap['end']<=cap['start']:
                invalid_timing.append({'group':group,'index':i,'text':cap['text'],'start':cap.get('start'),'end':cap.get('end')})
            proposals = boundaries(cap['text'])
            if proposals:
                identity = key(cap)
                reason = keep.get(identity)
                rows.append({'group': group, 'index': i, 'key': identity,
                             'text': cap['text'], 'start': cap['start'], 'end': cap['end'],
                             'possible_boundaries': proposals,
                             'keep_reason': reason if isinstance(reason, str) and reason.strip() else None})
    pending = [r for r in rows if not r['keep_reason']]
    return {'status': 'phrase_review_needed' if pending or invalid_timing else 'candidate_boundaries_resolved',
            'scanned_caption_count': len(plan.get('captions', [])),
            'scanned_promoted_count': len(plan.get('caption_promotions', [])),
            'candidates': rows, 'pending': pending, 'invalid_timing':invalid_timing, 'actual_listening': False,
            'semantic_review_complete': False,
            'note': 'A clean scan is not full semantic approval. Review all phrases; split using recognized speech times, never equal-duration slices.'}


def require_resolved(report):
    if report.get('invalid_timing'):raise ValueError('Caption timing unresolved or invalid; do not drop untimed inserted words or fabricate durations')
    if report['pending']:
        raise ValueError('Review short-phrase boundaries before assembly: ' + '; '.join(
            f"{r['start']:.2f}s {r['text']}" for r in report['pending']))


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('plan', type=Path); ap.add_argument('output', type=Path)
    ap.add_argument('--require-pass', action='store_true')
    a = ap.parse_args(); report = check(json.loads(a.plan.read_text(encoding='utf-8')))
    a.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(report['status'], 'pending', len(report['pending']))
    if a.require_pass: require_resolved(report)
