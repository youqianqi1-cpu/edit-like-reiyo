"""Portable diagram layers, waveform sheets and frame contact sheets.
Same normalized bottom-left shape coordinates as draw_shapes.swift.
"""
import argparse
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont


def draw_shapes(data, output):
    w,h = data['width'],data['height']
    if not (0 < w <= 8192 and 0 < h <= 8192): raise ValueError('Invalid image dimensions')
    image = Image.new('RGBA',(w,h)); draw = ImageDraw.Draw(image)
    for shape in data['shapes']:
        color = tuple(round(c*255) for c in shape['color'])
        if len(color)==3: color += (255,)
        x,y = shape.get('x',0)*w,shape.get('y',0)*h
        width,height = shape.get('w',1)*w,shape.get('h',1)*h
        box = (x,h-y-height,x+width,h-y)
        if shape['type']=='ellipse': draw.ellipse(box,fill=color)
        elif shape['type']=='line':
            draw.line((x,h-y,shape['x2']*w,h-shape['y2']*h),fill=color,width=max(1,round(shape.get('stroke',4))))
        else: draw.rounded_rectangle(box,radius=shape.get('radius',0),fill=color)
    image.save(output)


def waves(rows, output, font_path):
    if not rows: raise ValueError('No waveform rows')
    image = Image.new('RGB',(1200,140*len(rows)),'white'); draw = ImageDraw.Draw(image)
    font = ImageFont.truetype(font_path,16)
    for i,row in enumerate(rows):
        top = i*140; draw.text((10,top+4),row['label'],font=font,fill='black')
        for j,side in enumerate(['head','tail']):
            r=row[side]; values=r['values']; peak=max(max(values,default=0),.003); x0=j*600+15; y=top+80
            for k,value in enumerate(values):
                x=x0+k*570/max(1,len(values)); amplitude=value/peak*46
                draw.line((x,y-amplitude,x,y+amplitude),fill='#1f4080')
            x=x0+(r['cut']-r['a'])/(r['b']-r['a'])*570
            draw.line((x,y-50,x,y+50),fill='red',width=2)
            draw.text((x0,top+123),f"{side} {r['a']:.3f} -> {r['b']:.3f} | {r['cut']:.3f}",font=font,fill='black')
    image.save(output)


def contact(paths, output):
    width,height=320,200; columns=3
    if not paths: raise ValueError('No input images')
    result=Image.new('RGB',(width*columns,height*((len(paths)+columns-1)//columns)),'white')
    draw=ImageDraw.Draw(result)
    for i,path in enumerate(paths):
        with Image.open(path) as source:
            image=source.convert('RGB'); image.thumbnail((width,height-25))
        x,y=(i%columns)*width,(i//columns)*height
        result.paste(image,(x,y)); draw.text((x,y+height-20),str(i+1),fill='black')
    result.save(output)
    Path(str(output)+'.index.json').write_text(json.dumps(paths,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__=='__main__':
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='command',required=True)
    for name in ['shapes','waves']:
        c=sub.add_parser(name); c.add_argument('input'); c.add_argument('output')
        if name=='waves': c.add_argument('--font',required=True)
    c=sub.add_parser('contact'); c.add_argument('output'); c.add_argument('images',nargs='+')
    a=p.parse_args()
    if a.command=='contact': contact(a.images,a.output)
    else:
        data=json.loads(Path(a.input).read_text(encoding='utf-8'))
        if a.command=='shapes': draw_shapes(data,a.output)
        else: waves(data,a.output,a.font)
