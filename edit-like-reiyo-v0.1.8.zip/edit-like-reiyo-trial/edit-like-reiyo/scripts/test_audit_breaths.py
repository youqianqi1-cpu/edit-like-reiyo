import array,copy,pathlib,tempfile,unittest
from audit_breaths import audit

class JoinedQuietTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def pcm(self,name,windows):
  p=self.root/name;p.mkdir();a=array.array('h')
  for value in windows:a.extend([value]*160)
  (p/'audio.pcm').write_bytes(a.tobytes())
 def test_short_sides_accumulate_at_join_without_changing_plan(self):
  self.pcm('a',[3000]*92+[0]*8);self.pcm('b',[0]*9+[3000]*91)
  p={'fps':30,'takes':[{'source':'a','start':0,'end':1},{'source':'b','start':0,'end':1}]};before=copy.deepcopy(p)
  r=audit(p,self.root)
  self.assertEqual(p,before);self.assertEqual([t['quiet_candidates']for t in r['takes']],[[],[]])
  self.assertEqual(len(r['joins']),1);j=r['joins'][0]
  self.assertEqual(j['combined_quiet_seconds'],.17);self.assertEqual(j['timeline_join'],1)
  self.assertEqual(j['left_source'],'a');self.assertEqual(j['right_source'],'b');self.assertEqual(j['decision'],'review_required')
 def test_voiced_join_is_not_flagged_and_interior_still_is(self):
  self.pcm('a',[3000]*30+[0]*20+[3000]*150)
  p={'fps':24,'takes':[{'source':'a','start':0,'end':1},{'source':'a','start':1,'end':2}]}
  r=audit(p,self.root);self.assertEqual([j for j in r['joins'] if j['decision']=='review_required'],[])
  self.assertEqual(r['takes'][0]['quiet_candidates'][0]['duration'],.2)
 def test_out_of_range_audio_is_reported(self):
  self.pcm('a',[3000]*100)
  with self.assertRaises(ValueError):audit({'fps':24,'takes':[{'source':'a','start':0,'end':2}]},self.root)

if __name__=='__main__':unittest.main()
