import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from fractions import Fraction
from types import SimpleNamespace
from unittest.mock import patch

HAS_MEDIA=all(importlib.util.find_spec(n) for n in ['av','numpy','PIL'])


class WhisperAdapterTests(unittest.TestCase):
    def test_word_clock_and_local_only_model_are_preserved(self):
        from portable_media import transcribe
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'model.bin').touch()
            word=SimpleNamespace(start=.25,end=.5,word='原话',probability=.9)
            segment=SimpleNamespace(words=[word])
            class Model:
                def __init__(self,*args,**kwargs):
                    assert kwargs['local_files_only'] is True
                def transcribe(self,*args,**kwargs):
                    assert kwargs['vad_filter'] is False
                    return iter([segment]),None
            with patch.dict('sys.modules',{'faster_whisper':SimpleNamespace(WhisperModel=Model)}):
                rows=transcribe(root/'audio.wav',root/'words.jsonl',root)
            self.assertEqual(rows[0]['start'],.25)
            self.assertEqual(rows[0]['duration'],.25)
            self.assertEqual(json.loads((root/'words.jsonl').read_text(encoding='utf-8'))['text'],'原话')


@unittest.skipUnless(HAS_MEDIA,'Requires portable media dependencies')
class PortableMediaTests(unittest.TestCase):
    def setUp(self):
        import av
        import numpy as np
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name); self.source=self.root/'带延迟的样本.mkv'
        with av.open(str(self.source),'w') as output:
            video=output.add_stream('ffv1',rate=25); video.width=64; video.height=48; video.pix_fmt='yuv420p'
            audio=output.add_stream('pcm_s16le',rate=16000); audio.layout='mono'
            for i in range(50):
                pixels=np.zeros((48,64,3),dtype=np.uint8); pixels[:,:,0]=i*4
                frame=av.VideoFrame.from_ndarray(pixels,format='rgb24'); frame.pts=i; frame.time_base=Fraction(1,25)
                for packet in video.encode(frame): output.mux(packet)
            for packet in video.encode(): output.mux(packet)
            values=(np.sin(np.arange(16000)*2*np.pi*440/16000)*12000).astype(np.int16).reshape(1,-1)
            frame=av.AudioFrame.from_ndarray(values,format='s16',layout='mono'); frame.sample_rate=16000
            frame.pts=4000; frame.time_base=Fraction(1,16000)
            for packet in audio.encode(frame): output.mux(packet)
            for packet in audio.encode(): output.mux(packet)

    def test_audio_delay_stays_on_original_clock(self):
        import numpy as np
        from portable_media import decode_pcm,probe
        target=self.root/'audio.pcm'; decode_pcm(self.source,target)
        values=np.frombuffer(target.read_bytes(),dtype='<i2')
        self.assertAlmostEqual(probe(self.source)['duration'],2,places=2)
        self.assertTrue(np.all(values[:3990]==0))
        self.assertGreater(np.max(abs(values[4100:5000])),10000)
        self.assertEqual(len(values),32000)

    def test_frames_and_bottom_left_shapes(self):
        from PIL import Image
        from portable_media import frames
        from portable_visuals import draw_shapes
        rows=frames(self.source,self.root/'frames',[0,.8,1.6])
        self.assertEqual(len(rows),3)
        for row in rows: self.assertLess(abs(row['actual']-row['requested']),.041)
        target=self.root/'shapes.png'
        draw_shapes({'width':100,'height':100,'shapes':[{'type':'rect','x':0,'y':0,'w':.5,'h':.25,'color':[1,0,0,1]}]},target)
        with Image.open(target) as image:
            self.assertEqual(image.getpixel((10,90)),(255,0,0,255))
            self.assertEqual(image.getpixel((10,10))[3],0)

    def test_missing_model_stops_without_download(self):
        # Model presence is checked before importing the optional recognizer.
        from portable_media import transcribe
        with self.assertRaises(FileNotFoundError):
            transcribe(self.source,self.root/'words.jsonl',self.root/'missing-model')


if __name__=='__main__': unittest.main()
