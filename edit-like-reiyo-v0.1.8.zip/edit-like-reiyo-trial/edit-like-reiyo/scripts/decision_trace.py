"""Expose recorded editorial decisions; never certify their semantic or audible quality."""
import argparse
from collections import Counter
import json
import math
from pathlib import Path
from media_settings import plan_fps


def trace(plan, base_dir=None):
    fps = plan_fps(plan)
    us = lambda x: round(round(x * fps) * 1e6 / fps)
    mapping, cursor = [], 0
    for take in plan['takes']:
        start, end = us(take['start']) / 1e6, us(take['end']) / 1e6
        duration = round(end - start, 6)
        mapping.append(dict(source=take['source'], start=start, end=end,
                            at=cursor, duration=duration))
        cursor = round(cursor + duration, 6)

    def locations(source, start, end):
        return [dict(source=source, source_start=max(start, t['start']),
                     source_end=min(end, t['end']),
                     start=round(t['at'] + max(start, t['start']) - t['start'], 6),
                     end=round(t['at'] + min(end, t['end']) - t['start'], 6))
                for t in mapping if t['source'] == source
                and max(start, t['start']) < min(end, t['end'])]

    def source_at(at):
        return [dict(source=t['source'], at=round(t['start'] + at - t['at'], 6))
                for t in mapping if t['at'] <= at < t['at'] + t['duration']]

    sounds, starts = [], []
    for i, cue in enumerate(plan.get('sounds', [])):
        selection = cue.get('selection', {})
        offset = selection.get('anchor', {}).get('sound_offset_seconds', 0)
        at = cue['start'] + offset
        if not math.isfinite(at):
            raise ValueError('Sound event time must be finite')
        if not cue.get('muted') and cue.get('volume', 1) > 0:
            starts.append(at)
        sounds.append(dict(index=i, path=cue['path'], start=cue['start'], event_at=at,
                           source_locations=source_at(at), reason=cue.get('reason'),
                           selection=selection, candidate_count=len(selection.get('candidates', [])),
                           muted=bool(cue.get('muted') or cue.get('volume', 1) <= 0)))
    gaps = [round(b - a, 6) for a, b in zip(sorted(starts), sorted(starts)[1:])]
    def repeated(values):
        return {key: count for key, count in Counter(v for v in values if v).items() if count > 1}
    sound_stats = dict(events=len(sounds), unique_files=len({s['path'] for s in sounds}),
                       active_event_gaps=gaps, gaps_6_to_8_seconds=sum(6 <= g <= 8 for g in gaps),
                       single_candidate_indices=[s['index'] for s in sounds if s['candidate_count'] == 1],
                       missing_candidate_indices=[s['index'] for s in sounds if s['candidate_count'] == 0],
                       repeated_reuse_reasons=repeated(s['selection'].get('reuse_or_single_reason') for s in sounds),
                       repeated_comparison_paths=repeated((s['selection'].get('comparison_evidence') or {}).get('path') for s in sounds))

    pauses, record_errors = [], []
    decision_path = (plan.get('breath_review') or {}).get('decisions')
    decisions = None
    if decision_path:
        path = Path(decision_path)
        if not path.is_absolute():
            path = Path(base_dir or Path.cwd()) / path
        try:
            decisions = json.loads(path.read_text(encoding='utf-8'))
        except (OSError, ValueError) as exc:
            record_errors.append(dict(path=str(path), error=str(exc)))
    else:
        record_errors.append(dict(error='No breath decisions path recorded'))
    def add_pause(segment, origin):
        if segment.get('disposition') == 'expressive_pause':
            pauses.append(dict(id=origin['id'], origin=origin, recorded=segment,
                               timeline_locations=locations(segment['source'], segment['start'], segment['end']),
                               duration_evidence_verdict='requires_continuous_observation_or_listening'))
    if isinstance(decisions, dict):
        for item in decisions.get('items', []):
            for segment in item.get('segments', []):
                add_pause(segment, dict(kind='item', id=item.get('id'), action=item.get('action')))
        for join in decisions.get('join_reviews', []):
            for side in ('left', 'right'):
                for segment in join.get(side, []):
                    add_pause(segment, dict(kind='join', id=join.get('id'), side=side))
    elif decisions is not None:
        record_errors.append(dict(error='Breath decisions is not an object'))
    # These are evidence records, not fault counts. Surface overlapping observations together.
    for i, pause in enumerate(pauses):
        a = pause['recorded']
        pause['overlaps_record_indices'] = [j for j, other in enumerate(pauses) if i != j
            and a['source'] == other['recorded']['source']
            and max(a['start'], other['recorded']['start']) < min(a['end'], other['recorded']['end'])]
    review = plan.get('punchline_review') or {}
    punchlines = []
    for candidate in review.get('candidates', []):
        punchlines.append(dict(recorded=candidate,
                              timeline_locations=locations(candidate['source'], candidate['start'], candidate['end']),
                              planned_events=[e for e in plan.get('punchline_events', []) if e.get('id') == candidate.get('id')]))
    warnings = []
    if len(gaps) >= 5 and sum(6 <= g <= 8 for g in gaps) / len(gaps) >= .8:
        warnings.append('regular_sound_spacing: compare each event with actual meaning; this is not a rejection')
    if sound_stats['repeated_reuse_reasons']:
        warnings.append('repeated_sound_reuse_reason: check whether reuse has a specific role in each passage')
    if punchlines and all(not c['recorded'].get('selected') for c in punchlines):
        warnings.append('all_punchlines_declined: check preserved performance or actual alternative; zero events is allowed')
    if pauses:
        warnings.append('expressive_pause_duration: still frames locate posture but do not establish duration or sound')
    return dict(stage='planned', quality_certified=False, semantic_evidence_verified=False,
                playback_verified=False, native_result_verified=False,
                duration=cursor, mapping=mapping, warnings=warnings,
                sound_statistics=sound_stats, sounds=sounds,
                sound_selection_basis=(plan.get('sound_review') or {}).get('selection_basis'),
                listening_record=(plan.get('sound_review') or {}).get('listening'),
                expressive_pauses=pauses, breath_record_errors=record_errors,
                punchline_reason=review.get('reason'), punchlines=punchlines,
                planned_visual_counts={key: len(plan.get(key, [])) for key in ('captions', 'titles', 'overlays')},
                actual_result='Compare generated .mapping/.punchlines/.native-sound-density and saved readback; then play the actual passage')


def write_trace(plan, output, base_dir=None):
    report = trace(plan, base_dir)
    Path(output).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan')
    parser.add_argument('output')
    args = parser.parse_args()
    source = Path(args.plan)
    write_trace(json.loads(source.read_text(encoding='utf-8')), args.output, source.parent)
