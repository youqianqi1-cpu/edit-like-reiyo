# 单片剪辑计划

这是模型根据原片作出剪辑判断后生成的内部文件，用户只需提供素材和需求。工具按计划执行，并核对可验证的结构。

所有时间单位为秒。时间轴起点从 0 开始；素材中的时间必须来自对应原片，不能从别的识别音轨或旧成片搬来。

- `canvas`: `{"ratio":"9:16","width":1080,"height":1920}`，以用户要求/原片为准。
- `fps`: 剪点计算前必须写入已核帧率；运行 `media_settings.py 原计划.json 已核帧率计划.json` 按主要口播实测填写。`fps_reason` 只用于用户明确指定交付帧率或明确保留已有时间线的原因，不能为静默默认值补理由。装配时复核一致，不缺省为30。
- `breath_review`: 最终信号扫描的 `report` 和范围处置/接缝两侧复核 `decisions` 两个文件路径；生成与写入前核对剪点、帧率、原片记录和PCM均未变化。位置见 local-execution.md。
- `sources`: 源名称到 `{path,duration,width,height,type}` 的映射；type 默认为 video，静态图为 photo。
- `takes`: 按成片顺序列出 `{source,start,end,reason}`。start/end 是原片位置；可加 scale/x/y/volume（默认1）。先保全独有信息，再比较重说、收紧气口。所有删除理由在本次工作目录留底。
- `captions`: `{text,start,end,size?,x?,y?,lane?,color?,background?}`，start/end 是成片位置，按字词实际时间映射并校对。默认蓝字白底短句。累积块分到独立 lane，同一 lane 不重叠；background 可为颜色或 false。原声时点不因排版变化。
- `titles`: `{text,start,end,size?,x?,y?,color?,pop?}`，与普通字幕分开，默认有深蓝偏移投影。标题的语义和落点由原片决定。
- `overlays`: `{source,start,end,source_start,scale?,x?,y?,volume?}`，source_start 是对应素材时间，默认静音。
- `sounds`: `{path,start,volume?,reason}`，素材为 WAV。默认正常音量 1.0，不因为是音效就压低；声效时长来自实际文件。避免长音效重叠盖讲话。
- `font` / `title_font`: 当前机器实际存在的字体文件。Mac 未提供时用剪映随附中文字体；Windows 必须明确填写本机存在的中文字体，preflight.py 会列候选。
- takes 和 overlays 可加 `keys`，例如 `{"KFTypeScaleX":[[0,1],[0.4,1.12]],"KFTypeScaleY":[[0,1],[0.4,1.12]]}`。这里是相对片段的秒数；工具负责加回源素材起点。不要再次手动加源起点。跳切用相邻帧的两个关键帧表示，不能以长缓推代替。

生成候选后检查连续两段是否真正衔接；必要的表情停留在 takes 中保留，不拿动画覆盖吞字或生硬剪口。若要改变已经获认可的剪点，单独验证原声和所有关联层的同步。

多个同时出现的重点字可给 titles 指定不同 `lane`（字符串或整数）；同一 lane 内不允许重叠。章节提示也用独立 lane，避免占用普通字幕位置。音效和重点字的落点先定位原片真正说到该词的位置，再按 takes 映射到成片，不能给整段随意加固定偏移。


## 声音选择与试听记录

每个 `sound` beat 可带 `selection`，生成后保存在对应 `plan.sounds` 项中：
- `event`、`context`、`choice_reason`：表达事件、前后文、选用理由。
- `candidates`：实际比较的候选 `{path,finding}`；只有一个候选或沿用认可方案时，用 `reuse_or_single_reason` 说明实际原因。
- `anchor`：`kind` 为 spoken_word / reaction / visible_action / visual_landing；`timeline_seconds` 是成片事件时刻，`sound_offset_seconds` 是选用声音区间内对应落点的偏移；`evidence` 指向实际词时、画面或听审证据。识别词时不能冒充实际听过的重音。
- `comparison_evidence`：实际对照记录；`licence_scope` 如实注明本地体验、已核许可或待核。

计划顶层 `sound_review` 放 `catalogs`（每项含实际检索的 scope 与证据）、`preview`（sound_preview.py 输出的对照报告）、`listening`（status 为 pending 或 reviewed；后者需 reviewer、note、evidence）。证据引用统一 `{path,sha256}`，供检查文件是否存在且未变；填写记录不自动证明主观质量。预览报告绑定实际声音选择与输入文件，改音量、位置或声音后需要重新生成对照。

所有位置均为成片秒数；音效开始时刻加声音内部偏移，应对应事件时刻。不得统一拿字幕块起点充当真实重音。用户无需填写这些内部记录。

名称暂选路线：顶层 `sound_review.selection_basis` 设为 `name_inference`，可以省略音频 preview，listening 保持 pending。检索与比较记录可以是名称/作者/时长及实际库取得证据，不虚构音色。检查返回 name_selected_unlistened 时仍可生成草稿；它不代表听审完成。


## 约7秒音效规划与短语检查

`plan.sounds` 只记录真正的音效，BGM 不用它充数。`sound_density.py` 用当前帧率和 takes 计算完整成片时长；事件位置为音效 start 加已记录的 anchor.sound_offset_seconds（相对选定声音片段的起音偏移）。未提供偏移时只按片段起点算，并明确尚未核对真实起音。约7秒找事件，任何空段不得超过10秒，生成前和保存读回后分别检查。

`caption_review.keep_whole` 为 `{检查报告中的key: 具体保留理由}`，仅处理语义扫描的例外候选。正常需要拆的短语应实际拆开并重新对齐，不填理由来假装修复。保留个人手改时记录那一条实际要求。`caption_phrases.py` 检查全部 captions 和 caption_promotions；不是固定字数切分器。

## 包袱判断与关联事件

新计划必须填写 `punchline_review.reason` 与 `candidates`，候选字段及 `punchline` beat 见 [表现方法](performance-recipes.md#有依据的包袱把缩小配声和恢复作为一次选择)。没有合适候选填空数组并写实际原因，不为过检查编造笑点。compose 生成 `punchline_events`、对应 `sounds[].punchline_id` 与 `punchline_protected_takes`，作为后续修改和保存读回的对照；不要删掉记录来绕过未执行的事件。只修改本次获准范围；声音换位/换素材时同步重新规划关联事件，不移动用户认可的剪口、字幕或原声。

生成/保存模式由调用时的 `--pending-preview` 明确选择，不能在计划里改一个标签来放宽默认正式流程。候选同时生成 `.breath-review.json` 外部记录，保存工具将它与实际工程及时间线绑定；候选内的 `reiyo_breath_review` 是原生保存可能删除的附加提示。保留外部记录及其引用的扫描/处置/声音分析文件，正式升级须重新核验并生成新的候选。验收使用 `draft_io.py verify` 或 Windows 对应入口读取实际工程，详见 local-execution.md。

## 决策与实际结果

生成时自动输出 `.decision-trace.json`，也可按 [决策对照](decision-trace.md) 单独生成。它读取已有计划与气口处置，映射源区间与成片位置，并列出声音候选、重复理由、包袱选用及保留原因；`planned` 表示计划证据，实际生成与保存结果继续沿用原有检查报告。数量统计只帮助定位，不改变10秒上限、不强制笑点或音效种类，也不自动批准表达停顿。
